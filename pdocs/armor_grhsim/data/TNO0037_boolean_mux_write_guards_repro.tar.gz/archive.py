"""Validate the full-design replay, row proofs, DiffTest runs and paired PMU measurements."""
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

case = Path(__file__).resolve().parent
baseline = case.parent / 'armor-xs-priority-fixed-v1'
previous = case.parent / 'armor-xs-row-conflicts-v1'
dest = case.parents[1] / 'pdocs/armor_grhsim/data'
prefix = 'TNO0037_boolean_mux_write_guards'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
        return digest.hexdigest()


def groups(path):
    return {g['group']: g for line in path.open()
            if (g := json.loads(line))['outcome'] != 'decoded_write_overlap'}


def stats(values):
    assert len(values) == 8
    mean = statistics.mean(values)
    margin = 2.3646242516 * statistics.stdev(values) / math.sqrt(8)
    return dict(mean=mean, ci95=[mean-margin, mean+margin], minimum=min(values),
                maximum=max(values), below_zero=sum(x < 0 for x in values))


before = groups(baseline/'emitted-groups.jsonl')
after = groups(case/'groups.jsonl')
assert sha(case/'groups.jsonl') == sha(case/'emitted-groups.jsonl')
assert before.keys() == after.keys() and len(after) == 4782
changed = {i for i,g in after.items() if before[i]['outcome'] != g['outcome']}
assert changed == {945, 946, 975, 976}
assert all(before[i]['writes'] == after[i]['writes'] for i in after)
assert all(before[i]['consolidated_reject']=='priority_guard' and after[i]['normalized_match']=='boolean_mux_priority'
           and after[i]['outcome']=='converted' for i in changed)

proofs = []
for i in sorted(changed):
    members = after[i]['members']
    ports = set()
    width = 7 if i in (945,946) else 6
    for start in range(0, members, 10):
        end = min(start+10, members)
        chunk = read(case/'proof'/f'{i}-{start}-{end}-base.json')
        assert (chunk['group'],chunk['first'],chunk['end'],chunk['rows'],chunk['unsat'],chunk['width']) == (
            i,start,end,end-start,end-start,width)
        assert not chunk['fill'] and chunk['mutation'] is None
        ports.add(chunk['ports'])
    mutation = read(case/'proof'/f'{i}-0-1-drop.json')
    assert mutation['first_non_unsat'] == [0,'sat'] and ports == {37 if width == 7 else 29}
    proofs.append(dict(group=i, rows=members, unsat=members, width=width, ports=ports.pop(), dropped_port='sat'))

report = dict(graph=dict(candidates=len(after), converted_before=sum(g['outcome']=='converted' for g in before.values()),
                         converted_after=sum(g['outcome']=='converted' for g in after.values()),
                         proofs=proofs,cv32=read(case/'cv32.json'),
                         post_sha256=sha(case/'post.json'),group_report_sha256=sha(case/'groups.jsonl')),
              builds={}, validation={}, workloads={})
assert 'Identical post-pass graph: '+report['graph']['post_sha256'] in (case/'no-report.log').read_text()
for tag, path in [('reference',baseline),('candidate',case)]:
    report['builds'][tag] = {name:sha(path/'build'/name) for name in ('emu','grhsim-sites.tsv.gz','grhsim.profdata')}


def trace(path, reference):
    actual, expected = read(path), read(reference)
    assert actual['pass_'] and expected['pass_'] and actual['records'] == expected['records']
    assert actual['last_cycle'] == expected['last_cycle']
    def chunks(t):
        return [(c['name'], c['records'], c['b']['sha256']) for c in t['chunks']]
    assert chunks(actual) == chunks(expected)
    assert all(c['a']['sha256'] == c['b']['sha256'] for c in actual['chunks'])
    return dict(records=actual['records'],last_cycle=actual['last_cycle'],chunks=chunks(actual))


raw_rows = []
for wl,cpu in [('coremark',104),('microbench',120)]:
    v = read(case/'verify'/wl/'result.json')
    assert v == read(previous/'verify'/wl/'result.json')
    report['validation'][wl] = dict(**v,trace=trace(case/'verify'/wl/'trace.json',previous/'verify'/wl/'trace.json'))
    signature = v['signature']
    rounds = read(case/'pairs/main'/wl/'rounds.json')
    assert len(rounds) == 8 and sum(r['order'][0]=='candidate' for r in rounds)==4
    wall, cycle_pct = [], []
    event_deltas = {}
    for number,r in enumerate(rounds,1):
        assert r['cpu'] == cpu and sorted(r['order']) == ['candidate','reference']
        for pos,tag in enumerate(r['order'],1):
            s = r[tag]
            assert s['binary']['sha256'] == report['builds'][tag]['emu']
            assert all(s[k]==v for k,v in signature.items()) and s['guest_cycles']==100001
            folder = case/s['path']
            assert all(s[k]==v for k,v in read(folder/'sample.json').items())
            with (folder/'perf.csv').open() as f:
                counters = {line[2].removesuffix(':u'):(int(line[0]),float(line[4])) for line in csv.reader(f)
                            if len(line)>4 and line[2].removesuffix(':u') in s['counts']}
            assert counters == {k:(n,s['counter_running_pct'][k]) for k,n in s['counts'].items()}
            idle = min(pct for c,pct in s['sibling_idle'].items() if int(c)!=cpu)
            running = min(s['counter_running_pct'].values())
            assert s['placements']>0 and idle>=98 and running>=98 and s['cpu_fraction']>=.97
            raw_rows.append(dict(workload=wl,round=number,position=pos,variant=tag,cpu=cpu,
                                 binary_sha256=s['binary']['sha256'],guest_cycles=s['guest_cycles'],pc=s['pc'],
                                 guest_instructions=s['instr_count'],arch_cycles=s['cycle_count'],difftest=s['runtime_difftest'],
                                 wall_s=s['external_wall_s'],**s['counts'],min_running_pct=running,sibling_idle_pct=idle,
                                 cpu_fraction=s['cpu_fraction'],source=s['path']))
        a,b = r['reference'],r['candidate']
        wall.append(100*(b['external_wall_s']/a['external_wall_s']-1))
        cycle_pct.append(100*(b['counts']['cycles']/a['counts']['cycles']-1))
        for k in a['counts']:
            event_deltas.setdefault(k,[]).append((b['counts'][k]-a['counts'][k])/a['guest_cycles'])
    report['workloads'][wl]=dict(wall_pct=stats(wall), cycles_pct=stats(cycle_pct),
                                 per_guest_cycle={k:stats(v) for k,v in event_deltas.items()})
full = read(case/'long/verified.json')
ref = read(previous/'long/verified.json')
assert all(full[k]==ref[k] for k in ('guest_cycles','cycle','instr'))
assert 'HIT GOOD TRAP at pc = 0x80003a4e' in (case/'long/run.log').read_text()
report['validation']['microbench_full'] = dict(guest_cycles=full['guest_cycles'],guest_instructions=full['instr'],
                                               pc='0x80003a4e',trace=trace(case/'long/trace.json',previous/'long/trace.json'))
assert len(raw_rows)==32
report['min_sample_quality']={k:min(r[k] for r in raw_rows) for k in ('min_running_pct','sibling_idle_pct','cpu_fraction')}
with (dest/(prefix+'_samples.csv')).open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=raw_rows[0],lineterminator='\n')
    writer.writeheader()
    writer.writerows(raw_rows)
(dest/(prefix+'_results.json')).write_text(json.dumps(report,indent=2)+'\n')
