# TNO0037 复现

在主仓根目录使用同一份调度前香山 GRH。构建目录的原始组报告、Z3 结果和两个版本的完整构建命令都与归档样本采用同一次实验的路径。重新运行时使用空目录保存新产物。

```sh
xs_case=$(mktemp -d "$PWD/build/queue-guards-replay.XXXXXX")
tar -xzf pdocs/armor_grhsim/data/TNO0037_boolean_mux_write_guards_repro.tar.gz -C "$xs_case"
tool_dir="$PWD/build/armor-dispatch-v1/tools"
export PYTHONPATH="$tool_dir/python" LD_LIBRARY_PATH="$tool_dir"
ulimit -s unlimited
cmake --build "$tool_dir" --target transform-reg-to-mem wolvrix_python -j8
ctest --test-dir "$tool_dir" -R '^transform-reg-to-mem$' --output-on-failure
python3 scripts/armor_xs_gap_diagnostics/replay_reg_to_mem.py \
  build/armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json "$xs_case/groups.jsonl" \
  --normalize-write-conflicts --share-write-guards --prove-mux-write-guards \
  --output-checkpoint "$xs_case/post.json"
python3 "$xs_case/run_proof.py" all
python3 "$xs_case/run_proof.py" drop
python3 "$xs_case/no_report.py"
```

基线与候选均带写优先级修复，基线的 `build_model.py` 使用相同的旧构建参数并省略新选项。两个入口分别在自己的目录执行 `emit pgo`，复用 TNO0028 填好的工作负载、工具链和构建环境。候选用 `verify_model.py` 验证短轨迹，用 `verify_model.py long` 验证完整 MicroBench。在 node030 从候选目录运行以下两条计时命令。环境须可读取两个二进制和已归档实测所用的参考 NEMU、固件与轨迹。

```sh
python3 measure.py main coremark 104 reference candidate --rounds 8
python3 measure.py main microbench 120 reference candidate --rounds 8
```

`measure.py` 给出的基线目录是 `build/armor-xs-priority-fixed-v1`。采用其他目录重建基线时相应调整该路径。原实验的 `archive.py` 使用这个基线目录、候选目录及 TNO0036 的轨迹核对原始证据后生成结果 JSON 与逐轮 CSV。复现包中的 `proof/` 和 `evidence/` 保存冻结的证明与验证输出。
