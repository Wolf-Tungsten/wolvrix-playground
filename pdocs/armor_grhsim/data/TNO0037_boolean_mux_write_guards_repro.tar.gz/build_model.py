"""Rebuild the TNO0028 model with the generic conflict rule and train both PGOs."""
import json
from pathlib import Path
import resource
import sys

out = Path(__file__).resolve().parent
root = out.parents[1]
old = root / "build/armor-xs-value-paths-v1"
sys.path.insert(0, str(root / "scripts"))
from armor_xs_pgo_build import execute
from grhsim_single_baseline import clean_environment

resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
tool = root / "build/armor-dispatch-v1/tools"
env = dict(clean_environment(), PYTHONPATH=str(tool / "python"), LD_LIBRARY_PATH=str(tool),
           WOLVRIX_XS_GRHSIM_REG_TO_MEM_PROVE_MUX_WRITE_GUARDS="1",
           WOLVRIX_XS_GRHSIM_REG_TO_MEM_NORMALIZE_WRITE_CONFLICTS="1",
           WOLVRIX_XS_GRHSIM_REG_TO_MEM_SHARE_WRITE_GUARDS="1",
           WOLVRIX_GRHSIM_PRIORITY_MUX_COMMIT_DEMAND="1", WOLVRIX_GRHSIM_PRIORITY_MUX_MIN_CHAIN_LENGTH="13",
           WOLVRIX_XS_GRHSIM_REG_TO_MEM_GROUP_REPORT=str(out / "emitted-groups.jsonl"))
for stage, folder in (("emit", "reemit"), ("pgo", "generator")):
    if stage not in sys.argv[1:]: continue
    source = old / folder
    argv = json.loads((source / (stage + ".command.json")).read_text())["argv"]
    argv = [a.replace(str(source), str(out)) for a in argv]
    execute(argv, stage, out, env, root)
