"""Compare the TNO0033 short-circuit baseline with the newly trained simulator."""
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here.parents[1]/'scripts/armor_xs_gap_diagnostics'))
import site_pairs

site_pairs.base = here
site_pairs.bins.update(reference=here.parent/'armor-xs-shared-guards-v1/build/emu',
                      candidate=here/'build/emu')
site_pairs.main()
