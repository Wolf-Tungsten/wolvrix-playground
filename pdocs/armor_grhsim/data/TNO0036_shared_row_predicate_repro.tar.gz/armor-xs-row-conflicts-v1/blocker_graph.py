"""Extract the remaining normalized-family blockers directly from the input graph."""
import json
from pathlib import Path
from checkpoint_source import Checkpoint, pre_path
here=Path(__file__).resolve().parent
rows=[g for line in (here.parent/'armor-xs-shared-guards-v1/replay-groups.jsonl').open() if (g:=json.loads(line)).get('normalized_match')=='family_mismatch']
graph=Checkpoint(pre_path,set(),set()); keys=list(graph.width); tree={}
for g in rows:
 for b in g.get('normalized_blockers',[]):
  if 'common' not in b['role']:continue
  key=keys[b['value']-1]; assert graph.op(key)['kind']==b['kind'],(key,b,graph.op(key));
  def dump(v,depth):
   op=graph.op(v); kind=op.get('kind','input'); val=op.get('attrs',{}).get('constValue',{}).get('v','');
   return (v,kind,graph.width[v],val,[dump(i,depth-1) for i in op.get('in',[])]) if depth else (v,kind,graph.width[v],val)
  tree.setdefault(str(g['group']),{})[key]=dump(key,6)
(here/'trees.json').write_text(json.dumps(tree));
for k in ('904','924','1017','1254'):print(k,str(tree.get(k,''))[:3500],flush=True)
