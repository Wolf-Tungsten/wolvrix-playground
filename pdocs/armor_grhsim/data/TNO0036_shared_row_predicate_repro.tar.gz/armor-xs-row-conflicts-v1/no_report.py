"""Compare the reference post-pass GRH with an otherwise identical non-reporting run."""
import hashlib
from pathlib import Path
import tempfile
import wolvrix

here = Path(__file__).resolve().parent
source = here.parent/'armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json'

def digest(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for block in iter(lambda: stream.read(16 << 20), b''):
            h.update(block)
        return h.hexdigest()

with tempfile.TemporaryDirectory(dir=here) as work:
    out = Path(work)/'post.json'
    with wolvrix.Session() as session:
        session.read_json_file(str(source), out_design='design.main')
        session.run_pass('reg-to-mem', design='design.main', ordered_writes=True,
                         decoded_write_storage=True, normalize_write_conflicts=True, share_write_guards=True)
        session.store_json(design='design.main', output=str(out))
    sha = digest(out)
    assert sha == digest(here/'post.json')
    print('Identical post-pass graph:', sha)
