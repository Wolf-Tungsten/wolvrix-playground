"""Check two-state equivalence of full-width scalar writes and recovered ordered memory writes."""
import re
import sys
from functools import lru_cache
from pathlib import Path

here = Path(__file__).resolve().parent
sys.setrecursionlimit(1000000)
import checkpoint_source as cw
from checkpoint_source import literal, width_cast

CONST = re.compile(r"(\d+)?'(s)?([bdhoBDHO])([0-9a-fA-F]+)")


class Unsupported(Exception):
    pass


PRE = POST = None
_cone = {}


def stable(v):
    if v not in PRE.width or v not in POST.width or PRE.width[v] != POST.width[v]:
        return False
    if (v in PRE.signed) != (v in POST.signed):
        return False
    a, b = PRE.op(v), POST.op(v)
    return all(a.get(k) == b.get(k) for k in ("sym", "kind", "attrs", "in"))


def cone_stable(v):
    """True when the whole fan-in cone of v is identical before and after the pass."""
    known = _cone.get(v)
    if known is None:
        if not stable(v):
            known = False
        else:
            _cone[v] = True   # the combinational graph is acyclic
            known = all(cone_stable(s) for s in PRE.op(v).get("in", []))
        _cone[v] = known
    return known


def solve_group(g, pre, post, mutate=None, row_ids=None):
    mem = cw.memory_name(g)
    ports = post.ports[mem]
    writes = [p for p in ports if p["kind"] == "kMemoryWritePort"]
    if not writes or len(writes) != len(ports):
        raise Unsupported("port kinds")
    if len(writes) > 1:
        if not all(p["attrs"].get("memoryWrite.priorityGroup", {}).get("v") == mem for p in writes):
            raise Unsupported("priority group")
        if {p["attrs"]["memoryWrite.priority"]["v"] for p in writes} != set(range(len(writes))):
            raise Unsupported("priority values")
        # Lowest priority first; priority 0 is applied last and wins (GRH IR, kMemoryWritePort).
        writes = sorted(writes, key=lambda p: -p["attrs"]["memoryWrite.priority"]["v"])
    if mutate == "drop":
        writes = writes[:-1]
    memattr = post.memory[mem]["attrs"]
    if not memattr["row"]["v"] == g["members"] == len(g["writes"]):
        raise Unsupported("row count")
    word = memattr["width"]["v"]

    stats = dict(rows=0, unsat=0, atoms=0, state_atoms=0)
    cuts = set()
    # Share a symbolic operand only when its full defining cone matches in both graphs.
    pending = [v for p in writes for v in p["in"][:4]]
    visited = set()
    while pending:
        v = pending.pop()
        if v in visited:
            continue
        visited.add(v)
        if cone_stable(v):
            if POST.op(v).get("kind") not in ("kConstant", "kRegisterReadPort"):
                cuts.add(v)
        else:
            pending.extend(POST.op(v).get("in", []))
    for row, (_, op, reg) in enumerate(g["writes"]):
        if row_ids is not None and row not in row_ids:
            continue
        original = pre.writes[op]
        assert original["attrs"]["regSymbol"]["v"] == reg
        decl = []
        leaves = {}

        interned = {}

        def define(w, rhs):
            key = (w, rhs)
            ident = interned.get(key)
            if ident is None:
                ident = interned[key] = f"v{len(decl)}"
                decl.append(f"(define-fun {ident} () (_ BitVec {w}) {rhs})")
            return ident

        def atom(v, w):
            if v not in leaves:
                leaves[v] = "i" + str(len(leaves))
                decl.append(f"(declare-const {leaves[v]} (_ BitVec {w}))")
            return leaves[v]

        def truth(e, w):
            return e if w == 1 else f"(ite (= {e} {literal(0, w)}) #b0 #b1)"

        @lru_cache(None)
        def expr(side, v):
            # side 2: the cone is identical in both graphs, so one definition serves both.
            shared_cone = cone_stable(v)
            if side != 2 and shared_cone:
                return expr(2, v)
            gr = post if side == 1 else pre
            w = gr.width[v]
            o = gr.op(v)
            k = o.get("kind")
            ins = o.get("in", [])
            attrs = o.get("attrs", {})
            if shared_cone and v in cuts:
                stats["cut_atoms"] = stats.get("cut_atoms", 0) + 1
                return atom(("val", v), w)

            def a(i):
                return expr(side, ins[i])

            def cast(i, to):
                return width_cast(a(i), gr.width[ins[i]], to, ins[i] in gr.signed)

            if k == "kRegisterReadPort":
                stats["state_atoms"] += 1
                return atom(("reg", attrs["regSymbol"]["v"]), w)
            if k in ("kSliceDynamic", "kSliceArray"):
                sw = attrs["sliceWidth"]["v"]
                vw, iw = gr.width[ins[0]], gr.width[ins[1]]
                if sw != w or sw > vw:
                    raise Unsupported("dynamic slice width")
                step = sw if k == "kSliceArray" else 1
                positions = (vw // sw) if k == "kSliceArray" else vw
                producer = gr.op(ins[1])
                while producer.get("kind") == "kAssign":
                    producer = gr.op(producer["in"][0])
                if producer.get("kind") == "kConstant":
                    # A constant index selects one fixed field; fold it here.
                    m = CONST.fullmatch(producer["attrs"]["constValue"]["v"].replace("_", ""))
                    if m:
                        j = int(m[4], {"b": 2, "d": 10, "h": 16, "o": 8}[m[3].lower()]) % (1 << iw)
                        lo = j * step
                        if lo >= vw:
                            return literal(0, sw)
                        hi = min(lo + sw, vw) - 1
                        piece = f"((_ extract {hi} {lo}) {a(0)})"
                        if hi - lo + 1 < sw:
                            piece = f"((_ zero_extend {sw - (hi - lo + 1)}) {piece})"
                        return define(w, piece)
                source, index = a(0), a(1)
                if positions <= 4096:
                    # Select by index value; bits beyond the operand read as zero.
                    rhs = literal(0, sw)
                    for j in reversed(range(positions)):
                        if j >= (1 << iw):
                            continue
                        lo = j * step
                        hi = min(lo + sw, vw) - 1
                        piece = f"((_ extract {hi} {lo}) {source})"
                        if hi - lo + 1 < sw:
                            piece = f"((_ zero_extend {sw - (hi - lo + 1)}) {piece})"
                        rhs = f"(ite (= {index} {literal(j, iw)}) {piece} {rhs})"
                else:
                    tw = max(vw, iw) + sw.bit_length() + 1      # wide enough for index * sliceWidth
                    offset = f"((_ zero_extend {tw - iw}) {index})"
                    if k == "kSliceArray":
                        offset = f"(bvmul {offset} {literal(sw, tw)})"
                    rhs = f"((_ extract {sw - 1} 0) (bvlshr ((_ zero_extend {tw - vw}) {source}) {offset}))"
                return define(w, rhs)
            if k == "kConstant":
                m = CONST.fullmatch(attrs["constValue"]["v"].replace("_", ""))
                if not m:
                    if cone_stable(v):
                        return atom(v, w)
                    raise Unsupported("constant " + attrs["constValue"]["v"][:30])
                base = {"b": 2, "d": 10, "h": 16, "o": 8}[m[3].lower()]
                return literal(int(m[4], base), w)
            if k == "kAssign":
                return cast(0, w)
            if k in ("kEq", "kLt", "kGe"):
                aw = max(gr.width[s] for s in ins)
                left, right = cast(0, aw), cast(1, aw)
                signed = all(s in gr.signed for s in ins)
                pred = {"kEq": "=", "kLt": "bvslt" if signed else "bvult", "kGe": "bvsge" if signed else "bvuge"}[k]
                rhs = f"(ite ({pred} {left} {right}) #b1 #b0)"
                rhs = width_cast(rhs, 1, w)
            elif k in ("kOr", "kAnd", "kNot"):
                fn = {"kAnd": "bvand", "kOr": "bvor", "kNot": "bvnot"}[k]
                rhs = f"({fn} " + " ".join(cast(i, w) for i in range(len(ins))) + ")"
            elif k in ("kLogicOr", "kLogicAnd", "kLogicNot"):
                fn = {"kLogicAnd": "bvand", "kLogicOr": "bvor", "kLogicNot": "bvnot"}[k]
                rhs = f"({fn} " + " ".join(truth(a(i), gr.width[ins[i]]) for i in range(len(ins))) + ")"
                rhs = width_cast(rhs, 1, w)
            elif k in ("kReduceOr", "kReduceAnd"):
                req = literal(0 if k == "kReduceOr" else -1, gr.width[ins[0]])
                rhs = f"(ite (= {a(0)} {req}) " + ("#b0 #b1)" if k == "kReduceOr" else "#b1 #b0)")
                rhs = width_cast(rhs, 1, w)
            elif k == "kMux":
                if not (gr.width[ins[1]] == gr.width[ins[2]] == w):
                    raise Unsupported("mux widths")
                rhs = f"(ite (= {truth(a(0), gr.width[ins[0]])} #b1) {a(1)} {a(2)})"
            elif k == "kConcat":
                if sum(gr.width[s] for s in ins) != w:
                    raise Unsupported("concat widths")
                rhs = a(0)
                for i in range(1, len(ins)):
                    rhs = f"(concat {rhs} {a(i)})"
            elif k == "kSliceStatic":
                hi, lo = (attrs[key]["v"] for key in ("sliceEnd", "sliceStart"))
                if hi - lo + 1 != w:
                    raise Unsupported("slice width")
                rhs = f"((_ extract {hi} {lo}) {a(0)})"
            elif k == "kReplicate":
                if w % gr.width[ins[0]]:
                    raise Unsupported("replicate width")
                rhs = f"((_ repeat {w // gr.width[ins[0]]}) {a(0)})"
            else:
                if cone_stable(v):
                    return atom(v, w)
                raise Unsupported(f"{k} on {'post' if side else 'pre'} side")
            return define(w, rhs)

        old_enable, old_data, old_mask, *event = original["in"]
        if not (pre.width[old_mask] == pre.width[old_data] == word):
            raise Unsupported("original widths")
        enabled = truth(expr(0, old_enable), pre.width[old_enable])
        payload = expr(0, old_data)
        mask = expr(0, old_mask)
        hits = []
        selected = literal(0, word)
        for p in writes:
            gate, addr, data, m, *ev = p["in"]
            if event != ev or p["attrs"]["eventEdge"] != original["attrs"]["eventEdge"]:
                raise Unsupported("write events")
            if post.width[m] != word or post.width[data] != word:
                raise Unsupported("port widths")
            port_mask = expr(1, m)
            hit = f"h{len(decl)}"
            decl.append(f"(define-fun {hit} () Bool (and (= {expr(1, addr)} {literal(row, post.width[addr])}) "
                        f"(= {truth(expr(1, gate), post.width[gate])} #b1)))")
            hits.append(hit)
            # A write changes only the bits selected by its own mask. Name each step to keep the query linear.
            step = f"s{len(decl)}"
            decl.append(f"(define-fun {step} () (_ BitVec {word}) (ite {hit} (bvor (bvand {expr(1, data)} {port_mask}) "
                        f"(bvand {selected} (bvnot {port_mask}))) {selected}))")
            selected = step
        any_hit = f"(or {' '.join(hits)})" if len(hits) > 1 else hits[0]
        differs = (f"(or (distinct (= {enabled} #b1) {any_hit}) "
                   f"(and (= {enabled} #b1) (distinct (bvand {payload} {mask}) (bvand {selected} {mask}))))")
        query = "\n".join(["(set-logic QF_BV)", "(set-option :timeout 30000)", *decl,
                           f"(assert {differs})", "(check-sat)"])
        ctx = cw.context(cw.config)
        answer = cw.evaluate(ctx, query.encode()).decode().strip()
        cw.destroy(ctx)
        stats["rows"] += 1
        stats["atoms"] = max(stats["atoms"], len(leaves))
        if answer == "unsat":
            stats["unsat"] += 1
        else:
            stats.setdefault("first_non_unsat", (row, answer[:40]))
            if mutate is None and "saved" not in stats:
                (here / f"failed-{g['group']}-row{row}.smt2").write_text(query)
                stats["saved"] = True
            if mutate is not None:
                break   # one witness is enough for a mutation
    stats["ports"] = len(writes)
    stats["fill"] = False
    stats["width"] = word
    return stats
