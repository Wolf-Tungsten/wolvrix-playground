"""Count direct guard terms across enabled scalar writes in the input checkpoint."""
from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
from checkpoint_source import Checkpoint, pre_path

here = Path(__file__).resolve().parent

groups = [g for l in (here.parent/'armor-xs-shared-guards-v1/replay-groups.jsonl').open()
          if (g := json.loads(l)).get('normalized_match') == 'family_mismatch']
graph = Checkpoint(pre_path,{w[1] for g in groups for w in g['writes']},set())
symbols = list(graph.width)

@lru_cache(None)
def leaves(v, gate):
    op = graph.op(v)
    if op.get('kind') == 'kAssign':
        return leaves(op['in'][0],gate)
    if op.get('kind') in ('k'+gate,'kLogic'+gate) and graph.width[v] == 1:
        return frozenset().union(*(leaves(i,gate) for i in op['in']))
    return frozenset([v])

for g in groups:
    count = Counter()
    all_count = Counter()
    first_paths = {}
    blocker_names = {symbols[b['value']-1] for b in g['normalized_blockers'] if 'common' in b['role']}
    for _,sym,_ in g['writes']:
        update = graph.writes[sym]['in'][0]
        terms = set()
        for guard in leaves(update,'Or'):
            terms.update(leaves(guard,'And'))
        count.update(terms)
        stack=[(update,())]
        seen=set()
        while stack:
            v,path=stack.pop()
            if v in seen: continue
            seen.add(v)
            op=graph.op(v); k=op.get('kind')
            if v in blocker_names: first_paths.setdefault(v,path+(k,))
            if k in ('kAnd','kOr','kLogicAnd','kLogicOr','kAssign') and graph.width[v]==1:
                stack.extend((i,path+(k,)) for i in op['in'])
        all_count.update(seen & blocker_names)
    blockers = []
    for b in g['normalized_blockers']:
        if 'common' in b['role']:
            v=symbols[b['value']-1]
            blockers.append((b['role'],v,count[v],all_count[v], first_paths.get(v)))
    print(g['group'],g['members'],blockers,flush=True)
