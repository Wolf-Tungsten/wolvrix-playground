# TNO0036 复现

在主仓根目录操作。归档包含证明、计时和复算脚本，本轮完整的 `groups.jsonl`，以及 `evidence/` 下的逐行分段证明、删口反例结果与验证日志。工作区提供 TNO0030 的调度前检查点、TNO0033 的组报告、基线二进制与参考轨迹，以及 TNO0028 的原始构建命令。整机实验还用到原固件、NEMU、Clang 和 NUMA 工具。

可在 `build/` 下新建独立的同级目录，用归档中的组报告及冻结的变换后 GRH 核对三行和一个反例。正常模式会重新求解全部 1,280 行。

~~~sh
case_dir=$(mktemp -d "$PWD/build/row-predicate-repro.XXXXXX")
tar -xzf pdocs/armor_grhsim/data/TNO0036_shared_row_predicate_repro.tar.gz -C "$case_dir" --strip-components=1
ln -s "$PWD/build/armor-xs-row-conflicts-v1/post.json" "$case_dir/post.json"
python3 "$case_dir/run_proof.py" probe
~~~

## 图与证明

在更新后的 Wolvrix 源码上构建 Python 绑定并重放相同检查点。独立复现时使用新目录，以免覆盖已有计时产物。证明脚本每次重新向系统 libz3 提交所选行的查询。正常模式检查全部恢复行，drop 模式在每组第 0 行删去一个写口并要求得到反例，probe 模式只检查三行及一个删口反例。

~~~sh
case_dir=$(mktemp -d "$PWD/build/row-predicate-replay.XXXXXX")
tar -xzf pdocs/armor_grhsim/data/TNO0036_shared_row_predicate_repro.tar.gz -C "$case_dir" --strip-components=1
tool_dir="$PWD/build/armor-dispatch-v1/tools"
export PYTHONPATH="$tool_dir/python" LD_LIBRARY_PATH="$tool_dir"
ulimit -s unlimited
cmake --build "$tool_dir" -j8 --target wolvrix_python transform-reg-to-mem
ctest --test-dir "$tool_dir" --output-on-failure -R '^transform-reg-to-mem$'
python3 scripts/armor_xs_gap_diagnostics/replay_reg_to_mem.py \
  build/armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json "$case_dir/groups.jsonl" \
  --normalize-write-conflicts --share-write-guards --output-checkpoint "$case_dir/post.json"
python3 "$case_dir/row_terms.py"
python3 "$case_dir/blocker_graph.py"
python3 "$case_dir/run_proof.py" all
python3 "$case_dir/run_proof.py" drop
python3 "$case_dir/no_report.py" > "$case_dir/no-report.log" 2>&1
~~~

## 整机对照

`build_model.py` 沿用原模型生成和 PGO 构建参数，在本轮目录训练新的站点与 Clang profile。在 node029 上核对短窗口和完整 MicroBench。在 node030 上运行两个计时命令，每组同核换序八轮。八轮齐全后，archive.py 逐项核对写口清单、证明结果、性能计数器、二进制、guest 终点和 DiffTest 轨迹，再写入文档目录的 CSV 与 JSON。两个负载各自的计时命令可以单独运行。

~~~sh
python3 "$case_dir/build_model.py" emit pgo
python3 "$case_dir/verify_model.py"
python3 "$case_dir/verify_model.py" long
python3 "$case_dir/measure.py" main coremark 104 reference candidate --rounds 8
python3 "$case_dir/measure.py" main microbench 120 reference candidate --rounds 8
python3 "$case_dir/archive.py"
~~~
