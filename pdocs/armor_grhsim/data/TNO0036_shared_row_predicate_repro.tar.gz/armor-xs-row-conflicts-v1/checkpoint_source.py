"""Indexed GRH checkpoint reader and libz3 bindings for the row proof."""
import ctypes as C
from ctypes.util import find_library
from functools import lru_cache
import json
import mmap
from pathlib import Path
import re
import sys

here = Path(__file__).resolve().parent
root = here.parents[1]
pre_path = root / "build/armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json"
z3 = C.CDLL(find_library("z3"))


def function(name, result, *args):
    fn = getattr(z3, "Z3_" + name)
    fn.argtypes = args
    fn.restype = result
    return fn


ptr = C.c_void_p
config = function("mk_config", ptr)()
context = function("mk_context", ptr, ptr)
destroy = function("del_context", None, ptr)
evaluate = function("eval_smtlib2_string", C.c_char_p, ptr, C.c_char_p)


class Checkpoint:
    def __init__(self, path, regs, memories):
        # Pretty-compact GRH has one value or operation per line. Index symbol and offset
        # only. Parse complete JSON records on demand, including attrs and edge identity.
        self.width = {}
        self.signed = set()
        self.defs = {}
        self.writes = {}
        self.ports = {m: [] for m in memories}
        self.memory = {}
        f = path.open("rb")
        self.data = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        self.data.seek(self.data.find(b'      "vals": ['))
        while line := self.data.readline():
            if line.startswith(b'      "ports"'):
                break
            m = re.match(rb'        \{"sym": "([^"\\]+)", "w": (\d+), "sgn": (true|false),', line)
            if m:
                name = m[1].decode()
                self.width[name] = int(m[2])
                if m[3] == b"true": self.signed.add(name)
        self.data.seek(self.data.find(b'      "ops": [', self.data.tell()))
        while True:
            pos = self.data.tell()
            line = self.data.readline()
            if not line or line.startswith(b'      ]'):
                break
            at = line.find(b', "out": [')
            if at < 0:
                continue
            end = line.index(b']', at)
            outputs = line[at+10:end]
            if outputs:
                if b'\\' in outputs or b'", "' in outputs:
                    for value in json.loads(b'[' + outputs + b']'):
                        self.defs[value] = pos
                else:
                    self.defs[outputs[1:-1].decode()] = pos
                continue
            if b'"kind": "kRegisterWritePort"' in line:
                sym = line.split(b'"', 4)[3].decode()
                if sym in regs:
                    self.writes[sym] = json.loads(line.rstrip(b',\n'))
            elif b'"kind": "kMemory' in line:
                op = json.loads(line.rstrip(b',\n'))
                if op["sym"] in memories:
                    self.memory[op["sym"]] = op
                elif op["kind"] in ("kMemoryWritePort", "kMemoryFillPort"):
                    mem = op["attrs"]["memSymbol"]["v"]
                    if mem in memories:
                        self.ports[mem].append(op)

    @lru_cache(maxsize=262144)
    def op(self, value):
        pos = self.defs.get(value)
        if pos is None:
            return {}
        self.data.seek(pos)
        return json.loads(self.data.readline().rstrip(b',\n'))


def literal(n, w):
    return f"(_ bv{n % (1 << w)} {w})"


def width_cast(e, old, new, signed=False):
    if old == new: return e
    if old < new: return f"((_ {'sign_extend' if signed else 'zero_extend'} {new-old}) {e})"
    return f"((_ extract {new-1} 0) {e})"


def memory_name(g):
    return "rtm_mem$" + re.sub("[^a-zA-Z0-9_]", "_", g["writes"][0][2])
