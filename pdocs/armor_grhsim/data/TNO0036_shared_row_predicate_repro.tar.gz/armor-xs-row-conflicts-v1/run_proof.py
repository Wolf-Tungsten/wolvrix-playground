"""Check changed write families over complete rows, using identical upstream definitions."""
import json
import multiprocessing
import resource
import sys
from pathlib import Path

import prove

here = Path(__file__).resolve().parent
groups = [g for line in (here/'groups.jsonl').open()
          if (g := json.loads(line)).get('shared_predicate_retry') == 'matched' and g['outcome'] == 'converted']


def run(task):
    group, first, last, mutation = task
    path = here/'proof'/f"{group['group']}-{first}-{last}-{mutation or 'base'}.json"
    result = prove.solve_group(group, prove.PRE, prove.POST, mutate=mutation, row_ids=range(first,last))
    result.update(group=group['group'], first=first, end=last, mutation=mutation)
    path.write_text(json.dumps(result)+'\n')
    return result


if __name__ == '__main__':
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    (here/'proof').mkdir(exist_ok=True)
    mode = sys.argv[1] if len(sys.argv)>1 else 'all'
    if mode not in ('all', 'probe', 'drop'):
        raise SystemExit('Expected all, probe, or drop')
    regs = {op for g in groups for _,op,_ in g['writes']}
    mems = {prove.cw.memory_name(g) for g in groups}
    prove.PRE = prove.cw.Checkpoint(prove.cw.pre_path, regs, set())
    prove.POST = prove.cw.Checkpoint(here/'post.json', set(), mems)
    assert len(regs)==sum(g['members'] for g in groups) and set(prove.POST.memory)==mems
    def full_mask(graph, mask, width):
        assert graph.width[mask] == width
        const = graph.op(mask)['attrs']['constValue']['v']
        m = prove.CONST.fullmatch(const.replace('_',''))
        assert m and int(m[4],{'b':2,'o':8,'d':10,'h':16}[m[3].lower()])%(1<<width)==(1<<width)-1
    for g in groups:
        mem=prove.cw.memory_name(g)
        width = prove.POST.memory[mem]['attrs']['width']['v']
        for p in prove.POST.ports[mem]:
            assert p['kind']=='kMemoryWritePort'
            full_mask(prove.POST,p['in'][3],width)
            assert all(prove.cone_stable(clock) for clock in p['in'][4:])
        for _,op,_ in g['writes']:
            full_mask(prove.PRE,prove.PRE.writes[op]['in'][2],width)
    print('Indexed',len(groups),'groups',len(regs),'rows',flush=True)
    tasks = [(g,i,min(g['members'],i+10),None) for g in groups for i in range(0,g['members'],10)]
    if mode=='probe':
        tasks=[(groups[0],0,1,None),(groups[0],1,2,None),(groups[0],159,160,None),(groups[0],0,1,'drop')]
    elif mode=='drop':
        tasks=[(g,0,1,'drop') for g in groups]
    with multiprocessing.get_context('fork').Pool(8) as pool:
        for r in pool.imap_unordered(run,tasks):
            print(r['group'],r['first'],r['mutation'],r['unsat'],r.get('first_non_unsat'),flush=True)
            if r['mutation'] is None and r['unsat']!=r['end']-r['first']:
                raise RuntimeError(r)
            if r['mutation'] == 'drop' and tuple(r.get('first_non_unsat', ())) != (0, 'sat'):
                raise RuntimeError(r)
