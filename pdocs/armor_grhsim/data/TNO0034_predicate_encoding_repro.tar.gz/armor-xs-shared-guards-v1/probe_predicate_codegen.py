"""Compile the actual commit shard with fixed site decisions and compare predicate encodings."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib, json, re, shlex, shutil, subprocess, sys

case=Path(__file__).resolve().parent
root=case.parents[1]
sys.path.insert(0,str(root/'scripts'))
from grhsim_change_sites import ChangeSites

model=case/'model'
work=case/'predicate-codegen'
work.mkdir(exist_ok=True)
marker=b'// Demand-evaluate terminal priority mux under its commit guard.'
sources=[f for f in sorted(model.glob('*_sched_*.cpp')) if marker in f.read_bytes()]
assert len(sources)==1
src=sources[0]; raw=src.read_bytes(); lines=raw.splitlines(keepends=True)
indices=[i+1 for i,l in enumerate(lines) if marker in l]
assert len(indices)==2112
# Reuse the logged final compiler invocation, with only input, output and PCH location adjusted.
log=(case/'resumed-pgo.log').read_text().splitlines()
argv=next(shlex.split(l) for l in reversed(log) if l.startswith('/') and ' -fprofile-use=' in l and (' -c '+src.name+' ') in l)
cc=argv[0]; flags=argv[1:argv.index('-c')]; pi=flags.index('-include-pch'); del flags[pi:pi+2]
flags=[('-fprofile-use='+str(case/'build/grhsim.profdata')) if f.startswith('-fprofile-use=') else f for f in flags]
# Derive precisely the existing site header from the original model and profile.
import gzip
header=src.with_suffix('.sites.h').name
with gzip.open(case/'build/grhsim-sites.tsv.gz','rt') as prof:
 version,digest,cycles=prof.readline().split();cycles=int(cycles)
 for record in prof:
  fn,count=record.split(); entries=[prof.readline() for _ in range(int(count))]
  if fn==src.name: break
 else:raise RuntimeError(src.name)
macros=[]
for line in entries:
 kind,number,n,c=line.split();n,c=int(n),int(c)
 if (kind=='SPARSE' and n>=max(1,cycles//4) and 1000*c<=5*n) or (kind=='EAGER' and n>=max(1,cycles//100) and 5*c>=n): macros.append('#define GRHSIM_'+kind+'_'+number+' 1')

def run(tag):
 d=work/tag;d.mkdir(exist_ok=True);(d/header).write_text('\n'.join(macros)+'\n')
 output=lines.copy(); n=0
 for i in indices:
  assert b' = static_cast<' in lines[i];n+=lines[i].count(b' && ')+lines[i].count(b' || ')
  if tag=='eager': output[i]=lines[i].replace(b' && ',b' & ').replace(b' || ',b' | ')
 (d/src.name).write_bytes(b'#include "'+header.encode()+b'"\n'+b''.join(output))
 # A changed instrumentation CFG may reject the original profile. Never treat it as a valid fixed-profile control.
 command=[cc,*flags,'-Werror=profile-instr-out-of-date','-Werror=profile-instr-unprofiled','-I',str(model),'-c',src.name,'-o','shard.o']
 with (d/'compile.log').open('w') as stream: rc=subprocess.run(command,cwd=d,stdout=stream,stderr=subprocess.STDOUT).returncode
 report={'variant':tag,'changed_assignments':len(indices) if tag=='eager' else 0,'boolean_operators':n,'returncode':rc,'command':command}
 if not rc:
  obj=d/'shard.o'; size=subprocess.check_output([str(Path(cc).with_name('llvm-size')),'-A',str(obj)],text=True);report['text_bytes']=sum(int(l.split()[1]) for l in size.splitlines() if l.startswith('.text ' ) or l.startswith('.text.'))
 else: report['diagnostic']=(d/'compile.log').read_text()[:1400]
 return report
with ThreadPoolExecutor(2) as pool: rows=list(pool.map(run,['reference','eager']))
(work/'result.json').write_text(json.dumps(rows,indent=2)+'\n')
print([(x['variant'],x['returncode'],x.get('text_bytes'),x.get('diagnostic','')[:180]) for x in rows])
