"""Control the entire link, holding the TNO0033 sites and Clang profile fixed."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

case = Path(__file__).resolve().parent
base = case.parent / 'armor-xs-shared-guards-v1'
root = case.parents[1]
sys.path.insert(0, str(root / 'scripts'))
from grhsim_change_sites import ChangeSites
from grhsim_single_baseline import clean_environment

model = case/'model'; model.mkdir(exist_ok=True)
profile = base/'build/grhsim.profdata'
old = json.loads((base/'resumed-pgo.command.json').read_text())['argv']
settings = dict(arg.split('=', 1) for arg in old if '=' in arg)
environment = dict(clean_environment(), NOOP_HOME=str(root/'testcase/xiangshan'))
make_line = next(l for l in (base/'resumed-pgo.log').read_text().splitlines() if l.startswith('make -C ') and 'PGO_CFLAGS=-fprofile-use=' in l)
command = []
for arg in shlex.split(make_line):
    if arg.startswith('BUILD_DIR='): arg = f'BUILD_DIR={case}/link'
    if arg.startswith('GRHSIM_MODEL_DIR='): arg = f'GRHSIM_MODEL_DIR={model}'
    if '-fprofile-use=' in arg:
        prefix = arg.split('-fprofile-use=', 1)[0]
        arg = prefix + '-fprofile-use=' + str(profile)
    command.append(arg)
command.extend(f'{k}={settings[k]}' for k in ('CC','CXX','AR','EMU_RANDOMIZE','EMU_THREADS','NO_DIFF','GRHSIM_MODEL_BUILD_JOBS','EMU_TRACE'))
command += ['EMU_OPTIMIZE=-O3 -march=native']
(case/'link-command.json').write_text(json.dumps(command,indent=2)+'\n')

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def link(tag):
    with (case/f'{tag}-link.log').open('w') as log:
        subprocess.run(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT,check=True)
    destination=case/tag/'build';destination.mkdir(parents=True,exist_ok=True)
    shutil.copy2(case/'link/grhsim-compile/emu',destination/'emu')

# A completed pair is immutable; verify the stored inputs before reusing it.
identity_file = case/'identity.json'
if identity_file.exists():
    result = json.loads(identity_file.read_text())
    if (digest(profile) != result['profile_sha256'] or
        digest(base/'build/grhsim-sites.tsv.gz') != result['sites_sha256'] or
        digest(base/'build/emu') != result['frozen_sha256'] or
        any(digest(case/tag/'build/emu') != sha for tag, sha in result['binaries'].items())):
        raise RuntimeError('Recorded identity differs; use a fresh experiment directory')
    print(json.dumps(result, indent=2))
    sys.exit(0)

if (case/'reference/build/emu').exists():
    raise RuntimeError('Partial build without a recorded identity; preserve it and use a fresh directory')
else:
    for src in sorted((base/'model').iterdir()):
        if src.name=='Makefile' or src.suffix in ('.cpp','.h','.hpp'): shutil.copyfile(src,model/src.name)
    sites=ChangeSites(model,case)
    selected=sites.specialize(base/'build/grhsim-sites.tsv.gz','both',5)
    assert selected=={'SPARSE':120449,'EAGER':16040},selected
    link('reference')
# Use the two previously checked encodings. Discover the affected file from the comparison.
probe=base/'predicate-codegen'
reference,=list((probe/'reference').glob('*.cpp'))
source=model/reference.name
assert digest(source)==digest(reference)
replacement=probe/'eager'/reference.name
assert digest(model/reference.with_suffix('.sites.h').name)==digest(probe/'eager'/reference.with_suffix('.sites.h').name)
before={o.name:digest(o) for o in model.glob('*.o')}
shutil.copyfile(replacement,source)
link('eager')
after={o.name:digest(o) for o in model.glob('*.o')}
diff=[n for n in sorted(before) if before[n]!=after[n]]
assert diff==[source.with_suffix('.o').name] and before.keys()==after.keys(),diff
print(json.dumps(dict(objects=len(before),changed=diff,profile_sha256=digest(profile),sites_sha256=digest(base/'build/grhsim-sites.tsv.gz'),binaries={k:digest(case/k/'build/emu') for k in ('reference','eager')},frozen_sha256=digest(base/'build/emu')),indent=2),flush=True)
