"""Recompute the paired statistics using only the published TNO0034 CSV."""
import csv
import math
import statistics
import sys
from pathlib import Path

with Path(sys.argv[1]).open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 32
for workload in sorted({r['workload'] for r in rows}):
    pairs = {}
    for r in rows:
        if r['workload'] == workload:
            variants = pairs.setdefault(int(r['round']), {})
            assert r['variant'] not in variants
            variants[r['variant']] = r
    assert set(pairs) == set(range(1, 9))
    difference = []
    for i, pair in sorted(pairs.items()):
        old, new = pair['reference'], pair['eager']
        assert old['pc'] == new['pc'] and old['guest_cycles'] == new['guest_cycles'] == '100001'
        pct = 100 * (float(new['wall_s']) / float(old['wall_s']) - 1)
        difference.append(pct)
    mean = statistics.mean(difference)
    margin = 2.3646242516 * statistics.stdev(difference) / math.sqrt(len(difference))
    print(workload, 'wall %', round(mean, 4), '95% interval', [round(x, 4) for x in (mean-margin, mean+margin)],
          'faster', sum(x < 0 for x in difference), '/', len(difference))
