# TNO0034 复现

从主仓根目录操作。解包后脚本位于 build/armor-xs-predicate-encoding-v1。上下文为 TNO0033 两项同开的模型，包含其生成源码、站点计数、Clang profile、make 日志、冻结模拟器和验证轨迹。构建还使用同一套香山、NEMU、Clang 和宿主机。对应文件的指纹见结果 JSON。逐写口活动交叉比对另用 build/armor-xs-site-pgo-v1 的 native/model 和 train-sites.tsv.gz，以及 build/armor-xs-value-paths-v1/sequence 的两个负载目录。输入模型、固件和大体积 trace 保存在工作区。

## 建立对照

在新的实验目录运行以下命令。若本地已有计时产物，保留现有目录，改用同级新目录存放本轮脚本和输出。probe 写到 TNO0033 的 predicate-codegen 子目录，仅在缺少该目录时运行。它扫描生成器的提交求值标记，核对变更行，按原编译参数分别编译两份源码。build_pair.py 从 TNO0033 复制模型，恢复同一套站点选择，链接参考版本，然后只更换受影响的源文件。请在已有训练产物的工程副本中运行。

~~~sh
case_dir=build/armor-xs-predicate-encoding-v1
base_dir=build/armor-xs-shared-guards-v1
if [ ! -f "$base_dir/predicate-codegen/result.json" ]; then
    python3 "$base_dir/probe_predicate_codegen.py"
fi
python3 "$case_dir/build_pair.py" > "$case_dir/identity.tmp" && mv "$case_dir/identity.tmp" "$case_dir/identity.json"
python3 "$case_dir/activity.py" > "$case_dir/activity.json"
~~~

## 运行与核对

先验证两个版本的功能。short 运行两种负载的 100,001 拍窗口。long 运行完整 MicroBench 并比较到 GOOD TRAP 的所有轨迹。计时另在 node030 上进行。两个负载分别占用核 104 和 120，各自换序运行 8 轮。脚本通过 rounds.json 从完整的配对轮次续跑。结果目录存于共享文件系统。

~~~sh
for tag in reference eager; do
    python3 "$case_dir/verify.py" "$tag" short
    python3 "$case_dir/verify.py" "$tag" long
done
python3 "$case_dir/measure.py" paired coremark 104 reference eager --rounds 8
python3 "$case_dir/measure.py" paired microbench 120 reference eager --rounds 8
python3 "$case_dir/archive.py"
~~~

archive.py 检查各样本的原始 perf.csv、二进制哈希、guest 终点、冻结轨迹摘要、PMU 运行比例及 SMT 兄弟核空闲率，然后生成文档目录中的 CSV 和 JSON。仅复算计时可直接运行同目录 summarize_csv.py 并传入归档的 CSV 路径。
