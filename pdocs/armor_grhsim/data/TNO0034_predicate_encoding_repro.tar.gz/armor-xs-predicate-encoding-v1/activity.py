"""Join each guarded assignment to its write visit in the same straight-line block."""
import gzip
import json
import re
import sys
from pathlib import Path

case = Path(__file__).resolve().parent
base = case.parent / 'armor-xs-shared-guards-v1'
marker = '// Demand-evaluate terminal priority mux under its commit guard.'
slot = r'(value_\w+_slots_\[\d+\])'
site_operators = {}
identities = {}
for source in sorted((base / 'model').glob('*_sched_*.cpp')):
    if marker.encode() not in source.read_bytes():
        continue
    with source.open() as lines:
        for line in lines:
            if line.strip() != marker:
                continue
            assignment = next(lines).strip()
            output = re.match(slot + r' = ', assignment)[1]
            # The two computations must run under the same guard; fail on any new branch.
            body = []
            for following in lines:
                if match := re.search(r'GRHSIM_COUNT_SITE\(R, (\d+), state_changed\);', following):
                    break
                assert not re.search(r'\b(if|else|return|break|continue|goto)\b|^\s*}', following), following
                body.append(following)
            else:
                raise ValueError('No write counter after demand assignment')
            assert any('const auto next_value =' in row and output in row for row in body)
            key = source.name, int(match[1])
            assert key not in site_operators
            write, = [m.groups() for row in body if (m := re.search(r'// op (\S+) \[kRegisterWritePort\] reg=(\S+)', row))]
            identities[key] = write
            site_operators[key] = assignment.count(' && ') + assignment.count(' || ')

activity = {}
with gzip.open(base / 'build/grhsim-sites.tsv.gz', 'rt') as profile:
    version, _, cycles = next(profile).split()
    assert version == 'grhsim-change-sites-v1'
    for group in profile:
        shard, count = group.split()
        for _ in range(int(count)):
            kind, number, visits, changes = next(profile).split()
            key = shard, int(number)
            if kind == 'EAGER' and key in site_operators:
                assert key not in activity
                activity[key] = int(visits), int(changes)
assert site_operators.keys() == activity.keys() and len(activity) == 2112
visits = sum(v for v, _ in activity.values())
report = dict(workload='coremark', training_limit=int(cycles), sites=len(activity),
              static_operators=sum(site_operators.values()), total_visits=visits,
              total_changes=sum(c for _, c in activity.values()),
              sites_visited=sum(v > 0 for v, _ in activity.values()),
              visits_per_training_cycle=visits/int(cycles),
              operator_occurrences_in_entered_expressions_per_training_cycle=
                  sum(site_operators[k]*v for k, (v, _) in activity.items())/int(cycles))
# Independent site sequences of the previous model use different numeric IDs.
# Match the full operation and destination pair, then compare every training counter.
sys.path.insert(0, str(case.parents[1] / 'scripts/armor_xs_gap_diagnostics'))
from rank_reg_to_mem import site_counts

previous = case.parent / 'armor-xs-site-pgo-v1'
ports = set(identities.values())
assert len(ports) == len(activity)
report['earlier_site_sequences'] = {}
for workload in ('coremark', 'microbench'):
    sequence = case.parent / 'armor-xs-value-paths-v1/sequence' / workload
    _, training_limit, counts, _ = site_counts(previous/'native/model', previous/'train-sites.tsv.gz',
                                               sequence, ports, workload == 'coremark')
    assert counts.keys() == ports and training_limit == int(cycles)
    if workload == 'coremark':
        for key, port in identities.items():
            assert (counts[port]['visits'], counts[port]['changes']) == activity[key]
    visits = sum(port['visits'] for port in counts.values())
    report['earlier_site_sequences'][workload] = dict(
        matched_ports=len(ports), total_visits=visits, total_changes=sum(port['changes'] for port in counts.values()),
        visits_per_guest_cycle=visits/100001)
print(json.dumps(report, indent=2))
