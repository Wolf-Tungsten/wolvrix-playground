"""Counterbalanced comparison of the two fixed-profile terminal predicate encodings."""
from pathlib import Path
import sys

case = Path(__file__).resolve().parent
sys.path.insert(0,str(case.parents[1]/'scripts/armor_xs_gap_diagnostics'))
import site_pairs

site_pairs.base = case
site_pairs.main()
