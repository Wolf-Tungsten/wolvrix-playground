"""Trace-check both whole simulators using the TNO0033 reference windows and good trap."""
import json
import re
import resource
import sys
from pathlib import Path

case = Path(__file__).resolve().parent
root = case.parents[1]
sys.path.insert(0, str(root/'scripts/armor_xs_gap_diagnostics'))
from diagnostics import IMAGES, NEMU, clean_environment, execute, pick_cpu, save
from grhsim_difftrace import compare_traces
from verify_sparse import verify_sparse

resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY,resource.RLIM_INFINITY))
tag, window = sys.argv[1:]
assert tag in ('reference','eager') and window in ('short','long')
variant = case/tag
binary = variant/'build/emu'
if window == 'short':
    verify_sparse(binary, variant/'verify')
else:
    folder = variant/'long'
    frozen = case.parent/'armor-xs-shared-guards-v1/long'
    cpu, _ = pick_cpu()
    execute(['taskset','-c',cpu,'numactl','--membind=1','setarch','x86_64','-R',binary,'-i',IMAGES['microbench'],
             '--diff',NEMU,'-b',0,'-e',0,'-s',0,'-C',250000,'--dump-difftrace','./trace'],'run',folder,clean_environment(),folder)
    log = re.sub(r'\x1b\[[0-9;]*m','',(folder/'run.log').read_text())
    assert all(mark in log for mark in ('HIT GOOD TRAP','MicroBench PASS','Difftest enabled'))
    sig = json.loads((frozen/'verified.json').read_text())
    for k, field in [('guest_cycles','Guest cycle spent: '),('cycle','cycleCnt = '),('instr','instrCnt = ')]:
        assert int(re.search(field+r'([\d,]+)',log)[1].replace(',','')) == sig[k]
    pc = re.search(r'HIT GOOD TRAP at pc = (0x\w+)',log)[1]
    assert pc == re.search(r'HIT GOOD TRAP at pc = (0x\w+)',(frozen/'run.log').read_text())[1]
    trace = compare_traces(case.parent/'armor-xs-pgo-v1/gsim/verify/comparator/compare',frozen/'trace',folder/'trace',folder/'trace.json')
    assert trace['pass_'] and (trace['records'],trace['last_cycle']) == (225599,sig['cycle'])
    assert all(chunk['a']['sha256']==chunk['b']['sha256'] for chunk in trace['chunks'])
    save(folder/'verified.json',{**{k:sig[k] for k in ('guest_cycles','cycle','instr')},'pc':pc,'trace':trace})
