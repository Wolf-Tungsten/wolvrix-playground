"""Verify frozen endpoints, perf records and binaries before archiving a paired run."""
import csv
import hashlib
import json
import math
import statistics as st
import subprocess
from pathlib import Path

case = Path(__file__).resolve().parent
base = case.parent / 'armor-xs-shared-guards-v1'
output = case.parents[1] / 'pdocs/armor_grhsim/data'
stem = 'TNO0034_predicate_encoding_'
tags = ('reference', 'eager')
events = ('instructions', 'cycles', 'branches', 'branch-misses', 'ex_ret_ops')


def read(path):
    return json.loads(path.read_text())


def hash_file(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for block in iter(lambda: stream.read(2**20), b''):
            h.update(block)
        return h.hexdigest()


def section(path, name):
    headers = subprocess.check_output(['readelf', '-SW', path], text=True).splitlines()
    row, = [line.split() for line in headers if f' {name} ' in line]
    index = row.index(name)
    offset, size = [int(n, 16) for n in row[index+3:index+5]]
    with path.open('rb') as stream:
        stream.seek(offset)
        data = stream.read(size)
    assert len(data) == size
    return {'bytes': size, 'sha256': hashlib.sha256(data).hexdigest()}


def trace(fresh, frozen):
    assert fresh['pass_'] and frozen['pass_']
    assert fresh['records'] == frozen['records'] and fresh['last_cycle'] == frozen['last_cycle']
    def chunks(result):
        return [(c['name'], c['records'], c['b']['bytes'], c['b']['sha256']) for c in result['chunks']]
    assert chunks(fresh) == chunks(frozen)
    assert all(c['a']['sha256'] == c['b']['sha256'] for c in fresh['chunks'])
    return dict(records=fresh['records'], last_cycle=fresh['last_cycle'], chunks=chunks(fresh))


def stats(values):
    assert len(values) == 8
    mean = st.mean(values)
    radius = 2.3646242516 * st.stdev(values) / math.sqrt(len(values))
    return dict(mean=mean, minimum=min(values), maximum=max(values),
                paired_95_t=[mean-radius, mean+radius], negative=sum(x<0 for x in values))


def whole_build():
    ident = read(case/'identity.json')
    assert hash_file(base/'build/grhsim.profdata') == ident['profile_sha256']
    assert hash_file(base/'build/grhsim-sites.tsv.gz') == ident['sites_sha256']
    for tag in (*tags, 'frozen'):
        binary = (base if tag == 'frozen' else case/tag) / 'build/emu'
        sha = ident['frozen_sha256'] if tag == 'frozen' else ident['binaries'][tag]
        assert hash_file(binary) == sha
        ident.setdefault('text', {})[tag] = section(binary,'.text')
    assert ident['text']['frozen'] == ident['text']['reference']
    assert len(ident['changed']) == 1
    shard = read(base/'predicate-codegen/result.json')
    assert all(x['returncode'] == 0 for x in shard)
    ident['shard_text_bytes'] = {x['variant']:x['text_bytes'] for x in shard}
    return ident


def validate_sample(record, signature, cpu, sha):
    assert record['binary']['sha256'] == sha
    assert all(record[k] == v for k,v in signature.items())
    folder = case/record['path']
    raw = read(folder/'sample.json')
    assert all(record[k] == v for k,v in raw.items())
    with (folder/'perf.csv').open() as stream:
        counters = {f[2].removesuffix(':u'): (int(f[0]), float(f[4])) for f in csv.reader(stream)
                    if len(f)>4 and f[2].removesuffix(':u') in events}
    assert set(counters) == set(events)
    for k,(count,running) in counters.items():
        assert count == record['counts'][k] and running == record['counter_running_pct'][k]
    sibling = min(v for k,v in record['sibling_idle'].items() if int(k) != cpu)
    running = min(record['counter_running_pct'].values())
    assert record['cpu_fraction'] >= .97 and running >= 98 and sibling >= 98
    return dict(binary_sha256=sha, cpu=cpu, guest_cycles=record['guest_cycles'], pc=record['pc'],
                arch_cycles=record['cycle_count'], guest_instructions=record['instr_count'],
                difftest=record['runtime_difftest'], stop=record['stop_reason'], wall_s=record['external_wall_s'],
                **record['counts'], cpu_fraction=record['cpu_fraction'], min_running_pct=running,
                sibling_idle_pct=sibling, source=record['path'])


identity = whole_build()
report = dict(build=identity, coremark_site_activity=read(case/'activity.json'), workloads={}, verification={})
samples = []
for wl, cpu in [('coremark',104), ('microbench',120)]:
    frozen = base/'verify'/wl
    reference = read(frozen/'result.json')
    signature = reference['signature']
    assert signature['guest_cycles'] == 100001 and signature['runtime_difftest'] == 'on'
    for tag in tags:
        folder = case/tag/'verify'/wl
        assert read(folder/'result.json') == reference
        verification = report['verification'].setdefault(tag, {})
        verification[wl] = dict(signature=signature, counter_lines=reference['counter_lines'],
                                trace=trace(read(folder/'trace.json'), read(frozen/'trace.json')))
    rounds = read(case/'pairs/paired'/wl/'rounds.json')
    assert len(rounds) == 8 and sum(r['order'][0]=='reference' for r in rounds)==4
    wall_pct, cycle_pct, differences = [], [], {k:[] for k in events}
    for number, r in enumerate(rounds,1):
        assert r['cpu'] == cpu and set(r['order']) == set(tags)
        for position, tag in enumerate(r['order'],1):
            sample = validate_sample(r[tag], signature, cpu, identity['binaries'][tag])
            samples.append(dict(workload=wl, round=number, position=position, variant=tag, **sample))
        old, new = (r[tag] for tag in tags)
        wall_pct.append(100*(new['external_wall_s']/old['external_wall_s']-1))
        cycle_pct.append(100*(new['counts']['cycles']/old['counts']['cycles']-1))
        for event in events:
            differences[event].append((new['counts'][event]-old['counts'][event])/signature['guest_cycles'])
    report['workloads'][wl] = dict(wall_pct=stats(wall_pct), cycles_pct=stats(cycle_pct),
        wall_order_mean_pct={tag:st.mean(d for d,r in zip(wall_pct,rounds) if r['order'][0]==tag) for tag in tags},
        event_difference_per_guest_cycle={k:stats(v) for k,v in differences.items()})

frozen = read(base/'long/verified.json')
for tag in tags:
    result = read(case/tag/'long/verified.json')
    assert all(result[k]==frozen[k] for k in ('guest_cycles','cycle','instr'))
    report['verification'][tag]['microbench_full'] = dict(
        guest_cycles=result['guest_cycles'], pc=result['pc'], guest_instructions=result['instr'],
        trace=trace(result['trace'], frozen['trace']))
assert len(samples)==32
report['sample_quality'] = {name:min(s[name] for s in samples) for name in ('min_running_pct','sibling_idle_pct','cpu_fraction')}
with (output/(stem+'samples.csv')).open('w', newline='') as f:
    writer=csv.DictWriter(f, fieldnames=list(samples[0]),lineterminator='\n')
    writer.writeheader()
    writer.writerows(samples)
(output/(stem+'results.json')).write_text(json.dumps(report,indent=2)+'\n')
for wl,r in report['workloads'].items():
    print(wl, r['wall_pct'], {k:round(v['mean'],2) for k,v in r['event_difference_per_guest_cycle'].items()})
