"""Aggregate the exclusive-upstream evaluations per group for one workload (diagnostic)."""
import gzip
import json
import struct
import sys
from collections import Counter, defaultdict
from pathlib import Path

root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
import rank_reg_to_mem as rank  # noqa: E402

workload = sys.argv[1]
owners = {int(k): v for k, v in json.load(gzip.open(here / "exclusive-sites.json.gz", "rt")).items()}
prof = root / "build/armor-xs-site-pgo-v1"
digest, inventory = rank.model_sites(prof / "native/model")
record = struct.Struct("=4I")
visits = Counter(); changes = Counter(); all_visits = 0
with gzip.open(prof / "train-sites.tsv.gz","rt") as training:
    version, expected, length = next(training).split()
    assert version == "grhsim-change-sites-v1" and digest == expected and int(length) == 100000
    for name, (sites, _) in inventory.items():
        assert next(training).split() == [name,str(len(sites))]
        raw = (root / f"build/armor-xs-value-paths-v1/sequence/{workload}" / (Path(name).stem + ".bin")).read_bytes()
        assert len(raw) == record.size * len(sites), name
        for (kind, number), (n, c, _, _) in zip(sites, record.iter_unpack(raw)):
            tag, site, tn, tc = next(training).split()
            assert (kind, number) == (tag, int(site)) and c <= n
            if workload == "coremark": assert (int(tn), int(tc)) == (n, c)
            if kind == "SPARSE":
                visits[number] += n; changes[number] += c; all_visits += n
    assert not training.readline()
role = {1: "enable", 2: "data", 3: "both"}
groups = defaultdict(Counter); total = Counter(all_compute_site_visits=all_visits)
for v, (roles, gs) in owners.items():
    n, c = visits[v], changes[v]
    total["visits"] += n; total["changes"] += c; total["visits_" + role[roles]] += n; total["values"] += 1
    if gs is None:
        total["visits_many_groups"] += n
        continue
    for g in gs:
        r = groups[g]
        r["visits"] += n / len(gs); r["changes"] += c / len(gs); r["visits_" + role[roles]] += n / len(gs); r["values"] += 1
(here / f"upstream-{workload}.json").write_text(json.dumps(dict(total=dict(total), groups={str(k): dict(v) for k, v in groups.items()})))
N = 100001
print(workload, {k: (round(v / N, 1) if "visits" in k or k == "changes" else v) for k, v in total.items()})
