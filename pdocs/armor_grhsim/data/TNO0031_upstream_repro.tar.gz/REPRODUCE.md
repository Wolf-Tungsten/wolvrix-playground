# TNO0031 复现

在 ARMOR 仓库下将本包解至 `build/armor-xs-upstream-v1`，将 TNO0030 归档的 `TNO0030_reg_to_mem_groups.jsonl.gz` 解压至该目录的 `groups-64.jsonl`。脚本从相邻目录读取 TNO0026 的调度图和覆盖、TNO0027 的模型和训练清单，以及 TNO0028 的两份访问序列。

```bash
cd build/armor-xs-upstream-v1
python3 upstream_cones.py
for wl in coremark microbench; do
  python3 upstream_summary.py "$wl"
  python3 per_group_activity.py "$wl"
done
python3 guard_checks.py coremark
python3 summarize.py
```

归属程序遍历全部 7,768,578 个操作并校验所有目标端口。一个值在一个分片被多次执行时计入每次求值。共享值在最多 64 个目标组之间等分；更大的集合保留在全设计总数中。每组的 ID、访问和变化次数在两份 `upstream-*.json` 内，模型专属的模块和字段标签仅用于解释统计。
