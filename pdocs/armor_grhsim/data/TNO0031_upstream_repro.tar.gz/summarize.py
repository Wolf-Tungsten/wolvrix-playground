"""Aggregate per-group upstream counts and enabled writes for TNO0031."""
from collections import Counter, defaultdict
import json
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]
out = root / "pdocs/armor_grhsim/data"
rows = [json.loads(s) for s in (here/"groups-64.jsonl").read_text().splitlines()]
groups = {r["group"]:r for r in rows if r["outcome"] != "converted"}
result = {"guest_cycles":100001, **json.loads((here/"ownership.json").read_text()),
          "groups":len(groups), "workloads":{}}
for wl in ("coremark", "microbench"):
    upstream = json.loads((here/f"upstream-{wl}.json").read_text())
    enabled = json.loads((here/f"per-group-{wl}.json").read_text())
    writes = {r["group"]:r for r in enabled["groups"]}
    classes = defaultdict(Counter)
    sets = defaultdict(Counter)
    ranked = []
    for i,g in groups.items():
        measured = upstream["groups"].get(str(i), {})
        visits = measured.get("visits", 0)
        w = writes[i]
        counts = dict(groups=1, rows=g["members"], writes=w["visits"], upstream=visits,
                      changes=measured.get("changes",0))
        classes[g["consolidated_reject"]].update(counts)
        path = g["writes"][0][2].split("$")
        field = path[-1]
        if "rob" in path[:-1] or "inner_ftq" in path[:-1]:
            sets["rob_ftq"].update(counts)
        if "rob" in path[:-1] and field.startswith(("debug_lqIdx_", "debug_sqIdx_", "debug_exuData_")):
            sets["rob_triplet"].update(counts)
        if "inner_ftq" in path[:-1] and "cfiAttr" in field:
            sets["ftq_cfiAttr"].update(counts)
        ranked.append((i, visits))
    ranked.sort(key=lambda item:(-item[1],item[0]))
    total = upstream["total"]
    assigned = sum(r["upstream"] for r in classes.values())
    assert abs(total["visits"] - total["visits_many_groups"] - assigned) < 1
    result["workloads"][wl] = dict(total=total, assigned=assigned, classes=classes, fields=sets,
                                  top200=ranked[:200], top200_visits=sum(n for _,n in ranked[:200]))
    w = result["workloads"][wl]
    print(wl, {k:round(v["upstream"]/100001,1) for k,v in sets.items()},
          "top200 shares",round(w["top200_visits"]/assigned*100,2),
          round(w["top200_visits"]/total["visits"]*100,2))
result["coremark_outer_guard_checks_by_class"] = json.loads((here/"guard-checks-coremark.json").read_text())["classes"]
(out/"TNO0031_upstream_activity.json").write_text(json.dumps(result,indent=2)+"\n")
