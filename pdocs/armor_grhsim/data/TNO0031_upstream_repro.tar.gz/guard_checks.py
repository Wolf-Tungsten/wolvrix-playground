"""Count how often the write-enable guards of the reg-to-mem groups are evaluated (line coverage).

Complements the enabled-visit ranking: a visit is counted after the enable is true, a guard check before it.
Diagnostic only; write ports are joined by exact (operation, register) identity from the group report.
"""
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
import rank_reg_to_mem as rank  # noqa: E402
from source_categories import read_lcov  # noqa: E402

workload = sys.argv[1]
here = Path(__file__).resolve().parent
groups, ports = rank.load_groups(here / "groups-64.jsonl", "SimTop")
reason_of = {}
group_of = {}
for g in groups:
    reason = g["outcome"]
    if reason == "no_true_match" and g["consolidated_reject"]:
        reason = g["consolidated_reject"]
    for number, op, reg in g["writes"]:
        reason_of[op, reg] = reason
        group_of[op, reg] = g["group"]
indent = lambda row: len(row) - len(row.lstrip(b" "))
stats = defaultdict(Counter)
per_group = defaultdict(Counter)
seen_guard = defaultdict(set)
seen_group_guard = defaultdict(set)
for file, lines, _ in read_lcov(root / f"build/armor-xs-gap-current-v1/coverage/gr_pgo/{workload}/model.lcov"):
    path = Path(file)
    if "_sched_" not in path.name:
        continue
    rows = path.read_bytes().splitlines()
    stack = []  # open "if (...) {" lines as (indent, 1-based line, is_data_block)
    for i, row in enumerate(rows):
        body = row.strip()
        if not body or body.startswith(b"#"):
            continue
        level = indent(row)
        while stack and stack[-1][0] >= level:
            stack.pop()
        if body.startswith(b"if (") and body.endswith(b"{"):
            stack.append((level, i + 1, b"std::memcmp(std::as_bytes" in body))
            continue
        if b"[kRegisterWritePort] reg=" not in row:
            continue
        match = rank.WRITE.fullmatch(body)
        if not match:
            continue
        port = tuple(s.decode() for s in match.groups())
        if port not in reason_of:
            continue
        reason = reason_of[port]
        stats[reason]["ports_seen"] += 1
        guard = next((line for _, line, block in reversed(stack) if not block), None)
        in_block = any(block for _, _, block in stack)
        if guard is None or guard not in lines:
            stats[reason]["ports_without_guard"] += 1
            continue
        stats[reason]["ports_with_guard"] += 1
        stats[reason]["ports_in_data_block"] += int(in_block)
        key = (path.name, guard)
        if key not in seen_guard[reason]:
            seen_guard[reason].add(key)
            stats[reason]["guards"] += 1
            stats[reason]["guard_checks"] += lines[guard]
        gk = group_of[port]
        if key not in seen_group_guard[gk]:
            seen_group_guard[gk].add(key)
            per_group[gk]["guards"] += 1
            per_group[gk]["guard_checks"] += lines[guard]
out = dict(workload=workload, classes={k: dict(v) for k, v in stats.items()},
           groups={str(k): dict(v) for k, v in per_group.items()})
(here / f"guard-checks-{workload}.json").write_text(json.dumps(out))
for reason, row in sorted(stats.items(), key=lambda kv: -kv[1]["guard_checks"]):
    print(reason, dict(row))
