"""Per-group enabled-write activity for the reg-to-mem groups (diagnostic; names are used for display only).

Reuses the committed ranking script's readers, then keeps the per-port counts instead of class totals.
"""
import gzip
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
import rank_reg_to_mem as rank  # noqa: E402

workload = sys.argv[1]
here = Path(__file__).resolve().parent
groups, ports = rank.load_groups(here / "groups-64.jsonl", "SimTop")
prof = root / "build/armor-xs-site-pgo-v1"
digest, cycles, eager, ids = rank.site_counts(
    prof / "native/model", prof / "train-sites.tsv.gz",
    root / f"build/armor-xs-value-paths-v1/sequence/{workload}", ports, workload == "coremark")
coverage = rank.coverage_counts(root / f"build/armor-xs-gap-current-v1/coverage/gr_pgo/{workload}/model.lcov", ports)
rows = []
for group in groups:
    reason = group["outcome"]
    if reason == "no_true_match" and group["consolidated_reject"]:
        reason = group["consolidated_reject"]
    per_port = []
    for number, op, reg in group["writes"]:
        key = (op, reg)
        c = eager.get(key) or coverage.get(key)
        per_port.append(None if c is None else (c["visits"], c["changes"]))
    measured = [p for p in per_port if p is not None]
    regs = [w[2] for w in group["writes"]]
    rows.append(dict(group=group["group"], reason=reason, members=group["members"], ports=len(per_port),
                     measured=len(measured), visits=sum(p[0] for p in measured), changes=sum(p[1] for p in measured),
                     max_port_visits=max((p[0] for p in measured), default=0),
                     min_port_visits=min((p[0] for p in measured), default=0),
                     first=regs[0] if regs else "", last=regs[-1] if regs else ""))
(here / f"per-group-{workload}.json").write_text(json.dumps(dict(cycles=cycles, groups=rows)))
print(workload, "groups", len(rows), "cycles", cycles, "visits", sum(r["visits"] for r in rows))
