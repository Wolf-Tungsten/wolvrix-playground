"""Which compute values exist only to feed write ports of unconverted reg-to-mem groups, and how often are they evaluated?

Read-only diagnostic on existing dumps. A value is "exclusive" when every path from it ends in the enable or data
operand of a register write port that belongs to an unconverted group; any other sink makes it shared.
Groups and write ports are joined by exact (operation symbol, register symbol) identity; names are display only.
Evaluation counts are the per-value change-site visits of the TNO0027 training profile (CoreMark, 100,001 cycles).
"""
import gzip
import json
import mmap
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
stages = root / "build/armor-xs-gap-current-v1/audit/stages"
CAP = 64
t0 = time.time()
log = lambda *a: print(f"[{time.time() - t0:6.1f}s]", *a, flush=True)

# --- groups: unconverted write ports -> group index
groups = [json.loads(line) for line in (here / "groups-64.jsonl").open()]
reason_of_group = {}
port_group = {}
for g in groups:
    if g["outcome"] == "converted":
        continue
    reason_of_group[g["group"]] = g["consolidated_reject"] or g["outcome"]
    for _, op, reg in g["writes"]:
        port_group.setdefault((op, reg), g["group"])
log("unconverted groups", len(reason_of_group), "ports", len(port_group))

# --- ops
in_ptr = [0]; in_val = []; res_ptr = [0]; res_val = []
sink_group = {}      # op position -> group for matched write ports
is_other_sink = []   # op positions of sinks that are not such ports
observable_results = set()
matched = 0
with (stages / "after-clone.ops.tsv").open("rb") as stream:
    next(stream)
    pos = 0
    for raw in stream:
        f = raw.rstrip(b"\n").split(b"\t")
        if f[7]:
            in_val.extend(map(int, f[7].split(b",")))
        in_ptr.append(len(in_val))
        if f[8]:
            res_val.extend(map(int, f[8].split(b",")))
            if f[1] in (b"kDpicCall", b"kSystemFunction", b"kInstance", b"kBlackbox"):
                observable_results.update(map(int, f[8].split(b",")))
                is_other_sink.append(pos)
        else:
            if f[1] == b"kRegisterWritePort":
                reg = next(a[2] for a in json.loads(f[3]) if a[0] == "regSymbol")
                g = port_group.get((json.loads(f[2]), reg))
                if g is not None:
                    sink_group[pos] = g
                    matched += 1
                else:
                    is_other_sink.append(pos)
            else:
                is_other_sink.append(pos)
        res_ptr.append(len(res_val))
        pos += 1
n_ops = pos
log("ops", n_ops, "input edges", len(in_val), "results", len(res_val), "matched group ports", matched)
n_vals = max(max(in_val), max(res_val)) + 1
value_def = [-1] * n_vals
users_count = [0] * n_vals
for v in in_val:
    users_count[v] += 1
pending = [0] * n_ops
for u in range(n_ops):
    total_users = 0
    for k in range(res_ptr[u], res_ptr[u + 1]):
        r = res_val[k]
        value_def[r] = u
        total_users += users_count[r]
    pending[u] = total_users
log("values", n_vals)

# --- owner lattice: 0 none, 1 shared, >=2 interned (frozenset of groups or None for many, role bits)
NONE, SHARED = 0, 1
states = [None, None]; intern = {}; pair = {}
def make(gs, roles):
    key = (gs, roles)
    i = intern.get(key)
    if i is None:
        i = len(states); states.append(key); intern[key] = i
    return i
def combine(a, b):
    if a == b or b == NONE:
        return a
    if a == NONE:
        return b
    if a == SHARED or b == SHARED:
        return SHARED
    key = (a, b) if a < b else (b, a)
    r = pair.get(key)
    if r is None:
        ga, ra = states[a]; gb, rb = states[b]
        if ga is None or gb is None:
            gs = None
        else:
            gs = ga | gb
            if len(gs) > CAP:
                gs = None
        r = pair[key] = make(gs, ra | rb)
    return r

owner_val = [NONE] * n_vals
for value in observable_results:
    owner_val[value] = SHARED
# A primary output is an observable consumer even when the operation dump has no sink op for it.
checkpoint = root / "build/armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json"
with checkpoint.open("rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as data:
    start = data.find(b'      "ports": {')
    end = data.find(b'      "ops": [', start)
    port_info = json.loads(b"{" + data[start:end].rstrip().rstrip(b",") + b"}")["ports"]
external = {p["val"] for kind in ("out", "inout") for p in port_info[kind]}
matched_outputs = set()
with (stages / "after-clone.values.tsv").open("rb") as f:
    next(f)
    for line in f:
        index, canonical, _, _, _, symbol = line.rstrip(b"\n").split(b"\t",5)
        if symbol.strip(b'"').decode() in external:
            matched_outputs.add(json.loads(symbol))
            owner_val[int(index)] = owner_val[int(canonical)] = SHARED
assert matched_outputs == external
owner_op = [NONE] * n_ops
in_ptr_l, in_val_l, res_ptr_l, res_val_l, value_def_l, pending_l = in_ptr, in_val, res_ptr, res_val, value_def, pending
other = set(is_other_sink)
stack = [i for i in range(n_ops) if pending_l[i] == 0]
done = 0
while stack:
    u = stack.pop()
    done += 1
    lo, hi = res_ptr_l[u], res_ptr_l[u + 1]
    g = sink_group.get(u)
    if g is None:
        if lo == hi or u in other:
            state = SHARED
        else:
            state = NONE
            for k in range(lo, hi):
                state = combine(state, owner_val[res_val_l[k]])
        owner_op[u] = state
    a, b = in_ptr_l[u], in_ptr_l[u + 1]
    for k in range(a, b):
        v = in_val_l[k]
        if g is not None:
            idx = k - a
            c = make(frozenset((g,)), 1) if idx == 0 else make(frozenset((g,)), 2) if idx == 1 else SHARED
        else:
            c = state
        owner_val[v] = combine(owner_val[v], c)
        d = value_def_l[v]
        if d >= 0:
            pending_l[d] -= 1
            if pending_l[d] == 0:
                stack.append(d)
log("propagated ops", done, "of", n_ops, "states", len(states))
assert done == n_ops and matched == len(port_group)

# --- site visits per value
visits = defaultdict(int); changes = defaultdict(int)
with gzip.open(root / "build/armor-xs-site-pgo-v1/train-sites.tsv.gz", "rt") as stream:
    next(stream)
    for line in stream:
        if line.startswith("SPARSE "):
            _, n, v, c = line.split()
            visits[int(n)] += int(v); changes[int(n)] += int(c)
log("sparse sites", len(visits))

# keep the per-value ownership of the values that have a change site, for other workloads
with gzip.open(here / "exclusive-sites.json.gz", "wt") as out:
    json.dump({str(v): [states[owner_val[v]][1], sorted(states[owner_val[v]][0]) if states[owner_val[v]][0] is not None else None]
               for v in visits if owner_val[v] >= 2}, out)
exclusive_all = sum(1 for s in owner_val if s >= 2)
log("exclusive values", exclusive_all, "with a site", sum(1 for v in visits if owner_val[v] >= 2))
(here / "ownership.json").write_text(json.dumps(dict(exclusive_values=exclusive_all, observable_results=len(observable_results),
    observed_outputs=sorted(external), matched_ports=matched, ops=done, group_cap=CAP)) + "\n")
