"""Reconstruct the scheduler's pre-sibling cluster DAG for the eight enqueue lanes."""
from array import array
from collections import Counter,defaultdict
from pathlib import Path
import json,sys
out=Path(__file__).resolve().parent
root=out.parents[1]
stage=root/"build/armor-xs-gap-current-v1/audit/stages"
trace=json.loads((root/"build/armor-xs-site-pgo-v1/rob.json").read_text())
def words(name):
    return memoryview((stage/name).read_bytes()).cast("I")
nodes=words("nodes-final.nodes.bin")
offsets=array("I")
p=1
for i in range(nodes[0]):
    offsets.append(p);p+=1;end=p+1+nodes[p];p=end+1+nodes[end]
assert p==len(nodes)
def ops(n):
    p=offsets[n]+1;return nodes[p+1:p+1+nodes[p]]
def inputs(n):
    p=offsets[n]+1;p=p+1+nodes[p];return nodes[p+1:p+1+nodes[p]]
output={}
for s in ["clusters-0-in1","clusters-1-in1","clusters-1-siblings","clusters-2-in1"]:
    group=words(s+".groups.bin");p=1
    owner=array('I',[0])*nodes[0]
    members={}
    states=[next(x for x in v["stages"] if x["stage"]==s) for v in trace.values()]
    wanted={x["producer"][0] for x in states}
    for g in range(group[0]):
        row=group[p+1:p+1+group[p]];p+=1+len(row)
        if g in wanted:members[g]=list(row)
        for n in row:owner[n]=g
    nodeset={op:g for g,ns in members.items() for n in ns for op in ops(n)}
    prod={}; desc={}
    with (stage/"after-clone.ops.tsv").open() as f:
        next(f)
        for line in f:
            head,_,rest=line.partition("\t")
            if int(head) in nodeset:
                fields=rest.rstrip("\n").split("\t")
                for result in fields[-1].split(','):
                    if result:
                        prod[int(result)]=nodeset[int(head)]
                        desc[int(result)]=fields[0],Path(fields[3].strip('"')).stem,fields[4]
    edges=defaultdict(lambda:defaultdict(set)); wantedvals=set(prod)
    for n in range(nodes[0]):
        g=owner[n]
        for v in inputs(n):
            if v in wantedvals and prod[v]!=g:edges[prod[v]][g].add(v)
    targetnodes={t for dst in edges.values() for t in dst}
    targetops=Counter()
    for n,g in enumerate(owner):
        if g in targetnodes:targetops[g]+=len(ops(n))
    rows={}
    for lane,st in enumerate(states):
        grp=st["producer"][0]
        rows[lane]=dict(group=grp,source_ops=sum(len(ops(n)) for n in members[grp]),
                        readers=st["users"],successors=[dict(g=t,ops=targetops[t],values=sorted(vals),
                            origins={v:desc[v] for v in vals}) for t,vals in edges[grp].items()])
    output[s]=rows
(out/"cluster.json").write_text(json.dumps(output,indent=1))

