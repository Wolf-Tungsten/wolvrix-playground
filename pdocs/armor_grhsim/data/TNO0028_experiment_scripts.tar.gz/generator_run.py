"""Exercise the standalone emitter rule and the standard three-stage site/Clang PGO build."""
from pathlib import Path
import json, os, resource, shlex, sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts"))
from armor_xs_pgo_build import execute
from grhsim_single_baseline import clean_environment
old=root/"build/armor-xs-site-pgo-v1"
dest=base/"generator"; model=dest/"model"
def main():
    model.mkdir(exist_ok=True,parents=True)
    command=next((old/"native/logs").glob("*.log")).open().readline().removeprefix("[CMD] ")
    cmd=shlex.split(command)
    env=clean_environment()
    original=json.loads((old/"both05/pgo.command.json").read_text())["argv"]
    env["PGO_WORKLOAD"]=next(a.partition("=")[2] for a in original if a.startswith("PGO_WORKLOAD="))
    while "=" in cmd[0] and not cmd[0].startswith("/"):
        k,v=cmd.pop(0).split("=",1)
        if k=="WOLVRIX_XS_GRHSIM_MAX_OP_IN_COMMIT_SUPERNODE" and v=="cpp-default":continue
        env[k]=v.replace(str(old/"native"),str(dest))
    for key,value in dict(LD_LIBRARY_PATH=str(root/"build/armor-dispatch-v1/tools"),PYTHONPATH=str(root/"build/armor-dispatch-v1/tools/python"),
                          WOLVRIX_GRHSIM_CHANGE_SITE_PGO="1",WOLVRIX_GRHSIM_PRIORITY_MUX_COMMIT_DEMAND="1",
                          WOLVRIX_GRHSIM_PRIORITY_MUX_MIN_CHAIN_LENGTH="13").items():env[key]=value
    cmd=[a.replace(str(old/"native/model"),str(model)) for a in cmd]
    (model/"wolvrix_read_args.txt").write_bytes((old/"native/model/wolvrix_read_args.txt").read_bytes())
    execute(cmd,"emit",dest,env,root)
    def settings(log):
        with log.open() as stream:
            line=next(s for s in stream if "activity-schedule max_op" in s)
        return {k:v for k,v in (s.split("=",1) for s in line.split() if "=" in s) if k!="post_stats_json"}
    assert settings(next((old/"native/logs").glob("*.log")))==settings(dest/"emit.log")
    args=original
    cmd=[a.replace(str(old/"both05"),str(dest)).replace(str(old/"native/model"),str(model))
         for a in args if not a.startswith("XS_GRHSIM_SITE_PROFILE=")]
    execute(cmd,"pgo",dest,clean_environment(),root)
if __name__=="__main__":
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    main()
