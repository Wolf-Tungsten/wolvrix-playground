"""Sensitivity tests use only training data to generate new per-shard headers."""
from collections import Counter
import gzip
import re
import struct

def select_sites(sites, profile, dest, mode):
    totals=Counter()
    with gzip.open(profile,"rt") as stream:
        version,digest,cycles=next(stream).split()
        assert digest==sites.digest
        for path,keys in sites.shards.items():
            assert next(stream).split()==[path.name,str(len(keys))]
            immediate=set()
            if mode=="direct":
                source=path.read_text()
                for m in re.finditer(r"#ifdef GRHSIM_SPARSE_(\d+)\n(.*?)\n            \}",source,re.S):
                    if "supernode_active_curr_[" in m[2]:immediate.add(int(m[1]))
            if mode=="temporal":
                raw=(dest/"sequence/coremark"/(path.stem+".bin")).read_bytes()
                ordered=list(struct.iter_unpack("=4I",raw))
                assert len(ordered)==len(keys)
            with sites.header(path).open("w") as out:
                for j,(kind,id_) in enumerate(keys):
                    label,num,x,y=next(stream).split()
                    n,c=int(x),int(y)
                    assert (label,int(num))==(kind,id_)
                    if kind=="SPARSE":
                        original=n>=int(cycles)//4 and 200*c<=n
                        use=original or (mode=="direct" and n>=int(cycles)//4 and 20*c<=n and id_ in immediate)
                    else:
                        original=n>=int(cycles)//100 and 5*c>=n
                        use=original
                        if mode=="temporal":
                            visits,changes,transitions,misses=ordered[j]
                            assert (visits,changes)==(n,c)
                            use=original and 10*misses>=n
                    if use:
                        print(f"#define GRHSIM_{kind}_{id_} 1",file=out)
                        totals[kind]+=1
                    if original!=use:
                        totals.update(modified=1,visits=n,changes=c)
                        if mode=="temporal":totals.update(flips=transitions,misses=misses)
    return totals
