# 复现实验

脚本按 TNO0026、TNO0027 的既有构建布局读取冻结调度图、覆盖、ELF、训练固件和原始基线。解包到仓库的 `build/armor-xs-value-paths-v1/`。编译和采样使用项目的 XiangShan 环境。已存在的实验目录含有效结果。需要从头复现时，在独立工作树内使用相同的目录布局。

1. `paths.py`、`cluster.py` 从旧实验中读取按 IP 的采样、行覆盖和图导出。GSIM 更正计数使用仓库的 `value_modules.py` 和 `module_assignments.py`，令其 `DEST` 指向本实验的 `modules` 目录，再调用 `main("gs_pgo")`。
2. `prototype.py ftq`、`prototype.py rob`、`prototype.py dup` 和 `prototype.py ftqdup` 分别改变已校验的同一模型源码，在私有目录重训 Clang PGO。`sequence.py` 独立记录两种负载的每站点时间序列统计。运行后可用 `prototype.py direct` 和 `prototype.py temporal` 复现写回策略对照。
3. 按 TNO0028 的 Make 命令生成正式模型，或用 `generator_run.py` 重放本实验的完整冻结配置。编译库在 `build/armor-dispatch-v1/tools`。`reemit.py` 从同一检查点经 Make 独立生成并比较源码。`native_audit.py` 核对正式训练文件和选中的写口。`prototype.py factorrob` 在这个正式模型上单独测试 ROB 布尔因子提取。
4. `pairs.py` 在 node030 使用 TNO0027 的 NUMA、PMU、宿主核和模拟终点校验。对照组和运行顺序见 CSV，如 `python3 pairs.py emitted coremark 104 both05 generator gs_pgo --rounds 4`。MicroBench 的对应物理核是 120。`cache_pairs.py` 同样在 node030 采集另两组计数，分别使用 CPU 96、112。使用 CPU 96 时与工作区已有 XiangShan 计时共用 `wolvrix-playground-cv32e40p/build/xs/xiangshan-cpu96-measure.lock`。
5. `verify.py` 接受实验标签，和冻结参考比较两份短窗口 DiffTest，另核对 CoreMark 强制导出的性能计数。`long_trace.py` 接受标签，在 `long/baseline` 放置 TNO0027 的完整参考轨迹后比较完整 MicroBench。`shadow.py` 和 `shadow.py generator` 分别把原型和正式生成的延迟表达式与同一次执行中原槽的值逐写口比较。
6. `chain_counts.py`、`gs_copy.py`、`equivalent_ops.py`、`commit_ibs.py`、`rob_residual.py` 汇总各路径。`elf_paths.py` 生成两个原型的 ELF 摘录，正式版使用 `run(("generator",54))` 和 `run(("generator",81))`。`factor_shard.py` 用于复现旧 PGO 的函数控制流哈希拒绝，此诊断对象未参加计时。`archive.py` 校验轮次并导出计时 CSV、汇总 JSON 和本脚本包。

