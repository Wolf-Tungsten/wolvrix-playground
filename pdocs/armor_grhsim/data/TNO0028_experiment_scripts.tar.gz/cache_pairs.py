"""Repeat the ROB test with front-end and data-cache PMU counters on separate L3s."""
from pathlib import Path
import sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
import site_pairs
site_pairs.bins["both05"]=site_pairs.base/"both05/build/emu"
site_pairs.base=base
kind=sys.argv[1]
assert kind in ("frontend","data")
site_pairs.gap.GROUPS[0]=site_pairs.gap.GROUPS[1 if kind=="frontend" else 2]
site_pairs.main()

