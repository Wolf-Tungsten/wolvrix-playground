"""Join actual mispredicted commit branches in AMD IBS to the training site's rate band."""
from collections import Counter,defaultdict
from pathlib import Path
import gzip,json,re,sys
dest=Path(__file__).resolve().parent
root=dest.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from machine import OUT, DEFAULT, Elf, BINS, Disassembler, save
from armor_dispatch_ibs import BASE, symbolize
from sequence import band
folders={w:OUT/"ibs-isolated/gr_pgo"/w for w in ("coremark","microbench")}
debug=Elf(next((OUT/"lines/gr_pgo/work").glob("*-compile/emu")))
timed=Elf(BINS["gr_pgo"])
assert debug.code(*[debug.sec[".text"][i] for i in (0,2)])==timed.code(*[timed.sec[".text"][i] for i in (0,2)])
counts=defaultdict(dict)
for wl,path in folders.items():
    for line in (path/"ip.tsv").open():
        ip,n,br,taken,miss,ret,fused,dso,sym=line.rstrip("\n").split("\t")
        if int(br) and dso.endswith("/emu") and "eval_commit_batch_" in sym:
            p=int(ip,16)-BASE
            assert "eval_commit_batch_" in debug.function(p)
            counts[p][wl]=(int(br),int(miss))
out=dest/"ibs";out.mkdir(exist_ok=True)
byline=defaultdict(lambda:defaultdict(Counter))
pcs=defaultdict(list)
for p,(src,ln,*_) in symbolize(debug.path,sorted(counts),out).items():
    pcs[Path(src).name,ln].append(p)
    for wl,(br,miss) in counts[p].items():
        byline[Path(src).name,ln][wl].update(branch=br,miss=miss)
# Match the write symbol in the native and uninstrumented models. ID is stable across both.
old=root/"build/armor-xs-site-pgo-v1"
symbol={}
for name in {d for d,ln in byline}:
    file=old/"native/model"/name
    if not file.exists() or "_sched_" not in name:continue
    current=None
    for row in file.open():
        if "// op " in row:
            m=re.search(r"// op (\S+) \[kRegisterWritePort\]",row)
            current=m[1] if m else None
        if current and (m:=re.search(r"#ifdef GRHSIM_EAGER_(\d+)",row)):
            symbol[name,current]=int(m[1])
freq={}
with gzip.open(old/"train-sites.tsv.gz","rt") as f:
    _,_,length=next(f).split()
    for line in f:
        name,n=line.split()
        for j in range(int(n)):
            kind,v,vis,c=next(f).split()
            if kind=="EAGER":freq[name,int(v)]=band(kind,int(vis),int(c),int(length))
res=defaultdict(lambda:defaultdict(Counter))
examples=[]
dis=Disassembler()
for name in {k[0] for k in byline}:
    file=DEFAULT/"pgo/model"/name
    if "_sched_" not in name or not file.exists():continue
    sym=None
    for ln,row in enumerate(file.open(),1):
        if "// op " in row:
            m=re.search(r"// op (\S+) \[kRegisterWritePort\]",row)
            sym=m[1] if m else None
        if not sym or (name,ln) not in byline:continue
        if not re.search(r"if \(unlikely\(state_logic_storage_\.\w+ != next_value\)\)",row):continue
        key=freq.get((name,symbol.get((name,sym))),"other state compares")
        if key=="commit/always":
            for p in pcs[name,ln]:
                n,m=counts[p].get("coremark",(0,0))
                if m:examples.append(dict(shard=name,line=ln,op=symbol[name,sym],sym=sym,text=row.strip(),
                                          pc=hex(p),asm=dis.get(debug.code(p,16),p),branch=n,miss=m))
        for wl,c in byline[name,ln].items():res[wl][key].update(c)
save(out/"commit.json",res)
save(out/"always.json",sorted(examples,key=lambda x:-x["miss"]))

