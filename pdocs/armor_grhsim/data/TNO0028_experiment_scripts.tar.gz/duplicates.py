"""Test sharing named ROB results in one compute group using the existing notification mask."""
from collections import Counter, defaultdict
from pathlib import Path
import re

NAME = re.compile(r"// value .*?\$(entryEnqValid|uopCanEnqSeq)_(\d+)_(\d+) -> value_bool_slots_\[(\d+)\] \[value_id=(\d+):0\]")
SLOT = re.compile(r"value_bool_slots_\[(\d+)\]")
GUARD = re.compile(r"grhsim_any_changed_\d+_\d+")
BASE = re.compile(r"value_bool_slots_\.data\(\) \+ (\d+)u")
WRITE = re.compile(r"value_bool_slots_\[(\d+)\] = (?!=)")
STAGE = re.compile(r"// Supernode (\d+):")

def slot_spans(row):
    if not (ptr := BASE.search(row)):
        raise ValueError(row[:300])
    start = int(ptr[1])
    if "std::memcmp" in row:
        length = int(re.search(r", (\d+)u \* sizeof\(bool\)\)",row)[1])
    elif "grhsim_store_scalar_slices<" in row:
        params = row.partition("grhsim_store_scalar_slices<")[2].partition(">")[0].split(",")
        length = len(params)-1
    else:
        raise ValueError(row[:300])
    return range(start,start+length)

def duplicates(model):
    candidates = defaultdict(dict)
    ranges = set()
    writes = Counter()
    reads = defaultdict(set)
    cpp = sorted(model.glob("*.cpp"))
    def pass_one(p):
        group = None
        rows = p.read_text().splitlines()
        for i,row in enumerate(rows):
            if match := STAGE.search(row): group = int(match[1])
            if match := NAME.search(row):
                kind, lane, entry, dst, value = match.groups()
                if i+13>=len(rows) or "const bool next_value = " not in rows[i+2]:continue
                rhs = rows[i+2].strip().removeprefix("const bool next_value = ").removesuffix(";")
                if not re.fullmatch(r"value_bool_slots_\[\d+\] & grhsim_v\d+_0",rhs):continue
                if f"const bool grhsim_changed_{value} = (value_bool_slots_[{dst}] != next_value);" not in rows[i+3]: continue
                end = i+4
                while end<len(rows) and rows[end] != "        }":end+=1
                if end==len(rows) or end-i>24:continue
                body=rows[i+4:end]
                effects=[r.strip() for r in body if r.startswith("                ")]
                guard=set()
                for r in effects:
                    if match_guard := re.fullmatch(rf"(grhsim_any_changed_\d+_\d+) = static_cast<bool>\(\1 \| grhsim_changed_{value}\);",r):
                        guard.add(match_guard[1])
                    elif r != f"value_bool_slots_[{dst}] = next_value;":break
                else:
                    if guard:
                        candidates[lane,entry][kind]=dict(path=p.name,start=i,end=end,group=group,expr=rhs,
                                                           guards=sorted(guard),slot=int(dst),id=int(value))
            if "value_bool_slots_" not in row or row.lstrip().startswith("//"):continue
            writes.update(map(int,WRITE.findall(row)))
            if "value_bool_slots_.data()" in row:ranges.update(slot_spans(row))
    for p in cpp:pass_one(p)
    mapping={}
    cuts=defaultdict(dict)
    pairs=[]
    for key,names in candidates.items():
        a,b=names.get("entryEnqValid"),names.get("uopCanEnqSeq")
        if not (a and b):continue
        if (a["path"],a["group"],a["expr"])!=(b["path"],b["group"],b["expr"]) or a["start"]>=b["start"]:continue
        if max(writes[a["slot"]],writes[b["slot"]])!=1 or min(writes[a["slot"]],writes[b["slot"]])!=1:continue
        if b["slot"] in ranges or a["slot"] in ranges or not set(b["guards"])<=set(a["guards"]):continue
        mapping[b["slot"]]=a["slot"]
        cuts[b["path"]][b["start"]]=b["end"]
        pairs.append(dict(lane=int(key[0]),entry=int(key[1]),canonical=a,duplicate=b))
    assert len(mapping)==len(pairs)>0
    for p in [*cpp,*model.glob("*.hpp")]:
        original=p.read_text();rows=original.splitlines(keepends=True)
        for start,end in cuts.get(p.name,{}).items():rows[start:end+1]=[""]*(end-start+1)
        def substitute(m):
            idx=int(m[1])
            return f"value_bool_slots_[{mapping[idx]}]" if idx in mapping else m[0]
        new=SLOT.sub(substitute,"".join(rows))
        if new!=original:p.write_text(new)
    return dict(candidates=len(candidates),sites=pairs)

