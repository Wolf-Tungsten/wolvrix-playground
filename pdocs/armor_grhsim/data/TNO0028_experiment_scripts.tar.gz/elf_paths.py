"""Byte-check selected DWARF instructions against the final timed, stripped PGO binary."""
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from machine import LLVM, Elf, Disassembler, phase, save

def run(job):
    tag,batch=job
    old=root/"build/armor-xs-site-pgo-v1"
    baseline=tag=="both05"
    build=(old if baseline else base)/tag/"build"
    out=base/"elf"/tag
    out.mkdir(exist_ok=True,parents=True)
    model=(old/"native" if baseline else base/tag)/"model"
    name=f"grhsim_SimTop_sched_{batch}.cpp"
    source=out/name
    header=source.with_suffix(".sites.h").name
    if baseline or tag=="generator":
        shutil.copyfile(base/"ftq/model"/header,out/header)
        source.write_bytes(f'#include "{header}"\n'.encode()+(model/name).read_bytes())
    else:
        shutil.copyfile(model/name,source)
    rows=source.read_text().splitlines()
    def at(txt):
        hits=[i for i,x in enumerate(rows,1) if txt in x]
        assert len(hits)==1,(txt,hits)
        return hits[0]
    if batch==54:
        start=at("const std::uint8_t grhsim_v772201_0 =")
        if tag=="generator":
            end=next(i for i in range(start,len(rows)+1) if "// Terminal priority mux" in rows[i-1])
        else:
            end=at("[value_id=772208:0]")+4
    elif batch==81:
        start=at("reg=cpu$l_soc$core_with_l2$core$frontend$inner_ftq$perfQueue_36_cfiAttr_10_branchType")-1
        if tag=="generator":
            start=at("value_u8_slots_[35685] = static_cast")-2
        # Include the conditional guard, result assignment, compare and branch.
        end=start+20
    elif batch==15:
        start=end=at("[value_id=975546:0]")+2
    elif batch==20:
        start=end=at("const bool grhsim_v959726_0 =")
    outobj=source.with_suffix(".o")
    if not outobj.exists():
        subprocess.run([LLVM/"clang++","-std=c++20","-O3","-march=native",f"-fprofile-use={build/'grhsim.profdata'}",
                       "-mllvm","-x86-cmov-converter-force-mem-operand=false","-gline-tables-only","-I",model,
                       "-c",name,"-o",outobj],cwd=out,check=True)
    obj=Elf(outobj)
    elf=Elf(build/"emu")
    fphase="compute" if batch<80 else "commit"
    fun=f"GrhSIM_SimTop::eval_{fphase}_batch_{batch}()"
    startpc,size=elf.funcs[fun]
    objstart,objsize=obj.funcs[fun]
    assert size==objsize,(fun,size,objsize)
    trace=subprocess.Popen([LLVM/"llvm-objdump","-dlC",outobj],stdout=subprocess.PIPE,text=True)
    offset=None;ln=None;matched=[]
    dis=Disassembler()
    for row in trace.stdout:
        if m:=re.match(r"^([0-9a-f]+) <(.*)>:",row):
            offset=int(m[1],16) if m[2]==fun else None;ln=None
        elif row.startswith(";"):
            m=re.search(re.escape(name)+r":(\d+)",row)
            ln=int(m[1]) if m else None
        elif offset is not None and ln is not None and start<=ln<=end:
            m=re.match(r"^\s*([0-9a-f]+): ((?:[0-9a-f]{2} )*[0-9a-f]{2})\s+",row)
            if m:
                pc=startpc+int(m[1],16)-offset;encoding=bytes.fromhex(m[2])
                if elf.code(pc,len(encoding))==encoding:
                    matched.append(dict(pc=hex(pc),line=ln,asm=dis.get(elf.code(pc,16),pc)))
    assert trace.wait()==0
    save(out/f"shard-{batch}.json",dict(tag=tag,binary=str(elf.path),function=fun,bytes=size,lines=[start,end],instructions=matched))
    print(tag,batch,size,len(matched),flush=True)
if __name__=="__main__":
    jobs=[("both05",54),("ftq",54),("both05",81),("ftq",81),("both05",15),("rob",15)]
    with ThreadPoolExecutor(6) as pool:list(pool.map(run,jobs))

