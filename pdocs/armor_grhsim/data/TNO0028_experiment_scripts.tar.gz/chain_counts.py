"""Compare compute visits, proven active write visits, and baseline instruction samples."""
from collections import Counter, defaultdict
from pathlib import Path
import csv, gzip, json, re, sys
out=Path(__file__).resolve().parent
root=out.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import DEFAULT, OUT, save
from source_categories import read_lcov
from duplicates import SLOT
plain=DEFAULT/"pgo/model"
moves=json.loads((out/"ftq/ftq.json").read_text())["sites"]
term={m["id"] for m in moves}
slots={m["slot"] for m in moves}
ors={m["id"] for m in json.loads((out/"rob/rob.json").read_text())}
dups=json.loads((out/"dup/dup.json").read_text())["sites"]
dup_ids={x["duplicate"]["id"] for x in dups}
chain_ops={}
source_group={}
leaf_slots=defaultdict(set)
for name in {m["compute"] for m in moves}:
    locals_={};current=None
    for line in (plain/name).read_text().splitlines():
        if "// Supernode " in line:locals_.clear()
        if "// value " in line:
            m=re.search(r"\[value_id=(\d+):",line)
            current=int(m[1]) if m else None
        if m:=re.match(r"\s*const std::uint8_t grhsim_v(\d+)_0 = (.*);",line):
            locals_[int(m[1])]=m[2]
        elif current in term and "const std::uint8_t next_value = " in line:
            parts={current:line.split(" = ",1)[1]};work=[current]
            while work:
                expr=parts[work.pop()]
                for v in re.findall(r"grhsim_v(\d+)_0",expr):
                    key=int(v)
                    if key not in parts:parts[key]=locals_[key];work.append(key)
            assert sum(e.count("grhsim_mux_u64") for e in parts.values())==13
            for v,e in parts.items():
                chain_ops[v]=e.count("grhsim_mux_u64")
                for ty, slot in re.findall(r"value_(u8|bool)_slots_\[(\d+)\]",e):leaf_slots[ty].add(int(slot))
            current=None
assert len(chain_ops)>=len(term)
# Check the actual final C++ for writes to any materialized input in commit.
writes=defaultdict(set)
for p in plain.glob("*.cpp"):
    ph=False
    for line in p.read_text().splitlines():
        if line.startswith("void "): ph="::eval_commit_batch_" in line
        if ph:
            for ty,id_ in re.findall(r"value_(u8|bool)_slots_\[(\d+)\]\s*=(?!=)",line):writes[ty].add(int(id_))
            if "slots_.data()" in line:assert "std::memcmp(" in line and "memcpy(" not in line
assert all(not s.intersection(writes[ty]) for ty,s in leaf_slots.items())
result=dict(sites=len(moves),ids=len(chain_ops),leaf_slots={k:len(x) for k,x in leaf_slots.items()},
            commit_slot_writers={k:len(x) for k,x in writes.items()})
for wl in ("coremark","microbench"):
    c=Counter();metrics=json.loads((OUT/"metrics.json").read_text())[wl]["per_guest"]["gr_pgo"]
    total=json.loads((OUT/"machine/gr_pgo"/wl/"attribution.json").read_text())["total"]
    with (out/(wl+".tsv")).open() as f:
        for row in csv.DictReader(f,delimiter="\t"):
            i=int(row["id"]);n=int(row["visits"])
            if i in term:c.update(root_visits=n,roots_active=int(n>0))
            if i in chain_ops:c.update(mux_sites_visits=chain_ops[i]*n,chain_assignments=n,chain_samples=int(row["instruction_samples"]))
            if i in ors:c.update(rob_or_visits=n,rob_or_samples=int(row["instruction_samples"]))
            if i in dup_ids:c.update(dup_visits=n,dup_samples=int(row["instruction_samples"]))
    matched=0
    field=re.compile(r"reg=.*\$perfQueue_(\d+)_cfiAttr_(\d+)_(branchType|rasAction)$")
    mnames={m["commit"] for m in moves}
    for f,lines,_ in read_lcov(OUT/"coverage/gr_pgo"/wl/"model.lcov"):
        p=Path(f)
        if p.name not in mnames:continue
        relevant=False
        for ln,row in enumerate(p.read_text().splitlines(),1):
            if "// op " in row:relevant=bool(field.search(row))
            if relevant and (m:=re.search(r"const auto next_value = static_cast<std::uint8_t>\(value_u8_slots_\[(\d+)\]\);",row)):
                assert int(m[1]) in slots
                matched+=1
                n=lines.get(ln,0);c.update(write_visits=n,writes_active=int(n>0));relevant=False
    assert matched==len(moves)
    for key in ("chain","rob_or","dup"):
        c[key+"_instructions"]=c[key+"_samples"]*metrics["instructions"]/total["instructions"]
    result[wl]=c
save(out/"chain_counts.json",result)

