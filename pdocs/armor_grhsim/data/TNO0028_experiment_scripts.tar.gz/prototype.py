"""Frozen-layout tests. Specialize the validated original training profile before changing any C++."""
from collections import Counter,defaultdict
from pathlib import Path
import json,re,resource,shutil,sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts"))
from grhsim_change_sites import ChangeSites
from grhsim_single_baseline import clean_environment,save
from armor_xs_pgo_build import execute
from duplicates import duplicates
from select_sites import select_sites
from factor_rob import factor_rob

native=root/"build/armor-xs-site-pgo-v1"
stages=root/"build/armor-xs-gap-current-v1/audit/stages"
local=re.compile(r'\bgrhsim_v\d+_\d+\b')
slot=re.compile(r'\bvalue_u8_slots_\[(\d+)\]')
field=re.compile(r'\bperfQueue_(\d+)_cfiAttr_(\d+)_(branchType|rasAction)\b')
write_name=re.compile(r'\$perfQueue_(\d+)_cfiAttr_(\d+)_(branchType|rasAction)$')
ident=re.compile(r'\b[a-zA-Z_]\w*')
allowed={'static_cast','std','uint8_t','uint64_t','grhsim_mux_u64','value_bool_slots_','value_u8_slots_'}
def ftq(model, check=False):
    targets={}
    ranges=set()
    counts=Counter()
    for p in model.glob("*.cpp"):
        with p.open() as f:
            group=None; write=None
            for n,row in enumerate(f,1):
                t=row.strip()
                if t.startswith("// op "):write=write_name.search(t) if "[kRegisterWritePort]" in t else None
                if t.startswith("//") or t.startswith("#"):continue
                if "value_u8_slots_" not in t:continue
                counts.update(int(i) for i in slot.findall(t))
                if "value_u8_slots_.data()" in t:
                    m=re.search(r"value_u8_slots_\.data\(\) \+ (\d+)u, (\d+)u \* sizeof",t)
                    if not m:raise ValueError(t[:250])
                    ranges.update(range(int(m[1]),int(m[1])+int(m[2])))
                if write and (m:=re.fullmatch(r"const auto next_value = static_cast<std::uint8_t>\(value_u8_slots_\[(\d+)\]\);",t)):
                    i=int(m[1]);assert i not in targets,(p,n)
                    targets[i]=(p.name,n,write[0])
    eligible={i for i in targets if counts[i]==2 and i not in ranges}
    replacements=defaultdict(dict); records=[]
    for p in model.glob("*_sched_*.cpp"):
        rows=p.read_text().splitlines(keepends=True)
        if "::eval_compute_batch_" not in "".join(rows[:45]):continue
        variables={}; group=0; changed=False
        for j,row in enumerate(rows):
            if "// Supernode " in row:
                group=int(row.split("Supernode ")[1].split(":")[0]);variables.clear()
            m=re.match(r'        const std::uint8_t (grhsim_v\d+_\d+) = (.*);\n',row)
            if m:variables[m[1]]=m[2]
            if (m:=re.fullmatch(r'            value_u8_slots_\[(\d+)\] = next_value;\n',row)) and int(m[1]) in eligible:
                i=int(m[1])
                expr=re.fullmatch(r'            const std::uint8_t next_value = (.*);\n',rows[j-1])
                if not expr or rows[j-2].strip()!="{" or rows[j+1].strip()!="}":continue
                rhs=expr[1]
                for depth in range(12):
                    if not local.search(rhs):break
                    if not all(v in variables for v in local.findall(rhs)):break
                    rhs=local.sub(lambda v:"("+variables[v[0]]+")",rhs)
                if local.search(rhs) or set(ident.findall(rhs))-allowed or rhs.count("grhsim_mux_u64")<3:continue
                # Graph identity of the result is taken from the emitter's owner comment.
                value=int(re.search(r'\[value_id=(\d+):',rows[j-3])[1])
                target,n,symbol=targets[i]
                replacements[target][n]=rhs
                records.append(dict(id=value,slot=i,group=group,compute=p.name,store_line=j+1,commit=target,
                                    commit_line=n,symbol=symbol,muxes=rhs.count("grhsim_mux_u64")))
                if not check:
                    rows[j-1]=rows[j]=""
                changed=True
        if changed:p.write_text("".join(rows))
    for name,moves in replacements.items():
        p=model/name
        rows=p.read_text().splitlines(keepends=True)
        for n,rhs in moves.items():
            assert "const auto next_value" in rows[n-1]
            if check:
                rows[n-1]+="                    if (next_value != static_cast<std::uint8_t>("+rhs+")) std::abort();\n"
            else:
                rows[n-1]=slot.sub(lambda m:"("+rhs+")",rows[n-1],count=1)
        p.write_text("".join(rows))
    return dict(targets=len(targets),exclusive=len(eligible),sites=records)
def rob(model):
    ops=set()
    with (stages/"after-clone.ops.tsv").open() as f:
        for r in f:
            if '\tkOr\t' in r and '/Rob.sv"' in r:
                ops.update(int(v) for v in r.rstrip("\n").rsplit("\t",1)[1].split(",") if v)
    bools=re.compile(r'value_bool_slots_\[(\d+)\]')
    count=int(re.search(r'std::array<bool, (\d+)> value_bool_slots_', (model/"grhsim_SimTop.hpp").read_text())[1])
    records=[]
    for p in model.glob("*_sched_*.cpp"):
        rows=p.read_text().splitlines(keepends=True)
        if "::eval_compute_batch_" not in "".join(rows[:45]):continue
        changed=False;v=None
        for j,row in enumerate(rows):
            if "// value " in row and "[value_id=" in row:v=int(row.partition("[value_id=")[2].partition(":")[0])
            if (m:=re.match(r"\s*const bool grhsim_v(\d+)_\d+ =",row)):owner=int(m[1])
            elif "const bool next_value = " in row:owner=v
            else:continue
            if owner not in ops:continue
            lhs,rhs=row.split(" = ",1);rhs=rhs.strip().removesuffix(";")
            residual=bools.sub("B",rhs).replace("static_cast<bool>","")
            if not re.fullmatch(r'[\s()B|]+',residual) or "||" in residual:continue
            idx=sorted(set(map(int,bools.findall(rhs))))
            if len(idx)<5:continue
            parts=[];loads=0
            while idx:
                start=min(idx[0],count-8)
                group=[n for n in idx if n<start+8];idx=idx[len(group):]
                if len(group)<3:
                    parts.extend("value_bool_slots_["+str(n)+"]" for n in group);continue
                mask=sum(255<<((n-start)*8) for n in group)
                parts.append(f"xs_or8(value_bool_slots_.data()+{start}u, UINT64_C({mask}))")
                loads+=1
            if not loads:continue
            rows[j]=lhs+" = "+" | ".join(parts)+";\n"
            records.append(dict(cpp=p.name,line=j+1,id=owner,loads=loads));changed=True
        if changed:
            rows.insert(1,'#include "xs_or8.hpp"\n')
            p.write_text("".join(rows))
    (model/"xs_or8.hpp").write_text("""#pragma once
#include <bit>
#include <cstring>
#include <cstdint>
static_assert(sizeof(bool)==1 && std::endian::native==std::endian::little && std::bit_cast<unsigned char>(false)==0);
static inline bool xs_or8(const bool *p, std::uint64_t mask) {
    std::uint64_t word;
    std::memcpy(&word,p,sizeof(word));
    return (word & mask) != 0;
}
""")
    return records

def main(tag):
    dest=base/tag;model=dest/"model";model.mkdir(parents=True)
    source=base/"generator/model" if tag=="factorrob" else native/"native/model"
    for p in source.iterdir():
        if p.name=="Makefile" or p.suffix in (".cpp",".hpp",".h"):shutil.copyfile(p,model/p.name)
    sites=ChangeSites(model,dest)
    profile=base/"generator/build/grhsim-sites.tsv.gz" if tag=="factorrob" else native/"train-sites.tsv.gz"
    selected=sites.specialize(profile,"both",5)
    assert selected==dict(SPARSE=131357,EAGER=17187)
    if tag in ('direct','temporal'):
        save(dest/"selection.json",select_sites(sites,native/"train-sites.tsv.gz",base,tag))
    if tag in ('ftq','both'):save(dest/"ftq.json",ftq(model))
    if tag in ('rob','both'):save(dest/"rob.json",rob(model))
    if tag in ('dup','ftqdup'):
        save(dest/"dup.json",duplicates(model))
    if tag=='ftqdup':
        save(dest/"ftq.json",ftq(model))
    if tag=="factorrob":
        save(dest/"factor.json",factor_rob(model,base))
    args=json.loads((native/"both05/pgo.command.json").read_text())["argv"]
    cmd=[a.replace(str(native/"both05"),str(dest)).replace(str(native/"native/model"),str(model)) for a in args
         if not a.startswith(("XS_GRHSIM_SITE_","XS_GRHSIM_SPARSE_PERMILLE="))]
    execute(cmd,"pgo",dest,clean_environment(),root)
if __name__=="__main__":
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    main(sys.argv[1])

