"""Cross-check deferred expressions against the original computed slots at active writes."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import re
import resource
import shutil
import sys

base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import OUT, IMAGES, NEMU, execute, clean_environment, expected, signature, parse_run, pick_cpu, save
from grhsim_change_sites import ChangeSites
from prototype import ftq, native

def main():
    generated=sys.argv[1:]==["generator"]
    dest=base/("shadow-generator" if generated else "shadow")
    work=dest/"work";model=work/"model";model.mkdir(exist_ok=True,parents=True)
    for p in (native/"native/model").iterdir():
        if p.suffix in (".cpp",".hpp",".h") or p.name=="Makefile":shutil.copyfile(p,model/p.name)
    inventory=ChangeSites(model,dest)
    inventory.specialize(native/"train-sites.tsv.gz","both",5)
    number=0
    if generated:
        for p in (base/"generator/model").glob("*_sched_*.cpp"):
            source=p.read_text()
            if "// Demand-evaluate terminal priority mux" not in source:continue
            def check(match):
                return match[1]+"if ("+match[2]+" != "+match[3]+") std::abort();"
            replacement,n=re.subn(r"(// Demand-evaluate terminal priority mux under its commit guard\.\n +)(value_(?:bool|u\d+)_slots_\[\d+\]) = ([^;\n]+);",check,source)
            assert n==source.count("// Demand-evaluate terminal priority mux")
            number+=n
            (model/p.name).write_text('#include "'+p.with_suffix(".sites.h").name+'"\n'+replacement)
        assert number==4352
    else:
        number=len(ftq(model,True)["sites"])
        assert number==4096
    original=OUT/"sitewatch/gr_pgo"
    args=json.loads((original/"build.command.json").read_text())["argv"]
    args=[a.replace(str(original),str(dest)).replace("-j20","-j36").replace("JOBS=20","JOBS=36") for a in args]
    execute(args,"build",dest,dict(clean_environment(),NOOP_HOME=str(root/"testcase/xiangshan")),root)
    def run(wl):
        folder=dest/wl; folder.mkdir(exist_ok=True);cpu,_=pick_cpu()
        window=100000 if wl=="coremark" else 250000
        execute(["taskset","-c",str(cpu),"numactl","--membind=1",work/"grhsim-compile/emu","-i",IMAGES[wl],
                 "--diff",NEMU,"-b","0","-e","0","-s","0","-C",str(window)],"run",folder,clean_environment(),folder)
        txt=(folder/"run.log").read_text()
        if wl=="coremark":
            assert signature(parse_run(txt,window))==expected("gr_pgo",wl)
        else:
            assert "MicroBench PASS" in txt and "HIT GOOD TRAP" in txt and "326,377" in txt
        save(folder/"checked.json",dict(expressions=number,guest_window=window))
    with ThreadPoolExecutor(2) as ex:list(ex.map(run,IMAGES))

if __name__=="__main__":
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    main()
