from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import resource
import sys
import time

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base.parents[1] / "scripts/armor_xs_gap_diagnostics"))
from verify_sparse import verify_sparse

def verify(tag):
    binary = base / tag / "build/emu"
    while not binary.exists():
        outcome = base / tag / "pgo.result.json"
        if outcome.is_file() and json.loads(outcome.read_text())["returncode"]:
            raise RuntimeError(f"{tag} did not build")
        time.sleep(10)
    verify_sparse(binary, base / "verify" / tag)
    print(tag, "verified", flush=True)

resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
with ThreadPoolExecutor(max_workers=5) as pool:
    list(pool.map(verify, sys.argv[1:]))
