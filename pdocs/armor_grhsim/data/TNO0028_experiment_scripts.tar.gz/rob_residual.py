"""Count a recurring ROB writeback mux with the same boolean operand on both arms."""
from collections import Counter
from pathlib import Path
import csv,json,re
base=Path(__file__).resolve().parent
root=base.parents[1]
plain=root/"build/armor-xs-mode-defaults-v1/pgo/model"
out=root/"build/armor-xs-gap-current-v1"
atom=r"(?:value_bool_slots_\[\d+\]|grhsim_v\d+_0|state_logic_storage_\.bool_slots_\d+)"
arm=r"\(static_cast<bool>\(\(("+atom+r") ([|&]) ("+atom+r")\)\)\)"
pat=re.compile(r"grhsim_mux_u64\(static_cast<std::uint64_t>\(("+atom+r")\), "+arm+", "+arm+r"\)")
matched={}
for wl in ("coremark","microbench"):
    docs={}
    hist=Counter()
    with (base/(wl+".tsv")).open() as f:
        for r in csv.DictReader(f,delimiter="\t"):
            if r["module"]!="Rob" or r["kind"]!="kMux":continue
            name=r["cpp"]
            if name not in docs:docs[name]=(plain/name).read_text().splitlines()
            text=docs[name][int(r["line"])-1]
            m=pat.search(text)
            if not m or m[3]!=m[6] or not {m[2],m[4]}.intersection((m[5],m[7])):continue
            hist.update(ids=1,visits=int(r["visits"]),samples=int(r["instruction_samples"]))
    scale=json.loads((out/"metrics.json").read_text())[wl]["per_guest"]["gr_pgo"]["instructions"]/json.loads((out/"machine/gr_pgo"/wl/"attribution.json").read_text())["total"]["instructions"]
    hist["attributed_ins_per_guest"]=hist["samples"]*scale
    matched[wl]=hist
(base/"rob-residual.json").write_text(json.dumps(matched,indent=2)+"\n")

