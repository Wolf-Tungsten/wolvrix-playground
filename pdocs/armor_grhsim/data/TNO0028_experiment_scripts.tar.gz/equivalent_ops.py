"""Bound same-group CSE using identical pure graph instructions and measured site histories."""
from collections import Counter, defaultdict
from pathlib import Path
import gzip,json,struct,sys
out=Path(__file__).resolve().parent;root=out.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import OUT,save
stages=OUT/"audit/stages"
# The inventory records group IDs in emitted comments, also found for duplicated schedule functions.
import re
owners=defaultdict(set)
src=root/"build/armor-xs-site-pgo-v1/native/model"
marker=re.compile(rb"(?m)^        // Supernode (\d+):[^\n]*|^#ifdef GRHSIM_SPARSE_(\d+)$")
profile=defaultdict(Counter)
for path in src.glob("*_sched_*.cpp"):
    group=None
    for mat in marker.finditer(path.read_bytes()):
        if mat[1]:group=int(mat[1])
        elif mat[2]:owners[int(mat[2])].add(group)
seen=set(owners)
ty={}
with (stages/"after-clone.values.tsv").open() as f:
    header=next(f)
    for row in f:
        first,_,rest=row.partition("\t");v=int(first)
        if v in seen:ty[v]=tuple(rest.split("\t",4)[1:3])
dups=defaultdict(list)
pure={"kAnd","kOr","kXor","kNot","kLogicAnd","kLogicOr","kLogicNot","kMux","kEq","kNe","kAdd","kSub","kConcat","kSliceStatic"}
with (stages/"after-clone.ops.tsv").open() as f:
    next(f)
    for row in f:
        id_,kind,symbol,attrs,file,ln,col,inputs,results=row.rstrip("\n").split("\t")
        if kind not in pure or not results or "," in results:continue
        v=int(results)
        if v not in owners or len(owners[v])!=1:continue
        group,=owners[v]
        dups[group,kind,ty[v],attrs,inputs].append(v)
dups={k:vs for k,vs in dups.items() if len(vs)>1}
wanted={v for vs in dups.values() for v in vs}
results={}
for wl in ("coremark","microbench"):
    records={}
    with gzip.open(root/"build/armor-xs-site-pgo-v1/train-sites.tsv.gz","rt") as f:
        next(f)
        for line in f:
            shard,count=line.split()
            raw=(out/"sequence"/wl/(Path(shard).stem+".bin")).read_bytes()
            for row in struct.iter_unpack("=4I",raw):
                k,v,x,y=next(f).split();v=int(v)
                if k=="SPARSE" and v in wanted:
                    a=records.setdefault(v,[0]*4)
                    for i in range(4):a[i]+=row[i]
    bykind=defaultdict(Counter)
    for (_,kind,*rest),vs in dups.items():
        ns=[records[v] for v in vs]
        # Counts include repeated order and the isolated saturating counter.
        # Exclude nonmatching sequences of statistics from even the bound.
        ref=ns[0]
        for n in ns[1:]:
            if n==ref:bykind[kind].update(sites=1,visits=n[0],changes=n[1])
            else:bykind[kind].update(mismatched=1)
    results[wl]=bykind
save(out/"equivalent_ops.json",results)

