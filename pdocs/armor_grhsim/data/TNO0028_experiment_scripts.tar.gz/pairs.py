"""Run the original counterbalanced PMU harness in the current experiment directory."""
from pathlib import Path
import sys

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
import site_pairs

site_pairs.bins["both05"] = site_pairs.base / "both05/build/emu"
site_pairs.base = base
site_pairs.main()
