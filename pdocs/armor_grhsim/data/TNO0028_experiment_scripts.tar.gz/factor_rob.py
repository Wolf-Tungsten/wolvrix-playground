"""Factor just scalar boolean operand pairs belonging to ROB mux results."""
from collections import Counter
import csv
import re

ATOM=r"(?:value_bool_slots_\[\d+\]|grhsim_v\d+_0|state_logic_storage_\.bool_slots_\d+)"
ARM=r"\(static_cast<bool>\(\(("+ATOM+r") ([|&]) ("+ATOM+r")\)\)\)"
PATTERN=re.compile(r"grhsim_mux_u64\(static_cast<std::uint64_t>\(("+ATOM+r")\), "+ARM+", "+ARM+r"\)")
LOCAL=re.compile(r"const bool grhsim_v(\d+)_0 = ")
OWNER=re.compile(r"\[value_id=(\d+):0\]")

def factor_rob(model, base):
    stages=base.parent/"armor-xs-gap-current-v1/audit/stages"
    owners=set()
    with (stages/"after-clone.ops.tsv").open() as f:
        for r in f:
            if "\tkMux\t" in r and '/Rob.sv"' in r:
                owners.update(int(v) for v in r.rstrip("\n").rsplit("\t",1)[1].split(",") if v)
    sites=[]
    for p in model.glob("*_sched_*.cpp"):
        rows=p.read_text().splitlines(keepends=True)
        if "::eval_compute_batch_" not in "".join(rows[:45]):continue
        current=None;modified=False
        for i,row in enumerate(rows):
            if "// value " in row:
                match=OWNER.search(row)
                current=int(match[1]) if match else None
            elif "// op " in row or row.strip()=="}":current=None
            if "grhsim_mux_u64(" not in row:continue
            if match:=LOCAL.search(row):owner=int(match[1])
            elif "const bool next_value = " in row:owner=current
            else:continue
            if owner not in owners:continue
            def factor(m):
                if m[3]!=m[6]:return m[0]
                shared={m[2],m[4]} & {m[5],m[7]}
                if len(shared)!=1:return m[0]
                common,=shared
                a=m[4] if m[2]==common else m[2]
                b=m[7] if m[5]==common else m[5]
                return f"(grhsim_mux_u64({m[1]}, {a}, {b}) {m[3]} {common})"
            new=PATTERN.sub(factor,row)
            if new!=row:
                sites.append(dict(file=p.name,id=owner,line=i+1));rows[i]=new;modified=True
        if modified:p.write_text("".join(rows))
    assert sites
    return dict(sites=len(sites),by_shard=Counter(s["file"] for s in sites),example=next(s for s in sites if s["id"]==959726))

