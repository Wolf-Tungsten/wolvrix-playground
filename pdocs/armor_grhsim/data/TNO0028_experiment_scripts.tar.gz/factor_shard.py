"""Compile one real ROB compute shard with/without factoring the common operand."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from machine import LLVM,Elf,save
old=root/"build/armor-xs-site-pgo-v1"
model=old/"native/model";name="grhsim_SimTop_sched_20.cpp";fun="GrhSIM_SimTop::eval_compute_batch_20()"
atom=r"(?:value_bool_slots_\[\d+\]|grhsim_v\d+_0|state_logic_storage_\.bool_slots_\d+)"
arm=r"\(static_cast<bool>\(\(("+atom+r") ([|&]) ("+atom+r")\)\)\)"
pat=re.compile(r"grhsim_mux_u64\(static_cast<std::uint64_t>\(("+atom+r")\), "+arm+", "+arm+r"\)")
def run(variant):
    out=base/"factor"/variant;out.mkdir(exist_ok=True,parents=True)
    header=Path(name).with_suffix(".sites.h").name
    shutil.copyfile(base/"ftq/model"/header,out/header)
    src=f'#include "{header}"\n'+(model/name).read_text()
    records=0
    def factor(m):
        nonlocal records
        if m[3]!=m[6]:return m[0]
        both=set((m[2],m[4])) & set((m[5],m[7]))
        if len(both)!=1:return m[0]
        common,=both
        a=m[4] if m[2]==common else m[2];b=m[7] if m[5]==common else m[5]
        records+=1
        return f"(grhsim_mux_u64({m[1]}, {a}, {b}) {m[3]} {common})"
    if variant=="factor":src=pat.sub(factor,src)
    (out/name).write_text(src)
    obj=out/"shard.o"
    subprocess.run([LLVM/"clang++","-std=c++20","-march=native","-O3","-Werror=profile-instr-out-of-date",
                    f"-fprofile-use={old/'both05/build/grhsim.profdata'}","-mllvm","-x86-cmov-converter-force-mem-operand=false",
                    "-I",model,"-c",name,"-o",obj],cwd=out,check=True)
    # Read the relocatable .text section; the model dispatch function starts at offset zero.
    section=subprocess.check_output([LLVM/"llvm-readelf","-SW",obj],text=True)
    m=re.search(r"\]\s+\.text\s+PROGBITS\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)",section)
    start,offset,sz=(int(x,16) for x in m.groups())
    sym=subprocess.check_output([LLVM/"llvm-nm","-SC",obj],text=True)
    match=next(x.split(None,3) for x in sym.splitlines() if x.endswith(" T "+fun))
    pc,size=int(match[0],16),int(match[1],16)
    data=obj.read_bytes()[offset+pc-start:offset+pc-start+size]
    assert len(data)==size
    save(out/"result.json",dict(changed=records,size=size,sha256=hashlib.sha256(data).hexdigest(),final_baseline_size=Elf(old/"both05/build/emu").funcs[fun][1]))
with ThreadPoolExecutor(2) as ex:list(ex.map(run,("reference","factor")))

