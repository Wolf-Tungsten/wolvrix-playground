"""Archive accepted paired samples and compact supporting records for TNO0028."""
from collections import defaultdict
from pathlib import Path
from statistics import mean
import csv, hashlib, json, re, sys, tarfile
base=Path(__file__).resolve().parent
root=base.parents[1]
old=root/"build/armor-xs-site-pgo-v1"
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from machine import Elf, phase
dest=root/"pdocs/armor_grhsim/data"
def read(path):return json.loads(path.read_text())
def metrics(rows,tag,ref):
    speeds=[100*(r[tag]["external_wall_s"]/r[ref]["external_wall_s"]-1) for r in rows]
    diffs={ev:mean((r[tag]["counts"][ev]-r[ref]["counts"][ev])/r[tag]["guest_cycles"] for r in rows)
           for ev in rows[0][tag]["counts"]}
    return dict(wall_s=mean(r[tag]["external_wall_s"] for r in rows),paired_pct=mean(speeds),
                pct_range=[min(speeds),max(speeds)],pairs=speeds,delta_per_guest=diffs)
def archive():
    summary={}
    rows_for_csv=[]
    bins={}
    for group,expected in (("paths",2),("policies",3),("structural",3),("emitted",4),("frontend",3),("data",3),("robfactor",3)):
        summary[group]={}
        for wl in (("microbench",) if group in ("frontend","data") else ("coremark","microbench")):
            rounds=read(base/"pairs"/group/wl/"rounds.json")
            assert len(rounds)==expected
            summary[group][wl]={}
            for tag in rounds[0]["order"]:
                ref="generator" if group=="robfactor" else "both05"
                entry=metrics(rounds,tag,ref)
                entry["time_reference"]=ref
                if "gs_pgo" in rounds[0]:
                    entry["vs_gs_pct"]=metrics(rounds,tag,"gs_pgo")["paired_pct"]
                summary[group][wl][tag]=entry
            for i,row in enumerate(rounds,1):
                for j,t in enumerate(row["order"],1):
                    r=row[t];bins[t]=r["binary"]
                    rows_for_csv.append(dict(group=group,workload=wl,round=i,position=j,tag=t,cpu=row["cpu"],guest_cycles=r["guest_cycles"],
                           wall_s=r["external_wall_s"],**r["counts"],pmu_min_pct=min(r["counter_running_pct"].values()),
                           cpu_fraction=r["cpu_fraction"],placements=r["placements"],sibling_idle_min=min(v for k,v in r["sibling_idle"].items() if int(k)!=row["cpu"]),
                           sha256=r["binary"]["sha256"],dir=r["path"]))
    with (dest/"TNO0028_value_path_samples.csv").open("w") as f:
        writer=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in rows_for_csv for k in row)))
        writer.writeheader();writer.writerows(rows_for_csv)
    erows={}
    for tag,identity in bins.items():
        elf=Elf(Path(identity["path"]))
        erows[tag]=dict(identity=identity,text=elf.sec[".text"][2],
                        functions={ph:sum(size for name,(_,size) in elf.funcs.items() if phase(name)==ph) for ph in ("compute","commit")})
    verified={p.parent.name:{w:read(p.parent/w/"result.json") for w in ("coremark","microbench")}
              for p in (base/"verify").glob("*/coremark")}
    long={p.parent.name:read(p) for p in (base/"long").glob("*/coverage.json")}
    mods={}
    gs=base/"modules/gs_pgo";gr=old/"modules/gr_pgo"
    for wl in ("coremark","microbench"):
        mods[wl]={}
        for engine,d in (("gsim",gs),("grhsim",gr)):
            cov=read(d/"assignments.json")[wl];attr=read(d/"results.json")[wl]
            mods[wl][engine]={m:dict(assignments=v["visits"]/100001,assigned_instructions=attr["instructions"][m]["assignment_per_guest"],
                                    cycles=attr["cycles"][m]["per_guest"]) for m,v in cov.items()}
    clusters=read(base/"cluster.json")
    compact={s:{i:{**{key:x[key] for key in ("group","source_ops","readers")},"successors":len(x["successors"]),
                   "edges":[[e["g"],e["ops"],e["values"][:4]] for e in x["successors"][:3]]} for i,x in lanes.items()} for s,lanes in clusters.items()}
    dup=read(base/"dup/dup.json")
    data=dict(protocol="CoreMark training, seed 0, single-thread, DiffTest, 100001 guest cycles per timed run on node030",
              samples=len(rows_for_csv),results=summary,elf=erows,corrected_module_values=mods,
              by_op={w:{m:rows["kinds"] for m,rows in read(base/(w+".json")).items()} for w in mods},
              ftq_and_rob=read(base/"chain_counts.json"),gs_copy=read(base/"gs_copy.json"),
              sequence={w:read(base/"sequence"/w/"buckets.json") for w in mods},ibs=read(base/"ibs/commit.json"),
              ibs_always=read(base/"ibs/always.json"),selections={t:read(base/t/"selection.json") for t in ("direct","temporal")},
              clusters=compact,duplicated_graph_results=read(base/"equivalent_ops.json"),
              rob_pairs=dict(same_group_pairs=len(dup["sites"]),probed=dup["candidates"],entry67=[x for x in dup["sites"] if x["entry"]==67]),
              instructions={t:{f.stem:read(f) for f in (base/"elf"/t).glob("shard-*.json")} for t in ("both05","rob","ftq","generator","factorrob")},
              shadow={t:{w:read(base/t/w/"checked.json") for w in mods} for t in ("shadow","shadow-generator")},
              native_inventory=read(base/"generator/inventory.json"),verify=verified,full_microbench=long,
              profile_check=read(base/"generator/profile-check.json"),reemit=read(base/"reemit/matched.json"),
              rob_residual=read(base/"rob-residual.json"),factor_retrained=read(base/"factorrob/factor.json"),
              rejected_shard_profile=(base/"factor.log").read_text().strip(),
              ctest=(base/"final-ctest.log").read_text(),generator_stats=next(s for s in (base/"generator/emit.log").read_text().splitlines() if "[GRHSIM_PRIORITY_MUX_COMMIT_DEMAND]" in s))
    (dest/"TNO0028_value_paths.json").write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n")
    scripts=["paths","prototype","cluster","duplicates","chain_counts","elf_paths","gs_copy","sequence","select_sites","equivalent_ops","commit_ibs","pairs","cache_pairs","verify","long_trace","shadow","generator_run","reemit","native_audit","rob_residual","factor_shard","factor_rob","archive"]
    with tarfile.open(dest/"TNO0028_experiment_scripts.tar.gz","w:gz") as tar:
        tar.add(base/"REPRODUCE.md",arcname="REPRODUCE.md")
        for stem in scripts:tar.add(base/(stem+".py"),arcname=stem+".py")
if __name__=="__main__":archive()

