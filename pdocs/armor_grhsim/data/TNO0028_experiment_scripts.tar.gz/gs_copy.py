"""Locate machine instructions carrying a line for the two 64 by 32 GSIM FTQ copies."""
from collections import Counter
from pathlib import Path
import json,re,subprocess,sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from machine import BINS, OUT, LLVM, Elf, source_dir, save, Disassembler
from source_categories import read_lcov
label="gs_pgo"
elf=Elf(BINS[label]);debug=Elf(next((OUT/"lines"/label/"work").glob("*-compile/emu")))
name="SimTop238.cpp"
clines={ln for ln,line in enumerate((source_dir(label)/name).read_text().splitlines(),1)
        if re.search(r"perfQueue__DOT__cfiAttr__DOT__(rasAction|branchType)\$NEXT\[\d+\]\[\d+\] = ",line)}
assert len(clines)==4096
fun="SSimTop::subStep236()"
start,size=elf.funcs[fun];dbg,debug_size=debug.funcs[fun]
assert size==debug_size
proc=subprocess.Popen([LLVM/"llvm-objdump","-dlC",f"--start-address={dbg}",f"--stop-address={dbg+size}",debug.path],
                      stdout=subprocess.PIPE,text=True)
loc=None;ins=[]
dis=Disassembler()
for line in proc.stdout:
    if line.startswith(";"):
        m=re.search(re.escape(name)+r":(\d+)",line);loc=int(m[1]) if m else None
    elif loc in clines and (m:=re.match(r"^\s*([0-9a-f]+): ((?:[0-9a-f]{2} )*[0-9a-f]{2})\s+",line)):
        enc=bytes.fromhex(m[2]);pc=start+int(m[1],16)-dbg
        if elf.code(pc,len(enc))==enc:ins.append((pc,dis.get(elf.code(pc,16),pc),loc))
assert proc.wait()==0
res=dict(source_lines=len(clines),function=fun,lines_with_instructions=len(set(line for _,_,line in ins)),
         operations=Counter(expr.split()[0] for _,expr,_ in ins),examples=[(hex(pc),expr,ln) for pc,expr,ln in ins[:18]])
for wl in ("coremark","microbench"):
    for f,lines,_ in read_lcov(OUT/"coverage"/label/wl/"model.lcov"):
        if Path(f).name==name:
            res[wl]=dict(visits=sum(lines.get(n,0) for n in clines),probe_visits=lines[25011]);break
save(base/"gs_copy.json",res)

