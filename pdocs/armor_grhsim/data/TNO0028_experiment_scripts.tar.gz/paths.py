"""DWARF attribution, exact source coverage and RTL operation families for Rob and Ftq."""
from collections import Counter, defaultdict
from pathlib import Path
import json, re, sys
dest=Path(__file__).resolve().parent
root=dest.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from value_modules import GR_LOCAL, GR_VALUE, BINS, OUT, source_dir, symbolize, Elf, Disassembler, save
from source_categories import read_lcov
labels=("coremark","microbench")
stages=OUT/"audit/stages"
rtl_dir=root.parent/"wolvrix-playground-new-xiangshan/build/xs/kunminghu-v3-grhsim-merge-20261110/after/rtl-preparation/rtl/rtl"
modules=("Rob","Ftq")
rtl={m:(rtl_dir/(m+".sv")).read_text().splitlines() for m in modules}
ops={}
for line in (stages/"after-clone.ops.tsv").open():
    if '/Rob.sv"' not in line and '/Ftq.sv"' not in line:continue
    fields=line.rstrip("\n").split("\t")
    m=Path(fields[4].strip('"')).stem
    for v in fields[8].split(","):
        if v:ops[int(v)]=(m,fields[1],int(fields[5]),int(fields[6]))
names={}
for line in (stages/"after-clone.values.tsv").open():
    if line.startswith("id"):continue
    k,_,rest=line.partition("\t"); k=int(k)
    if k in ops:names[k]=rest.rsplit("\t",1)[-1].strip().strip('"').split("$")[-1]
def family(v):
    m,kind,line,col=ops[v]
    name=names[v]
    if re.fullmatch(r'_val_\d+|_T(?:_\d+)?|_GEN(?:_\d+)?',name):
        src=rtl[m][line-1] if line else ""
        w=re.search(r'(?:assign\s+|wire(?:\s+\[[^]]+\])?\s+)([\w$]+)\s*=',src)
        name=w[1] if w else "(anonymous)"
    return re.sub(r"\d+","#",name)
debug=Elf(next((OUT/"lines/gr_pgo/work").glob("*-compile/emu")))
elf=Elf(BINS["gr_pgo"])
assert elf.code(elf.sec[".text"][0],elf.sec[".text"][2])==debug.code(debug.sec[".text"][0],debug.sec[".text"][2])
for wl in labels:
    sampled=defaultdict(Counter)
    mdir=OUT/"machine/gr_pgo"/wl
    mix=json.loads((mdir/"attribution.json").read_text())
    allmetrics=json.loads((OUT/"metrics.json").read_text())[wl]["per_guest"]["gr_pgo"]
    ips={}
    for row in (mdir/"model-ips.tsv").read_text().splitlines():
        a,c,n,_=row.split()
        if int(c) or int(n):ips[int(a,16)]=int(c),int(n)
    for p,(path,ln,*_) in symbolize(debug.path,sorted(ips),dest).items():
        name=Path(path).name
        if "_sched_" in name and ln:
            c,n=ips[p]
            sampled[name,ln].update(c=c,n=n)
    rows=[]
    for file,lines,_ in read_lcov(OUT/"coverage/gr_pgo"/wl/"model.lcov"):
        p=Path(file)
        if "_sched_" not in p.name:continue
        ph=False;v=None;sn=None
        with p.open() as f:
            for ln,raw in enumerate(f,1):
                if raw.startswith("void "):ph="::eval_compute_batch_" in raw
                if not ph:continue
                t=raw.strip()
                if t.startswith("// Supernode "):sn=int(t.split()[2].rstrip(":"))
                if "// value " in t:
                    match=GR_VALUE.search(t);v=int(match[1]) if match else None
                elif t.startswith("// op ") or t=="}":v=None
                if match:=GR_LOCAL.match(t):owner=int(match[1])
                elif "next_value = " in t or "next_words = " in t:owner=v
                else:continue
                if owner not in ops:continue
                visit=lines.get(ln,0);freq=sampled.get((p.name,ln),{})
                if not visit and not freq:continue
                m,k,rl,col=ops[owner]
                rows.append([owner,m,k,rl,col,names[owner],family(owner),p.name,ln,sn,visit,freq.get("n",0),freq.get("c",0)])
    with (dest/(wl+".tsv")).open("w") as f:
        print("id\tmodule\tkind\trtl_line\trtl_col\tname\tfamily\tcpp\tline\tgroup\tvisits\tinstruction_samples\tcycle_samples",file=f)
        for row in rows:print(*row,sep="\t",file=f)
    result={}
    for m in modules:
        kinds=defaultdict(Counter);families=defaultdict(Counter)
        for v,mod,kind,rl,col,name,fam,path,ln,sn,vis,n,c in rows:
            if mod!=m:continue
            for group in (kinds[kind],families[fam]):
                group.update(vis=vis/100001,ins=n*allmetrics["instructions"]/mix["total"]["instructions"],cyc=c*allmetrics["cycles"]/mix["total"]["cycles"])
        result[m]=dict(kinds=sorted(kinds.items(),key=lambda item:-item[1]["ins"]),families=sorted(families.items(),key=lambda item:-item[1]["ins"])[:100])
    save(dest/(wl+".json"),result)

