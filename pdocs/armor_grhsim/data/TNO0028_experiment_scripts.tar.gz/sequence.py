"""Measure transition structure in actual site visitation order in the single-thread XiangShan harness."""
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import gzip
import json
import resource
import shutil
import struct
import sys

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
from diagnostics import DEFAULT, IMAGES, NEMU, OUT, WINDOW, clean_environment, execute, expected, parse_run, pick_cpu, save, signature
from grhsim_change_sites import ChangeSites

counter = r'''
#include <cstdint>
#include <cstdio>
#include <cstdlib>
namespace {
struct Stat { std::uint32_t visits{}, changes{}, transitions{}, misses{}; unsigned char last{}, state{}; };
Stat stats[@SIZE@];
__attribute__((noinline)) void count_site(unsigned i, bool v) {
    auto &s=stats[i];
    s.transitions += s.visits && v != s.last;
    s.misses += (s.state >= 2) != v;
    if (v) { if (s.state < 3) ++s.state; } else if (s.state) --s.state;
    ++s.visits;
    s.changes += v;
    s.last = v;
}
struct Writer {
    ~Writer() {
        auto *f=std::fopen("@RAW@", "wb");
        if (!f) std::abort();
        for (const auto &s: stats) {
            std::uint32_t row[] = {s.visits,s.changes,s.transitions,s.misses};
            if (std::fwrite(row,sizeof(row),1,f)!=1) std::abort();
        }
        if (std::fclose(f)!=0) std::abort();
    }
} writer;
}
#define GRHSIM_COUNT_SITE(kind,id,changed) count_site(GRHSIM_INDEX_##kind##id, changed)
'''

def band(kind, n, c, cycles):
    if kind == "SPARSE":
        if n < cycles//4: return "sparse/low visits"
        if 200*c <= n: return "sparse/up to 0.5%"
        if 20*c <= n: return "sparse/0.5 to 5%"
        return "sparse/over 5%"
    if n < cycles//100: return "commit/low visits"
    for lo,hi in [(0,20),(20,50),(50,80),(80,100)]:
        if 100*c < hi*n: return f"commit/{lo} to {hi}%"
    return "commit/always"

def main():
    dest=base/"sequence"; source=root/"build/armor-xs-site-pgo-v1/native/model"
    work=dest/"work"; model=work/"model"; model.mkdir(exist_ok=True,parents=True)
    for p in source.iterdir():
        if p.suffix in (".cpp",".hpp",".h") or p.name=="Makefile":shutil.copyfile(p,model/p.name)
    sites=ChangeSites(model,dest)
    for p,keys in sites.shards.items():
        with sites.header(p).open("w") as f:
            print(counter.replace("@SIZE@",str(len(keys))).replace("@RAW@",p.stem+".bin"),file=f)
            for i,(kind,id_) in enumerate(keys):
                print(f"#define GRHSIM_INDEX_{'V' if kind=='SPARSE' else 'R'}{id_} {i}",file=f)
    original=OUT/"sitewatch/gr_pgo"
    args=json.loads((original/"build.command.json").read_text())["argv"]
    args=[a.replace(str(original),str(dest)).replace("-j20","-j32").replace("JOBS=20","JOBS=32") for a in args]
    execute(args,"build",dest,dict(clean_environment(),NOOP_HOME=str(root/"testcase/xiangshan")),root)
    def run(wl):
        folder=dest/wl;folder.mkdir(exist_ok=True)
        cpu,_=pick_cpu()
        execute(["taskset","-c",str(cpu),"numactl","--membind=1","setarch","x86_64","-R",work/"grhsim-compile/emu","-i",
                 IMAGES[wl],"--diff",NEMU,"-b","0","-e","0","-s","0","-C",str(WINDOW)],"run",folder,clean_environment(),folder)
        assert signature(parse_run((folder/"run.log").read_text(),WINDOW))==expected("gr_pgo",wl)
        groups=defaultdict(Counter)
        with gzip.open(root/"build/armor-xs-site-pgo-v1/train-sites.tsv.gz","rt") as profile:
            version,digest,length=next(profile).split()
            assert digest==sites.digest
            for path,keys in sites.shards.items():
                assert next(profile).split()==[path.name,str(len(keys))]
                buf=(folder/(path.stem+".bin")).read_bytes()
                assert len(buf)==16*len(keys)
                for (k,i), (n,c,t,m) in zip(keys,struct.iter_unpack("=4I",buf)):
                    kind,id_,vis,chg=next(profile).split(); assert (k,i)==(kind,int(id_))
                    if wl=="coremark":assert (int(vis),int(chg))==(n,c)
                    b=band(k,int(vis),int(chg),int(length))
                    if n:groups[b].update(sites=1,n=n,c=c,t=t,m=m)
        save(folder/"buckets.json",groups)
    with ThreadPoolExecutor(2) as ex:list(ex.map(run,IMAGES))

if __name__=="__main__":
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    main()
