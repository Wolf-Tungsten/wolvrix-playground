"""Repeat the final C++ emission through the Make target and compare model source bytes."""
from pathlib import Path
import hashlib
import json
import resource
import sys

base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts"))
from armor_xs_pgo_build import execute
from grhsim_single_baseline import clean_environment,save
resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
dest=base/"reemit";model=dest/"model"
logged=json.loads((base/"generator/emit.command.json").read_text())["argv"]
filelist=Path(logged[2])
old=root/"build/armor-xs-site-pgo-v1"
args=json.loads((old/"both05/pgo.command.json").read_text())["argv"]
options=[x for x in args if x.startswith(("PGO_WORKLOAD=","XS_DIFFTEST_GEN_DIR=","XS_DIFFTEST_MACROS=","PYTHON="))]
cmd=["make","--no-print-directory","-o",str(filelist),"-o","py_install","xs_wolf_grhsim_emit",
     "WOLF_ENV_SOURCED=1",f"XS_WOLF_FILELIST={filelist}",f"XS_WOLF_GRHSIM_EMIT_DIR={model}",f"XS_LOG_DIR={dest/'logs'}",f"XS_GRHSIM_BUILD={dest/'build'}",
     "XS_GRHSIM_SITE_PGO=both","XS_WOLF_GRHSIM_RESUME_FROM_PRE_REG_TO_MEM_JSON=1",
     f"XS_WOLF_GRHSIM_PRE_REG_TO_MEM_JSON={root/'build/armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json'}",*options]
env=dict(clean_environment(),PYTHONPATH=str(root/"build/armor-dispatch-v1/tools/python"),LD_LIBRARY_PATH=str(root/"build/armor-dispatch-v1/tools"),
         WOLVRIX_GRHSIM_PRIORITY_MUX_COMMIT_DEMAND="1",WOLVRIX_GRHSIM_PRIORITY_MUX_MIN_CHAIN_LENGTH="13")
execute(cmd,"emit",dest,env,root)
def digest(m):
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in m.iterdir() if p.suffix in (".cpp",".h",".hpp") or p.name=="Makefile"}
first=digest(base/"generator/model")
second=digest(model)
assert first==second,sorted(k for k in first.keys()|second.keys() if first.get(k)!=second.get(k))
save(dest/"matched.json",dict(files=len(first),sha256=hashlib.sha256(json.dumps(first,sort_keys=True).encode()).hexdigest()))

