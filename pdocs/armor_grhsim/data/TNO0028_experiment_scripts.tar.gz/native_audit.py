"""Verify all site counts and enumerate the registers receiving deferred muxes."""
from collections import Counter, defaultdict
from itertools import zip_longest
from pathlib import Path
import gzip
import hashlib
import json
import re

base = Path(__file__).resolve().parent
target = base / "generator"
native = base.parent / "armor-xs-site-pgo-v1"

def verify_counts():
    digest = hashlib.sha256()
    counts = Counter()
    with gzip.open(native / "train-sites.tsv.gz", "rb") as reference, gzip.open(target / "build/grhsim-sites.tsv.gz", "rb") as actual:
        old = next(reference).split()
        new = next(actual).split()
        assert old[0] == new[0] and old[2] == new[2] and old[1] != new[1]
        for a,b in zip_longest(reference,actual):
            assert a is not None and a == b
            kind = a.split(None,1)[0].decode() if a.startswith((b"SPARSE",b"EAGER")) else "shards"
            counts[kind] += 1
            digest.update(a)
    return dict(old_source_sha256=old[1].decode(), new_source_sha256=new[1].decode(),
                identical_count_rows=counts, sha256_body=digest.hexdigest())

def inventory():
    roots = {}
    users = defaultdict(list)
    for path in (target / "model").glob("*_sched_*.cpp"):
        source = path.read_text()
        if "// Demand-evaluate terminal" not in source:continue
        pending = False
        register = None
        for row in source.splitlines():
            if pending:
                slot = re.match(r"\s*(value_(?:bool|u\d+)_slots_\[\d+\]) = ",row)[1]
                assert slot not in roots
                roots[slot] = row.count(" ? ")
                pending = False
            if "// Demand-evaluate terminal" in row:
                pending = True
            if "// op " in row:
                register = row.strip().split("reg=")[-1] if "[kRegisterWritePort]" in row else None
            if register and "const auto next_value =" in row:
                for slot in re.findall(r"value_(?:bool|u\d+)_slots_\[\d+\]",row):users[slot].append(register)
    ftq = {f"value_u8_slots_[{m['slot']}]" for m in json.loads((base / "ftq/ftq.json").read_text())["sites"]}
    return dict(chains=len(roots), frozen_ftq=len(ftq & roots.keys()), lengths=Counter(roots.values()),
                additional={s:users[s] for s in sorted(roots.keys() - ftq)})
if __name__=="__main__":
    for name,rows in (("inventory",inventory()),("profile-check",verify_counts())):
        (target / (name+".json")).write_text(json.dumps(rows,indent=2)+"\n")

