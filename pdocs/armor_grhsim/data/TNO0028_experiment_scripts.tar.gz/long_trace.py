"""Verify the baseline and both selected features beyond the training horizon."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import re
import resource
import sys
import time

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
from diagnostics import DEFAULT, IMAGES, NEMU, parse_run, signature, execute, clean_environment, pick_cpu, save
from grhsim_difftrace import compare_traces

def run(tag):
    binary = DEFAULT/"pgo/build/emu" if tag == "baseline" else base/tag/"build/emu"
    while not binary.exists():
        time.sleep(10)
    out = base/"long"/tag
    done = out/"run.result.json"
    if not done.exists():
        cpu, _ = pick_cpu()
        execute(["taskset","-c",str(cpu),"numactl","--membind=1","setarch","x86_64","-R",binary,
                 "-i",IMAGES["microbench"],"--diff",NEMU,"-b","0","-e","0","-s","0","-C","250000",
                 "--dump-difftrace","./trace"],"run",out,clean_environment(),out)
    if json.loads(done.read_text())["returncode"]: raise RuntimeError(tag)
    text = re.sub(r"\x1b\[[0-9;]*m", "", (out/"run.log").read_text())
    if "MicroBench PASS" not in text or "Difftest enabled" not in text or "HIT GOOD TRAP" not in text:
        raise ValueError(text[-900:])
    # Strip interleaved harness progress before comparing all guest UART text.
    clean = re.sub(r"\[CYCLE_LIMIT\] cycles=\d+ max_cycles=\d+\n", "", text)
    end = dict(stop="good-trap", pc=re.search(r"HIT GOOD TRAP at pc = (0x\w+)",text)[1],
               instr=int(re.search(r"instrCnt = ([\d,]+)",text)[1].replace(",","")),
               cycle=int(re.search(r"cycleCnt = ([\d,]+)",text)[1].replace(",","")),
               guest_cycles=int(re.search(r"Guest cycle spent: ([\d,]+)",text)[1].replace(",","")),
               output=clean[clean.index("MicroBench",clean.index("Difftest enabled")):clean.index("Core 0: HIT GOOD TRAP")])
    save(out/"endpoint.json",end)
    return end

resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
with ThreadPoolExecutor(max_workers=3) as pool:
    futures = {tag:pool.submit(run,tag) for tag in ("baseline",*sys.argv[1:])}
    ref = futures.pop("baseline").result()
    for tag,future in futures.items():
        assert future.result() == ref
        out = base/"long"/tag
        result = compare_traces(root/"build/armor-xs-pgo-v1/gsim/verify/comparator/compare",
                                base/"long/baseline/trace",out/"trace",out/"trace.json")
        assert result["pass_"] and result["records"] > 0 and result["last_cycle"] == ref["cycle"]
        save(out/"coverage.json", {k:result[k] for k in ("records","first_cycle","last_cycle","pass_")})
