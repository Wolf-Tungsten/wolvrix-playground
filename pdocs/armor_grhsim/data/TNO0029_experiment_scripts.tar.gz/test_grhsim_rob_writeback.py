"""Exercise ROB profile replay with a site-training include and a changed model."""
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from grhsim_change_sites import model_digest
from grhsim_rob_writeback import load_writeback_profile, specialize_writeback


class WritebackProfileTest(unittest.TestCase):
    def test_model_identity_and_private_include(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            model = folder / "model"
            model.mkdir()
            source = model / "a.cpp"
            original = b"// before\nint a;\n"
            result = b"// after\nint a;\n"
            source.write_bytes(original)
            header = model / "a.hpp"
            header.write_text("class A {};\n")
            profile_path = folder / "profile.json.gz"
            profile = {
                "format": "grhsim-rob-writeback-v1",
                "model": model_digest(model),
                "files": {
                    "a.cpp": {
                        "source": hashlib.sha256(original).hexdigest(),
                        "result": hashlib.sha256(result).hexdigest(),
                        "edits": [[0, 1, "// after\n"]],
                    }
                },
            }
            with gzip.open(profile_path, "wt") as stream:
                json.dump(profile, stream)

            accepted = load_writeback_profile(profile_path, model_digest(model))
            header.write_text("class B {};\n")
            with self.assertRaisesRegex(ValueError, "expects model"):
                load_writeback_profile(profile_path, model_digest(model))
            for prefix in (b"", b'#include "a.sites.h"\n'):
                with self.subTest(prefix=prefix):
                    source.write_bytes(prefix + original)
                    specialize_writeback(model, accepted)
                    self.assertEqual(source.read_bytes(), prefix + result)
            source.write_bytes(b"int unrelated;\n")
            with self.assertRaisesRegex(ValueError, "source mismatch"):
                specialize_writeback(model, accepted)
            self.assertEqual(source.read_bytes(), b"int unrelated;\n")

    def test_insert_and_delete_with_result_check(self):
        with tempfile.TemporaryDirectory() as tmp:
            model = Path(tmp)
            source = model / "model.cpp"
            original = b"first\nsecond\nthird\n"
            expected = b"prefix\nsecond\nthird\ntail\n"
            source.write_bytes(original)
            change = {
                "source": hashlib.sha256(original).hexdigest(),
                "result": hashlib.sha256(expected).hexdigest(),
                "edits": [[0, 0, "prefix\n"], [0, 1, ""], [3, 0, "tail\n"]],
            }
            profile = {"files": {source.name: change}}
            specialize_writeback(model, profile)
            self.assertEqual(source.read_bytes(), expected)

            source.write_bytes(original)
            change["edits"][-1] = [3, 0, "different\n"]
            with self.assertRaisesRegex(ValueError, "result mismatch"):
                specialize_writeback(model, profile)
            self.assertEqual(source.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()

