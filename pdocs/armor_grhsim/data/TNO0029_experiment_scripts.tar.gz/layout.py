"""Join proven graph inputs and sinks to the frozen generated scalar storage."""
from collections import Counter,defaultdict
from pathlib import Path
import json,re,sys
base=Path(__file__).resolve().parent
root=base.parents[1]
model=root/"build/armor-xs-value-paths-v1/generator/model"
address=sys.argv[1:]==["paddr"]
proof=json.loads((base/("paddr-proof.json" if address else "proof.json")).read_text())
roots={v for w in proof["writes"] for v in (w["guard"],w["value"])}
extra={p["id"] for p in proof["ports"] if not p["reg"]}
states={p["reg"] for p in proof["ports"] if p["reg"]}
data={}
leaf={}
sources={}
want=roots|extra
candidate_ids={str(i) for i in want}
comment=re.compile(r" -> (value_(?:bool|u\d+)_slots_\[\d+\]) \[value_id=(\d+):0\]")
member=re.compile(r"state_logic_storage_\.(?:bool|u\d+)_slots_\d+")
reg=re.compile(r"// op \S+ \[kRegisterWritePort\] reg=(\S+)")
fields=re.compile(r"\$rob\$debug_(lqIdx|sqIdx|exuData)_(\d+)_(0|1)(?:_value)?$")
address_field=re.compile(r"\$rob\$dt_exuDebug_(\d+)_(0|1)_paddr$")
records=defaultdict(dict)
pending=defaultdict(list)
for p in sorted(model.glob("*_sched_*.cpp")):
    rows=p.read_text().splitlines()
    for j,row in enumerate(rows):
        if "[value_id=" in row and (m:=comment.search(row)) and m[2] in candidate_ids:
            i=int(m[2]); target=m[1]
            assert i not in sources or sources[i]==target
            sources[i]=target
            if i in roots:
                block="\n".join(rows[j+1:j+5])
                plain=block.splitlines()
                if len(plain)==4 and plain[0].strip()=="{" and plain[1].strip().startswith("const ") and " next_value = " in plain[1] and plain[2].strip()==target+" = next_value;" and plain[3].strip()=="}":
                    pending[i].append((p.name,j+1))
            continue
        if "[kRegisterWritePort]" not in row or not (m:=reg.search(row)):continue
        symbol=m[1]
        match=address_field.search(symbol) if address else fields.search(symbol)
        if symbol not in states and not match:continue
        excerpt=[]
        for r in rows[j+1:j+55]:
            if "// op " in r:break
            excerpt.append(r)
        body="\n".join(excerpt)
        if symbol in states:
            candidates=set(member.findall(body))
            if len(candidates)!=1:
                # Inline commit can read other state, identify the actual destination.
                candidates=set(re.findall(r"(state_logic_storage_\.(?:bool|u\d+)_slots_\d+) (?:!= next_value|= next_value)",body))
            if len(candidates)==1:
                selected,=candidates
                assert leaf.get(symbol,selected)==selected;leaf[symbol]=selected
        else:
            key=("paddr",int(match[1]),int(match[2])) if address else (match[1],int(match[2]),int(match[3]))
            records[key].update(file=p.name,line=j+1)
slots={sources[v]:v for v in roots if v in sources}
assert len(slots)==len([v for v in roots if v in sources])
# Count every scalar read and every address range overlapping a destination.
slot_re=re.compile(r"value_(bool|u\d+)_slots_\[(\d+)\]")
ptr_re=re.compile(r"value_(bool|u\d+)_slots_\.data\(\) \+ (\d+)u")
slot_lookup={(m[1],int(m[2])):v for s,v in slots.items() if (m:=slot_re.fullmatch(s))}
compute=Counter();commit=Counter();other=Counter();blocked=set();bulk=defaultdict(set)
for p in sorted(list(model.glob("*.cpp"))+list(model.glob("*.hpp"))):
    phase="other"
    for n,r in enumerate(p.open(),1):
        if r.startswith("void "):
            phase="commit" if "::eval_commit_batch_" in r else "compute" if "::eval_compute_batch_" in r else "other"
        stripped=r.lstrip()
        if stripped.startswith(("//","#")):continue
        if "_slots_[" not in r and "_slots_.data()" not in r:continue
        for t,num in slot_re.findall(r):
            i=slot_lookup.get((t,int(num)))
            if i is not None:{"commit":commit,"compute":compute,"other":other}[phase][i]+=1
        for m in ptr_re.finditer(r):
            start=int(m[2]);tail=r[m.end():]
            if "std::memcmp" in r:
                length=int(re.search(r"(\d+)u \* sizeof",tail)[1])
            elif "grhsim_store_scalar_slices<" in r:
                length=r.partition("grhsim_store_scalar_slices<")[2].partition(">")[0].count(",")
            else:raise ValueError((p.name,n,r[:200]))
            for k in range(start,start+length):
                if (v:=slot_lookup.get((m[1],k))) is not None:
                    bulk[v].add(phase)
                    if phase!="commit" or "std::memcmp" not in r:blocked.add(v)
# Disabled data is only defined under its write guard. Exclude indirect data reads.
guards={w["guard"] for w in proof["writes"]}
uses=Counter(w[k] for w in proof["writes"] for k in ("value","guard"))
for p in proof["ports"]:
    expr=leaf.get(p["reg"]) if p["reg"] else sources.get(p["id"])
    if expr:p["source"]=expr
counts=Counter()
for w in proof["writes"]:
    w["commit"]=records[w["field"],w["row"],w["half"]]
    for k in ("guard","value"):
        i=w[k];slot=sources.get(i);part=dict(slot=slot,blocks=pending[i],compute_uses=compute[i],commit_uses=commit[i],bulk=sorted(bulk[i]),other=other[i])
        # Shared scalar enables may protect other state, not just the proven field.
        # For these leave the producer and all original slot values intact.
        simple=bool(slot and len(pending[i])==1 and compute[i]==1 and not other[i] and i not in blocked)
        # Reconstruct every guard exactly. Direct reads by other commit writers are safe.
        # Data must be exclusive to the checked writer; bulk memcpy/reads are excluded.
        part["eligible"]=simple and (k=="guard" or (commit[i]==1 and uses[i]==1 and not bulk[i]))
        counts[w["field"]+"/"+k+"/"+str(part["eligible"])]+=1
        w[k+"_storage"]=part
res=dict(ports=proof["ports"],writes=proof["writes"],counts=counts,source_missing=[p for p in proof["ports"] if "source" not in p])
(base/("paddr-layout.json" if address else "layout.json")).write_text(json.dumps(res,indent=1)+"\n")
print(counts,"missing leaves",res["source_missing"],flush=True)

