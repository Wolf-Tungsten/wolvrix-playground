"""Compare the actual text and model symbols from an experiment and an independent Make build."""
from pathlib import Path
import hashlib
import json
import re
import sys

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
from machine import Elf


def hexdigest(data):
    return hashlib.sha256(data).hexdigest()


def compare(tag, rebuilt):
    original = Elf(base / tag / "build/emu")
    replay = Elf(base / rebuilt / "build/emu")
    sections, changed = {}, []
    for name in (".text", ".rodata"):
        hashes = []
        chunks = []
        for elf in (original, replay):
            _, offset, length = elf.sec[name]
            chunk = memoryview(elf.data)[offset:offset + length]
            chunks.append(chunk)
            hashes.append(hexdigest(chunk))
        sections[name] = {"sha256": hashes, "identical": hashes[0] == hashes[1]}
        if name == ".rodata" and hashes[0] != hashes[1]:
            # Difftest's compile banner stores __DATE__ and __TIME__ as adjacent C strings.
            timestamp = rb"\0(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) [ \d]\d \d{4}\0\d\d:\d\d:\d\d\0"
            normalized = [re.sub(timestamp, b"<compiled at>", chunk) for chunk in chunks]
            sections[name]["equal_excluding_compile_banner"] = normalized[0] == normalized[1]
    names = {n for e in (original, replay) for n in e.funcs if n.startswith(("GrhSIM_SimTop::", "grhsim_"))}
    for name in sorted(names):
        if name not in original.funcs or name not in replay.funcs:
            changed.append([name, "missing"])
            continue
        if original.code(*original.funcs[name]) != replay.code(*replay.funcs[name]):
            changed.append([name, original.funcs[name], replay.funcs[name]])
    out = dict(prototype=tag, make=rebuilt, elf_sha256=[hexdigest(e.data) for e in (original, replay)],
               section=sections, generated_model_functions=len(names), different_model_functions=changed)
    if not sections[".text"]["identical"]:
        others = (original.funcs.keys() | replay.funcs.keys()) - names
        out["different_other_functions"] = [
            name for name in sorted(others)
            if name not in original.funcs or name not in replay.funcs
            or original.code(*original.funcs[name]) != replay.code(*replay.funcs[name])
        ]
    (base / rebuilt / "comparison.json").write_text(json.dumps(out, indent=2) + "\n")
    print(tag, rebuilt, sections[".text"]["identical"], len(names), len(changed))


if __name__ == "__main__":
    compare(*sys.argv[1:])

