"""Independently test whether neighboring physical-address payloads obey the same priority."""
from collections import Counter
from pathlib import Path
import json,re
import proof as graph
from proof import base,stages,canonical,get_bdd,variable,conj,inv,disj,ite,width
regex=re.compile(rb'\$rob\$io_(?:exuWriteback|writeback)_(\d+)_bits_debug_paddr"$')
regs={}
for line in (stages/"after-clone.values.tsv").open("rb"):
    if b"_bits_debug_paddr" in line and (m:=regex.search(line)):
        c=int(line.split(b"\t",2)[1])
        regs[c]=(int(m[1]),"bits_debug_paddr")
graph.portids.update(regs)
# Allocate distinct address payload variables in the same BDD, after the port control inputs.
# Each proof checks a single payload bit; the distinct address namespace keeps shifted bits independent.
oldvariable=graph.variable
def pvar(p,role,bit=0):
    if role=="bits_debug_paddr":return graph.make(4000+p*48+bit,0,1)
    return oldvariable(p,role,bit)
graph.variable=pvar
writes=[];source_regs={}
for line in (stages/"after-clone.ops.tsv").open("rb"):
    if b"\tkRegisterReadPort\t" in line:
        result=int(line.rstrip(b"\n").rsplit(b"\t",1)[1])
        if result in regs:
            source_regs[result]=re.search(rb'\["regSymbol",3,"([^"]+)"\]',line)[1].decode()
    if b"\tkRegisterWritePort\t" not in line or b"_paddr" not in line:continue
    if m:=re.search(rb'\$rob\$dt_exuDebug_(\d+)_(0|1)_paddr"\]\]',line):
        x=line.rstrip(b"\n").split(b"\t")
        en,data,mask,clk=(canonical[int(v)] for v in x[7].split(b","))
        assert ["eventEdge",7,["posedge"]] in json.loads(x[3]) and clk==2 and graph.number(mask)==(1<<48)-1
        writes.append((int(m[1]),int(m[2]),int(x[0]),en,data))
assert len(writes)==320
pass_fields=0;failed=[]
for row,half,op,en,data in writes:
    expr=get_bdd(row)
    hits=[];expected=0
    for p in range(29):
        f=variable(p,"bits_robIdx_isFormer");h=conj(conj(variable(p,"eq"),variable(p,"valid")),inv(f) if half else f)
        hits.append(h);expected=disj(expected,h)
    assert expected==expr(en)
    try:
        for bit in range(48):
            out=0
            for p,h in enumerate(hits):
                val=pvar(p,"bits_debug_paddr",bit) if p in (*range(9,17),*range(19,29)) else 0
                out=ite(h,val,out)
            observed=expr(data,bit)
            if conj(expected,observed)!=conj(expected,out):
                failed.append([row,half,"priority differs",bit]);break
        else:pass_fields+=1
    except (KeyError,ValueError,AssertionError) as e:failed.append([row,half,"extra dependency",str(e)])
    expr.cache_clear()
result=dict(guard_proved=len(writes),payload_bits_proved=48*pass_fields,fields_proved=pass_fields,leaves=len(regs),first_rejections=failed[:4],
            by_reason=Counter(x[2] for x in failed))
(base/"paddr.json").write_text(json.dumps(result,indent=2)+"\n")
assert not failed and len(source_regs)==18
assert set(regs.values())=={(p,"bits_debug_paddr") for p in (*range(9,17),*range(19,29))}
(base/"paddr-proof.json").write_text(json.dumps(dict(writes=[dict(row=r,half=h,field="paddr",op=o,guard=g,value=v) for r,h,o,g,v in writes],
    ports=[dict(port=p,role=role,id=i,reg=source_regs[i]) for i,(p,role) in regs.items()]),indent=1)+"\n")

