"""Archive the exact generated source edits for replay on the proved XiangShan model."""
from pathlib import Path
import gzip,hashlib,json,re,subprocess,tempfile,sys
base=Path(__file__).resolve().parent
root=base.parents[1]
original=root/"build/armor-xs-value-paths-v1/generator/model"
def export(tag,output):
    digest=hashlib.sha256();files={}
    with tempfile.TemporaryDirectory() as scratch:
        tmp=Path(scratch)/"after.cpp"
        for p in sorted(original.iterdir()):
            if p.name!="Makefile" and p.suffix not in (".cpp",".h",".hpp"):continue
            before=p.read_bytes()
            digest.update(p.name.encode()+b"\0"+hashlib.sha256(before).digest())
            after=(base/tag/"model"/p.name).read_bytes()
            header=f'#include "{p.with_suffix(".sites.h").name}"\n'.encode()
            if p.suffix==".cpp" and after.startswith(header):after=after[len(header):]
            if before==after:continue
            tmp.write_bytes(after)
            result=subprocess.run(["diff","--speed-large-files","-U0",p,tmp],stdout=subprocess.PIPE)
            assert result.returncode==1
            rows=after.splitlines(keepends=True);edits=[]
            for m in re.finditer(rb"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@",result.stdout,re.M):
                first,count,new_first,new_count=[int(x if x is not None else b"1") for x in m.groups()]
                edits.append([first-1 if count else first,count,b"".join(rows[new_first-1:new_first-1+new_count]).decode() if new_count else ""])
            assert edits
            files[p.name]=dict(source=hashlib.sha256(before).hexdigest(),result=hashlib.sha256(after).hexdigest(),edits=edits)
    data=dict(format="grhsim-rob-writeback-v1",model=digest.hexdigest(),fields=["debug_lqIdx","debug_sqIdx","debug_exuData"]+(["dt_exuDebug_paddr"] if tag.startswith("address") else []),
              entries=160,halves=2,writeback_ports=29,allocation_ports=8,variant=tag,files=files)
    with output.open("wb") as raw,gzip.GzipFile(filename="",mode="wb",mtime=0,fileobj=raw) as g:g.write(json.dumps(data,separators=(",",":")).encode()+b"\n")
    print(tag,len(files),output.stat().st_size,digest.hexdigest(),flush=True)
if __name__=="__main__":export(sys.argv[1],Path(sys.argv[2]))

