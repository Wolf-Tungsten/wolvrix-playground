"""Check every guard and enabled payload, including cycles beyond the training window."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,re,resource,sys,time
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import IMAGES,NEMU,parse_run,signature,expected,clean_environment,execute,save,pick_cpu
resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
dest=base/"shadow"
while not (dest/"build.result.json").exists():time.sleep(5)
assert json.loads((dest/"build.result.json").read_text())["returncode"]==0
def run(wl):
    out=dest/wl;limit=100000 if wl=="coremark" else 250000
    cpu,_=pick_cpu()
    execute(["taskset","-c",str(cpu),"numactl","--membind=1",dest/"work/grhsim-compile/emu","-i",IMAGES[wl],"--diff",NEMU,"-b","0","-e","0","-s","0","-C",str(limit)],"run",out,clean_environment(),out)
    text=(out/"run.log").read_text()
    clean=re.sub(r"ROB_SHADOW [\d ]+\n","",text)
    if wl=="coremark":
        assert signature(parse_run(clean,limit))==expected("gr_pgo",wl)
    else:
        assert "MicroBench PASS" in clean and "HIT GOOD TRAP" in clean and "326,377" in clean
    rows=re.findall(r"ROB_SHADOW ([0-9 ]+)\n",text)
    assert rows
    records=[dict(zip(("edges","wb_ports","rows_with_collision","rows_with_enq_and_wb","enq_only","lq_writes","wb_rows"),map(int,r.split()))) for r in rows]
    guest=int(re.search(r"Guest cycle spent: ([\d,]+)",clean)[1].replace(",",""))
    save(out/"checked.json",dict(guest_cycles=guest,asserted_fields=960,checkpoints=records))
with ThreadPoolExecutor(2) as ex:list(ex.map(run,IMAGES))

