"""Count input cones, shared predicates, outside users and dynamic checks before removing terminal writes."""
from collections import Counter,defaultdict,deque
import csv,gzip,json,re,sys
from proof import base,root,stages,canonical,opname,kind,inputs,portids
proof=json.loads((base/"proof.json").read_text())
extended=sys.argv[1:]==["address"]
if extended:
    extra=json.loads((base/"paddr-proof.json").read_text())
    proof["writes"].extend(extra["writes"])
    portids=dict(portids)
    portids.update({p["id"]:(p["port"],p["role"]) for p in extra["ports"]})
use=defaultdict(set)
def walk(seeds):
    q=list(seeds);found=set()
    while q:
        i=q.pop()
        if i in found or i in portids:continue
        k=opname[kind[i]]
        if k=="kConstant":continue
        found.add(i);q.extend(inputs(i))
    return found
cones={f+"/"+k:walk([w[k] for w in proof["writes"] if w["field"]==f]) for f in sorted({w["field"] for w in proof["writes"]}) for k in ("guard","value")}
all_nodes=set.union(*cones.values());writeops={w["op"] for w in proof["writes"]}
# Compute actual outside reads. Union cloned graph values only for this accounting.
# One active clone still prevents removing its canonical expression as a whole.
outside=Counter();live=set()
for line in (stages/"after-clone.ops.tsv").open("rb"):
    if line.startswith(b"id\t"):continue
    op,k,s,attr,file,ln,col,ins,outs=line.rstrip(b"\n").split(b"\t")
    if not ins:continue
    if outs and b"," not in outs and canonical[int(outs)] in all_nodes:
        continue
    if int(op) in writeops:continue
    for a in ins.split(b","):
        v=canonical[int(a)]
        if v in all_nodes:live.add(v);outside[opname[kind[v]]]+=1
direct=set(live);q=list(live)
while q:
    v=q.pop()
    for a in inputs(v):
        if a in all_nodes and a not in live:
            live.add(a);q.append(a)
exclusive=all_nodes-live
groups={k:len(v) for k,v in cones.items()}
intersect={a:{b:len(v&x) for b,x in cones.items()} for a,v in cones.items()}
wlout={}
for wl in ("coremark","microbench"):
    metrics=defaultdict(Counter)
    old=root/"build/armor-xs-value-paths-v1"
    with (old/(wl+".tsv")).open() as f:
        for row in csv.DictReader(f,delimiter="\t"):
            v=canonical[int(row["id"])]
            if v in all_nodes:metrics["exclusive" if v in exclusive else "shared"].update(visits=int(row["visits"]),ins_samples=int(row["instruction_samples"]))
    # This limits source attribution to named RTL origins carried by TNO0028.
    wlout[wl]=metrics
records=defaultdict(Counter)
with gzip.open(root/"build/armor-xs-value-paths-v1/generator/build/grhsim-sites.tsv.gz","rt") as f:
    next(f)
    for line in f:
        name,n=line.split()
        for j in range(int(n)):
            k,i,vis,chg=next(f).split()
            v=canonical[int(i)] if k=="SPARSE" else None
            if v in all_nodes:
                records["exclusive" if v in exclusive else "shared"].update(sites=1,visits=int(vis),changes=int(chg))
raw_to_excl=[i for i in range(1,len(canonical)) if canonical[i] in exclusive]
(base/("exclusive-address.txt" if extended else "exclusive.txt")).write_text("\n".join(map(str,raw_to_excl))+"\n")
res=dict(unique=len(all_nodes),direct_outside=len(direct),exclusive=len(exclusive),by_root=groups,pairwise=intersect,
         by_kind=Counter(opname[kind[i]] for i in all_nodes),old_src_samples=wlout,exact_coremark_site_counts=records)
(base/("cone-address.json" if extended else "cone.json")).write_text(json.dumps(res,indent=2)+"\n")

