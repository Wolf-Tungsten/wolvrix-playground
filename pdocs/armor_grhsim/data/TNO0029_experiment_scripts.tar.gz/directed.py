"""Exercise the exact generated helper against a row-by-row independent reference."""
from collections import defaultdict
from pathlib import Path
import json,re,subprocess,sys
base=Path(__file__).resolve().parent; root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import LLVM
address=sys.argv[1:]==["address"]
d=json.loads((base/"layout.json").read_text())
if address:
    additional=json.loads((base/"paddr-layout.json").read_text())
    for key in ("ports","writes"):d[key].extend(additional[key])
out=base/("directed-address" if address else "directed");out.mkdir(exist_ok=True)
model=base/("address" if address else "ports")/"model"
body=(model/"grhsim_SimTop_eval.cpp").read_text().partition("void GrhSIM_SimTop::prepare_rob_writeback")[2]
assert body.strip().endswith("}")
preamble="""#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <random>
#include <cstdlib>
class GrhSIM_SimTop {
public:
    std::array<std::uint16_t,37> rob_touched_rows_{};
    std::size_t rob_touched_count_{};
    void prepare_rob_writeback(bool initialize=false);
"""
types={"bool":"bool","u8":"std::uint8_t","u64":"std::uint64_t"}
slots=defaultdict(list);state={}
port={(p["port"],p["role"]):p["source"] for p in d["ports"]}
for p in d["ports"]:
    e=p["source"]
    if m:=re.fullmatch(r"value_(\w+)_slots_\[(\d+)\]",e):slots[m[1]].append(int(m[2]))
    else:
        m=re.fullmatch(r"state_logic_storage_\.(\w+)_slots_(\d+)",e)
        assert m,e
        state[e.split(".")[1]]=types[m[1]]
for w in d["writes"]:
    for k in ("guard","value"):
        m=re.fullmatch(r"value_(\w+)_slots_\[(\d+)\]",w[k+"_storage"]["slot"]);slots[m[1]].append(int(m[2]))
for t,ids in slots.items():preamble+=f"    std::array<{types[t]}, {max(ids)+1}> value_{t}_slots_{{}};\n"
preamble+="    struct State {\n"+"".join("        "+t+" "+name+"{};\n" for name,t in state.items())+"    } state_logic_storage_;\n};\n"
source=preamble+"void GrhSIM_SimTop::prepare_rob_writeback"+body
source+="""
struct Port { unsigned row; bool former, valid; unsigned char lq,sq; std::uint64_t data,address; };
int main() {
    auto model=std::make_unique<GrhSIM_SimTop>();
    std::mt19937_64 gen(88077);
    model->prepare_rob_writeback(true);
    constexpr unsigned rounds=1500;
    for (unsigned round=0; round<rounds; ++round) {
        std::array<Port,37> ports{};
        if (round%43==0) model->prepare_rob_writeback(true);
        for (unsigned p=0;p<37;++p) {
            unsigned row=gen()%256;
            bool former=(gen()&1)!=0, valid=(gen()&1)!=0;
            // All 37 collide, same address opposite halves, all invalid,
            // 29 isolated winners, then no writes to the previously active rows.
            if (round==0 || round==1 || round==3) { valid=true; former=round!=1 || (p%2==0); row=round==3?160u+p:79u; }
            if (round==2 || round==4) valid=false;
            if (round>=5 && round<34) { valid=p==round-5 || p>=29; row=159; former=true; }
            if (round%3==1 && round>=34) row=round%160;
            unsigned char lq=static_cast<unsigned char>(gen()&127),sq=static_cast<unsigned char>(gen()&63);
            std::uint64_t data=gen();
            ports[p]={row,former,valid,lq,sq,data,gen() & UINT64_C(0xffffffffffff)};
        }
"""
sources={"bits_robIdx_value":"row","bits_robIdx_isFormer":"former","valid":"valid","bits_sqIdx_value":"sq","bits_lqIdx_value":"lq","bits_data":"data"}
sources["bits_debug_paddr"]="address"
for (p,r),code in port.items():source+=f"        model->{code}=ports[{p}].{sources[r]};\n"
source+="""        model->prepare_rob_writeback();
        for (unsigned i=0;i<320;++i) {
            int winner=-1;
            bool allocate=false;
            for (unsigned p=0;p<ports.size();++p) {
                if (!ports[p].valid || ports[p].row!=i/2 || ports[p].former!=(i%2==0)) continue;
                if (p<29) winner=static_cast<int>(p); else allocate=true;
            }
            bool wb=winner>=0;
            std::uint64_t lq=0,sq=0,data=0;
            if (winner==9 || winner==11 || winner==13) lq=ports[winner].lq;
            if (15<=winner && winner<=18) sq=ports[winner].sq;
            switch(winner) {
                case 0: case 2: case 4: case 6: case 7: case 8: case 9: case 11: case 13:
                    data=ports[winner].data; break;
            }
"""
if address:
    source+="            const std::uint64_t pa = ((winner>=9 && winner<=16) || winner>=19) ? ports[winner].address : 0;\n"
fields=[("lqIdx","lq"),("sqIdx","sq"),("exuData","data")]
if address:fields.append(("paddr","pa"))
for f,val in fields:
    writes=sorted((w for w in d["writes"] if w["field"]==f),key=lambda w:(w["row"],w["half"]))
    for k in ("guard","value"):
        ids=[re.search(r"\[(\d+)\]",w[k+"_storage"]["slot"])[1] for w in writes]
        var=f+("_guards" if k=="guard" else "_data")
        enabled="(wb || allocate)" if f=="lqIdx" else "wb"
        member=writes[0][k+"_storage"]["slot"].partition("[")[0]
        source+="            static constexpr unsigned "+var+"[]={"+",".join(ids)+"};\n"
        cond=f"model->{member}[{var}[i]] != {enabled}" if k=="guard" else f"{enabled} && model->{member}[{var}[i]] != {val}"
        source+=f'            if ({cond}) {{ std::fprintf(stderr,"round=%u row=%u field={var}\\n",round,i);return 1; }}\n'
source+="        }\n    }\n    std::puts(\"1500 input sets, "+str(320*len(fields))+" guards checked per set and all enabled payloads equal\");\n}\n"
cpp=out/"directed.cpp";cpp.write_text(source)
subprocess.run([LLVM/"clang++","-std=c++20","-O2",cpp,"-o",out/"check"],check=True)
with (out/"result.txt").open("w") as log:subprocess.run([out/"check"],stdout=log,check=True)

