"""Count original next-value stores and removed change-site executions."""
from collections import Counter
from pathlib import Path
import gzip,json,re,sys
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import OUT
from source_categories import read_lcov
writes=json.loads((base/"layout.json").read_text())["writes"]
writes+=json.loads((base/"paddr-layout.json").read_text())["writes"]
targets={w[k]:(w["field"]+"/"+k,w[k+"_storage"]["blocks"][0][0],w[k+"_storage"]["slot"]) for w in writes for k in ("guard","value")}
removed=set(json.loads((base/"pruned/prune.json").read_text())["removed_slot_ids"])
extended=set(json.loads((base/"address-cones/prune.json").read_text())["removed_slot_ids"])
assert removed.issubset(extended)
shards={s for _,s,_ in targets.values()};summary={}
for wl in ("coremark","microbench"):
    counts=Counter();seen=set()
    for file,visits,_ in read_lcov(OUT/"coverage/gr_pgo"/wl/"model.lcov"):
        p=Path(file)
        if p.name not in shards:continue
        rows=p.read_text().splitlines()
        for j,row in enumerate(rows):
            if "[value_id=" not in row:continue
            m=re.search(r"\[value_id=(\d+):0\]",row)
            if not m or (v:=int(m[1])) not in targets:continue
            k,s,slot=targets[v];assert s==p.name and rows[j+3].strip()==slot+" = next_value;"
            seen.add(v);counts[k]+=visits.get(j+4,0)
    assert seen==targets.keys()
    summary[wl]=dict(original_store_visits=counts)
    # Counts of the original static inventory also exist for the held-out binary run in TNO0028.
    old=root/"build/armor-xs-value-paths-v1"
    import struct
    stats=Counter(); extra=Counter()
    with gzip.open(old/"generator/build/grhsim-sites.tsv.gz","rt") as f:
        next(f)
        for hdr in f:
            name,n=hdr.split()
            data=(old/"sequence"/wl/(Path(name).stem+".bin")).read_bytes()
            assert len(data)==16*int(n)
            for n,c,flips,miss in struct.iter_unpack("=4I",data):
                kind,i,tn,tc=next(f).split()
                if kind=="SPARSE" and int(i) in extended:
                    bucket=stats if int(i) in removed else extra
                    bucket.update(sites=1,visits=n,changes=c)
    summary[wl]["pruned_site_counts"]=stats
    summary[wl]["additional_paddr_sites"]=extra
(base/"coverage.json").write_text(json.dumps(summary,indent=2)+"\n")

