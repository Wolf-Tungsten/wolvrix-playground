"""Build each counterfactual from the measured FTQ model with independent Clang PGO."""
from pathlib import Path
import json,resource,shutil,sys
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from diagnostics import OUT,clean_environment,save,execute
from grhsim_change_sites import ChangeSites
from rewrite import patch_model
baseline=root/"build/armor-xs-value-paths-v1/generator"

def build(tag):
    dest=base/tag
    model=dest/"work/model" if tag=="shadow" else dest/"model"
    model.mkdir(parents=True)
    for p in (baseline/"model").iterdir():
        if p.suffix in (".cpp",".h",".hpp") or p.name=="Makefile":
            shutil.copyfile(p,model/p.name)
    sites=ChangeSites(model,dest)
    selected=sites.specialize(baseline/"build/grhsim-sites.tsv.gz","both",5)
    assert selected=={"SPARSE":131357,"EAGER":17187}
    save(dest/"rewrite.json",patch_model(model,"ports" if tag=="pruned" or tag.startswith("address") else tag))
    if tag.startswith("address"):
        from address import extend
        save(dest/"extension.json",extend(model))
    if tag=="address-cones":
        from mux_cleanup import remove_dead_muxes
        save(dest/"mux.json",remove_dead_muxes(model))
    if tag=="pruned" or tag.startswith("address"):
        from prune import prune
        save(dest/"prune.json",prune(model,extended=tag in ("address-pruned","address-cones")))
    if tag=="shadow":
        prev=OUT/"sitewatch/gr_pgo";args=json.loads((prev/"build.command.json").read_text())["argv"]
        cmd=[a.replace(str(prev),str(dest)).replace("-j20","-j32").replace("JOBS=20","JOBS=32") for a in args]
        execute(cmd,"build",dest,dict(clean_environment(),NOOP_HOME=str(root/"testcase/xiangshan")),root)
    else:
        args=json.loads((baseline/"pgo.command.json").read_text())["argv"]
        cmd=[a.replace(str(baseline/"model"),str(model)).replace(str(baseline),str(dest)) for a in args if not a.startswith(("XS_GRHSIM_SITE_","XS_GRHSIM_SPARSE_PERMILLE="))]
        execute(cmd,"pgo",dest,clean_environment(),root)
if __name__=="__main__":
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY));build(sys.argv[1])

