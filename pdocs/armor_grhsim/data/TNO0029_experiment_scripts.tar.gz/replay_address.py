"""Replay the extended profile through the standard PGO target after the same fresh emission."""
from pathlib import Path
import json,sys,resource
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/"scripts"))
from grhsim_single_baseline import clean_environment
from armor_xs_pgo_build import execute
tag=sys.argv[1] if sys.argv[1:] else "address"
assert tag in ("address","address-cones")
old=root/"build/armor-xs-value-paths-v1/generator";dest=base/("make-"+tag)
args=json.loads((old/"pgo.command.json").read_text())["argv"]
cmd=[a.replace(str(old/"build"),str(dest/"build")).replace(str(old/"logs"),str(dest/"logs")).replace(str(old/"model"),str(base/"make/model")) for a in args]
cmd+=[f"XS_GRHSIM_SITE_PROFILE={old/'build/grhsim-sites.tsv.gz'}",f"XS_GRHSIM_ROB_WRITEBACK_PROFILE={base/(tag+'-profile.json.gz')}"]
resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
execute(cmd,"make",dest,clean_environment(),root)

