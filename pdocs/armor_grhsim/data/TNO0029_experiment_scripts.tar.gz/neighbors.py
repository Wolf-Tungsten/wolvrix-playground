"""Classify nearby ROB commit enables with the same per-row BDD, retaining unmatched predicates."""
from collections import Counter,defaultdict
from pathlib import Path
import json,re
from proof import base,stages,canonical,width,opname,kind,get_bdd,variable,conj,inv,disj
expr_re=re.compile(rb'\$rob\$((?:debug_microOp|dt_exuDebug|dt_pcTransType|enqHalfWritten))_(\d+)_(0|1)((?:_[a-zA-Z0-9_]+)?)"')
families=defaultdict(dict)
for line in (stages/"after-clone.ops.tsv").open("rb"):
    if b"\tkRegisterWritePort\t" not in line or b"$rob$" not in line:continue
    op,k,s,attrs,file,ln,col,inputs,_=line.rstrip(b"\n").split(b"\t")
    m=expr_re.search(attrs)
    if m:families[m[1].decode()+m[4].decode()][int(m[2]),int(m[3])]=(int(op),canonical[int(inputs.split(b",",1)[0])])
groups=defaultdict(Counter);ids=defaultdict(list)
for row in range(160):
    expr=get_bdd(row)
    for half in (0,1):
        hit=[conj(conj(variable(p,"eq"),variable(p,"valid")),variable(p,"bits_robIdx_isFormer") if half==0 else inv(variable(p,"bits_robIdx_isFormer"))) for p in range(37)]
        allwb=alloc=0
        for p,h in enumerate(hit):
            if p<29:allwb=disj(allwb,h)
            else:alloc=disj(alloc,h)
        def classify(i):
            try:x=expr(i)
            except (KeyError,ValueError,AssertionError):return "other leaves or operations"
            if x==allwb:return "all writebacks"
            if x==disj(allwb,alloc):return "writeback or allocation"
            if x==1:return "always"
            if x==0:return "never"
            return "different function of these inputs"
        for name,t in families.items():
            if (row,half) not in t:continue
            op,i=t[row,half]
            groups[name][classify(i)]+=1
            if row==79 and half==1:ids[i].append(name)
res=dict(classes=groups,shared_guard_ids_for_row79_half1=ids)
(base/"neighbors.json").write_text(json.dumps(res,indent=1)+"\n")

