"""Drop pure conditional mux blocks whose destination store was replaced by the port decoder."""
from collections import Counter, defaultdict
from pathlib import Path
import json
import re

from prune import pure

base = Path(__file__).resolve().parent
names = re.compile(r"\b(?:grhsim_mux_result_\d+|grhsim_v\d+_\d+)\b")
declaration = re.compile(r"std::uint64_t (grhsim_mux_result_\d+);")
assignment = re.compile(r"(?:const std::uint64_t )?(grhsim_v\d+_\d+|grhsim_mux_result_\d+) = (.*);")
predicate = re.compile(r"if \(value_bool_slots_\[\d+\]\) \{")


def remove_dead_muxes(model):
    writes = json.loads((base / "paddr-layout.json").read_text())["writes"]
    expected = defaultdict(set)
    for w in writes:
        name, _ = w["value_storage"]["blocks"][0]
        expected[name].add(w["value"])
    counts = Counter()
    for name, ids in expected.items():
        path = model / name
        rows = path.read_text().splitlines(keepends=True)
        file_refs = Counter()
        for line in rows:
            if not line.lstrip().startswith("//"):
                file_refs.update(names.findall(line))
        seen = set()
        for stop, line in enumerate(rows):
            marker = re.search(r"\[value_id=(\d+):0\]", line)
            if not marker or int(marker[1]) not in ids:
                continue
            assert not rows[stop + 1].strip() == "{"
            seen.add(int(marker[1]))
            start = next((j for j in range(stop - 1, max(-1, stop - 30), -1) if declaration.fullmatch(rows[j].strip())), None)
            if start is None:
                continue
            code = [r.strip() for r in rows[start:stop] if not r.lstrip().startswith("//")]
            target = declaration.fullmatch(code[0])[1]
            if (not predicate.fullmatch(code[1]) or code[2] != target + " = UINT64_C(0);"
                    or code[3] != "} else {" or code[-1] != "}"):
                continue
            records = [assignment.fullmatch(r) for r in code[4:-1]]
            if not records or not all(m and pure(m[2]) for m in records) or records[-1][1] != target:
                continue
            locals_ = {m[1] for m in records}
            inside = Counter(names.findall("\n".join(code)))
            if any(inside[key] != file_refs[key] for key in locals_):
                continue
            counts["branches"] += 1
            counts["local_definitions"] += len(locals_)
            rows[start:stop] = [""] * (stop - start)
        assert seen == ids
        path.write_text("".join(rows))
    return counts

