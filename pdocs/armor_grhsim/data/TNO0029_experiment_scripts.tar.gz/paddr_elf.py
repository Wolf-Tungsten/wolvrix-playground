"""Locate the row 79 paddr predicate producer and mux consumer in linked binaries."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import re
import subprocess
import sys

from elf import base, dest, LLVM, Elf, Disassembler


def source_lines(rows, shard):
    if shard == 22:
        marker = "[value_id=1254778:0]"
        head = next((j for j,r in enumerate(rows) if marker in r), None)
        if head is None:
            return set()
        stop = next(i for i in range(head + 1, head + 40) if rows[i] == "        }")
        return {i+1 for i in range(head+1,stop+1) if not rows[i].strip().startswith(("//","#"))}
    head = next((j for j,r in enumerate(rows) if "std::uint64_t grhsim_mux_result_1473143;" in r), None)
    if head is None:
        return set()
    marker = next(i for i in range(head+1,head+40) if "[value_id=1254798:0]" in rows[i])
    stop = marker + (4 if rows[marker+1].strip() == "{" else 0)
    return {i+1 for i in range(head, stop+1) if not rows[i].strip().startswith(("//","#"))}


def examine(task):
    tag, shard = task
    folder = base / tag
    model = folder / "model"
    source = model / f"grhsim_SimTop_sched_{shard}.cpp"
    elf = Elf(folder / "build/emu")
    name = f"GrhSIM_SimTop::eval_compute_batch_{shard}()"
    address, length = elf.funcs[name]
    selected = source_lines(source.read_text().splitlines(), shard)
    hit = []
    relocations = 0
    if selected:
        obj = dest / f"{tag}-{shard}-paddr.o"
        subprocess.run([LLVM/"clang++", "-std=c++20", "-march=native", "-O3", "-gline-tables-only",
                        f"-fprofile-use={folder/'build/grhsim.profdata'}", "-mllvm",
                        "-x86-cmov-converter-force-mem-operand=false", "-c", source.name, "-o", obj], cwd=model, check=True)
        assert Elf(obj).funcs[name][1] == length
        dis = Disassembler()
        proc = subprocess.Popen([LLVM/"llvm-objdump", "-dlC", f"--disassemble-symbols={name}", obj], stdout=subprocess.PIPE, text=True)
        offset = line = None
        for row in proc.stdout:
            if m := re.match(r"^([0-9a-f]+) <(.*)>:", row):
                offset = int(m[1],16) if m[2]==name else None
                line = None
            elif row.startswith(";"):
                m = re.search(re.escape(source.name) + r":(\d+)", row)
                line = int(m[1]) if m else None
            elif offset is not None and line in selected:
                m = re.match(r"^\s*([0-9a-f]+): ((?:[0-9a-f]{2} )*[0-9a-f]{2})\s+", row)
                if m:
                    enc = bytes.fromhex(m[2])
                    pc = address + int(m[1],16) - offset
                    if elf.code(pc,len(enc)) == enc:
                        hit.append(dict(pc=hex(pc), source_line=line, bytes=enc.hex(), asm=dis.get(elf.code(pc,16),pc)))
                    else:
                        relocations += 1
        assert proc.wait() == 0
    record = dict(symbol=name, bytes=length, source=source.name, source_lines=sorted(selected), matched=len(hit),
                  mismatched_encodings=relocations, instructions=hit)
    (dest / f"{tag}-paddr-{shard}.json").write_text(json.dumps(record,indent=2)+"\n")
    print(tag,shard,length,len(selected),len(hit),relocations,flush=True)


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(examine, [(tag, shard) for tag in sys.argv[1:] for shard in (22,26)]))

