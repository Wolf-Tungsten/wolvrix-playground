"""Intersect sites removed or served by the new ROB decoder with prior sparse/eager choices."""
from collections import Counter, defaultdict
from pathlib import Path
import gzip
import json
import re
import struct

base = Path(__file__).resolve().parent
prior = base.parents[1] / "build/armor-xs-value-paths-v1"
profile = prior / "generator/build/grhsim-sites.tsv.gz"
chosen = defaultdict(set)
for header in (base / "pruned/model").glob("*.sites.h"):
    for kind, ident in re.findall(r"^#define GRHSIM_(SPARSE|EAGER)_(\d+)\b", header.read_text(), re.M):
        chosen[(header.name, kind)].add(int(ident))
triplet = set(json.loads((base/"pruned/prune.json").read_text())["removed_slot_ids"])
extra = set(json.loads((base/"address-cones/prune.json").read_text())["removed_slot_ids"]) - triplet
port_ops = {w["op"]:w["field"] for name in ("proof.json","paddr-proof.json")
            for w in json.loads((base/name).read_text())["writes"]}
output = {}
for wl in ("coremark","microbench"):
    counts = defaultdict(lambda: defaultdict(Counter))
    with gzip.open(profile, "rt") as stream:
        cycles = int(stream.readline().split()[-1])
        for block in stream:
            file, size = block.split()
            header = Path(file).with_suffix(".sites.h").name
            seq = (prior/"sequence"/wl/(Path(file).stem+".bin")).read_bytes()
            assert len(seq) == int(size)*16
            for n, changes, _, _ in struct.iter_unpack("=4I",seq):
                kind, ident, train_n, train_changes = next(stream).split()
                if wl == "coremark":
                    assert (n,changes)==(int(train_n),int(train_changes))
                ident = int(ident)
                if kind == "SPARSE":
                    key = "three_fields" if ident in triplet else "extra_paddr" if ident in extra else None
                else:
                    key = port_ops.get(ident)
                if key:
                    selected = "selected" if ident in chosen[header,kind] else "unselected"
                    row = counts[key][selected]
                    row.update(sites=1, visits=n, changes=changes)
                    if kind=="EAGER":
                        enough=int(train_n)>=max(1,cycles//100)
                        frequent=5*int(train_changes)>=int(train_n)
                        assert (selected=="selected")==(enough and frequent)
                        row["passes_visits" if enough else "below_visits"] += 1
                        row["passes_rate" if frequent else "below_rate"] += 1
    output[wl] = counts
(base/"site-overlap.json").write_text(json.dumps(output,indent=2) + "\n")

