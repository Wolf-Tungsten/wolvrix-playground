"""Collect paired counters, equivalence checks and portable experiment sources for TNO0029."""
from pathlib import Path
from statistics import mean
import csv
import gzip
import hashlib
import json
import tarfile

base = Path(__file__).resolve().parent
root = base.parents[1]
dest = root / "pdocs/armor_grhsim/data"
workloads = ("coremark", "microbench")
groups = {
    "components": (3, workloads, "ftq"),
    "final": (4, workloads, "ftq"),
    "frontend": (2, ("coremark",), "ftq"),
    "data": (2, ("coremark",), "ftq"),
    "address": (3, workloads, "ftq"),
    "address_frontend": (2, workloads, "pruned"),
    "address_data": (2, workloads, "pruned"),
    "cones": (3, workloads, "address"),
    "check_frontend": (4, ("coremark",), "pruned"),
    "check_data": (4, ("microbench",), "pruned"),
}


def read(name):
    return json.loads((base / name).read_text())


def stats(rows, tag, ref):
    current = [r[tag] for r in rows]
    rates = [100 * (r[tag]["external_wall_s"] / r[ref]["external_wall_s"] - 1) for r in rows]
    events = current[0]["counts"]
    return dict(reference=ref, mean_wall_s=mean(r["external_wall_s"] for r in current),
                paired_wall_pct=mean(rates), paired_wall_range=[min(rates), max(rates)], paired_wall=rates,
                faster=sum(s < 0 for s in rates),
                mean_per_guest={ev:mean(r["counts"][ev] / r["guest_cycles"] for r in current) for ev in events},
                delta_per_guest={ev:mean((r[tag]["counts"][ev] - r[ref]["counts"][ev]) / r[tag]["guest_cycles"]
                                         for r in rows) for ev in events})


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def collect():
    samples, results, identities = [], {}, {}
    for group, (expected, wls, ref) in groups.items():
        results[group] = {}
        for wl in wls:
            rows = read(f"pairs/{group}/{wl}/rounds.json")
            assert len(rows) == expected
            tags = rows[0]["order"]
            wl_out = {}
            for tag in tags:
                entry = stats(rows, tag, ref)
                for comparator in ("ftq", "gs_pgo", "pruned", "address"):
                    if comparator != ref and comparator in tags:
                        entry["vs_" + comparator] = stats(rows, tag, comparator)
                wl_out[tag] = entry
            results[group][wl] = wl_out
            for i, row in enumerate(rows, 1):
                assert set(tags) == set(row["order"])
                for position, tag in enumerate(row["order"], 1):
                    r = row[tag]
                    ident = r["binary"]
                    assert ident == identities.setdefault(tag, ident)
                    assert r["runtime_difftest"] == "on" and r["guest_cycles"] == 100001
                    samples.append(dict(group=group, workload=wl, round=i, position=position, tag=tag, cpu=row["cpu"],
                                        guest_cycles=r["guest_cycles"], wall_s=r["external_wall_s"], **r["counts"],
                                        pmu_min_pct=min(r["counter_running_pct"].values()), cpu_fraction=r["cpu_fraction"],
                                        placements=r["placements"], sibling_idle_min=min(v for k,v in r["sibling_idle"].items()
                                                                                      if int(k)!=row["cpu"]),
                                        sha256=ident["sha256"], directory=r["path"]))
    with (dest / "TNO0029_rob_writeback_samples.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(dict.fromkeys(k for row in samples for k in row)))
        writer.writeheader()
        writer.writerows(samples)

    checks = {}
    for tag in ("guards", "payload", "ports", "pruned", "address", "address-cones", "make", "make-address", "make-address-cones"):
        checks[tag] = {w:read(f"verify/{tag}/{w}/result.json") for w in workloads}
        assert all(rec["coverage"]["pass_"] and rec["coverage"]["records"] == 99999 for rec in checks[tag].values())
    long = {tag:dict(coverage=read(f"long/{tag}/coverage.json"), endpoint=read(f"long/{tag}/endpoint.json"))
            for tag in ("ports", "pruned", "address", "address-cones", "make", "make-address", "make-address-cones")}
    assert all(row["coverage"]["pass_"] and row["coverage"]["records"] == 225599 for row in long.values())

    sources = {"pruned":"triplet-profile.json.gz", "address":"address-profile.json.gz",
               "address-cones":"address-cones-profile.json.gz"}
    profiles = {}
    for tag, name in sources.items():
        with gzip.open(base / name, "rt") as stream:
            data = json.load(stream)
        profiles[tag] = dict(model=data["model"], files=len(data["files"]), fields=data["fields"], sha256=hash_file(base/name))
    selected = hash_file(base / "triplet-profile.json.gz")
    canonical, = [t for t,v in profiles.items() if v["sha256"]==selected]
    proof = read("proof.json")
    layout = {k:read(name)["counts"] for k,name in (("triplet","layout.json"),("paddr","paddr-layout.json"))}
    raw = dict(protocol="node030, NUMA node 1, single hardware thread, ASLR off, NEMU DiffTest, seed 0, CoreMark PGO, 100001 guest cycles",
               samples=len(samples), results=results, identity=identities,
               pmu_min_pct=min(r["pmu_min_pct"] for r in samples), cpu_min_fraction=min(r["cpu_fraction"] for r in samples),
               smt_min_idle=min(r["sibling_idle_min"] for r in samples),
               selection=canonical, profiles=profiles,
               triplet_proof=dict(guards=len(proof["writes"]), data_bits=sum(w["width"] for w in proof["writes"]),
                                  ports=proof["ports"], payloads=proof["payloads"], clocks=proof["clock_ids"],
                                  decision_nodes=proof["decision_nodes"]),
               paddr_proof=read("paddr.json"), layout=layout, neighbors=read("neighbors.json"),
               cones={t:read(name) for t,name in (("triplet","cone.json"),("four_fields","cone-address.json"))},
               cleanup={t:{k:v for k,v in read(t+"/prune.json").items() if not isinstance(v,list)}
                        for t in ("pruned","address","address-pruned","address-cones")},
               mux=read("address-cones/mux.json"), coverage=read("coverage.json"), write_rates=read("write-rates.json"),
               previous_site_policies=read("site-overlap.json"),
               shadow={w:read(f"shadow/{w}/checked.json") for w in workloads},
               directed={t:(base/t/"result.txt").read_text().strip() for t in ("directed","directed-address")},
               elf={p.stem:json.loads(p.read_text()) for p in sorted((base/"elf").glob("*.json"))},
               rebuilt={t:read(f"{t}/comparison.json") for t in ("make","make-address","make-address-cones")},
               repeated_four_field_cleanup=read("address-pruned/comparison.json"),
               executable_test=(base/"ctest.log").read_text(), verify=checks, full_microbench=long)
    assert all(rec["section"][".text"]["identical"] and not rec["different_model_functions"] for rec in raw["rebuilt"].values())
    (dest / "TNO0029_rob_writeback.json").write_text(json.dumps(raw, ensure_ascii=False, indent=2) + "\n")
    with tarfile.open(dest / "TNO0029_experiment_scripts.tar.gz", "w:gz") as tar:
        tar.add(base / "REPRODUCE.md", arcname="REPRODUCE.md")
        tar.add(base / "historical-make.patch", arcname="historical-make.patch")
        for path in sorted(base.glob("*.py")):
            tar.add(path, arcname=path.name)
        for name in sources.values():
            tar.add(base / name, arcname=name)
    print(f"{len(samples)} accepted samples. Published profile {canonical}.")


if __name__ == "__main__":
    collect()

