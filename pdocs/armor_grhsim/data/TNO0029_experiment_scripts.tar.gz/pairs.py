"""Run the existing NUMA-controlled counterbalanced harness against TNO0028."""
from pathlib import Path
import sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
import site_pairs
site_pairs.bins["ftq"]=root/"build/armor-xs-value-paths-v1/generator/build/emu"
site_pairs.base=base
site_pairs.main()

