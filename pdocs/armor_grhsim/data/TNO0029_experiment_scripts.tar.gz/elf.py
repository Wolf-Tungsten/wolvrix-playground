"""Relocate source-line instructions into each measured ELF and check final encodings."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,re,subprocess,sys
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
from machine import LLVM,Elf,Disassembler,phase,save
prev=root/"build/armor-xs-value-paths-v1"
dest=base/"elf";dest.mkdir(exist_ok=True)
def run(task):
    tag,shard=task
    folder=prev/"generator" if tag=="ftq" else base/tag
    model=folder/"model";build=folder/"build";elf=Elf(build/"emu")
    sections=dict(text=elf.sec[".text"][2],rodata=elf.sec[".rodata"][2],compute=sum(size for n,(pc,size) in elf.funcs.items() if phase(n)=="compute"),
                  commit=sum(size for n,(pc,size) in elf.funcs.items() if phase(n)=="commit"))
    if shard=="size":save(dest/(tag+"-sizes.json"),sections);return
    if shard=="20":
        path=prev/"elf/generator/grhsim_SimTop_sched_20.cpp"
        obj=path.with_suffix(".o")
        fun="GrhSIM_SimTop::eval_compute_batch_20()"
        rows=path.read_text().splitlines()
        hits=[i for i,r in enumerate(rows,1) if "[value_id=1282313:0]" in r];start,=hits;end=start+12
    else:
        path=model/"grhsim_SimTop_eval.cpp";rows=path.read_text().splitlines()
        obj=dest/(tag+"-eval.o")
        fun="GrhSIM_SimTop::prepare_rob_writeback(bool)"
        start,=[i for i,r in enumerate(rows,1) if "if (state_logic_storage_.bool_slots_27874 &&" in r]
        end=next(i for i in range(start+1,len(rows)+1) if rows[i-1]=="    }")
        subprocess.run([LLVM/"clang++","-std=c++20","-march=native","-O3","-gline-tables-only",f"-fprofile-use={build/'grhsim.profdata'}",
                        "-mllvm","-x86-cmov-converter-force-mem-operand=false","-c",path.name,"-o",obj],cwd=model,check=True)
    startpc,size=elf.funcs[fun]
    assert Elf(obj).funcs[fun][1]==size
    dis=Disassembler();matched=[];offset=None;line=None
    proc=subprocess.Popen([LLVM/"llvm-objdump","-dlC",f"--disassemble-symbols={fun}",obj],stdout=subprocess.PIPE,text=True)
    for row in proc.stdout:
        if m:=re.match(r"^([0-9a-f]+) <(.*)>:",row):
            offset=int(m[1],16) if m[2]==fun else None;line=None
        elif row.startswith(";"):
            m=re.search(re.escape(path.name)+r":(\d+)",row);line=int(m[1]) if m else None
        elif offset is not None and line is not None and start<=line<=end:
            m=re.match(r"^\s*([0-9a-f]+): ((?:[0-9a-f]{2} )*[0-9a-f]{2})\s+",row)
            if m:
                pc=startpc+int(m[1],16)-offset
                enc=bytes.fromhex(m[2])
                if elf.code(pc,len(enc))==enc:matched.append(dict(pc=hex(pc),line=line,bytes=enc.hex(),asm=dis.get(elf.code(pc,16),pc)))
    assert proc.wait()==0 and matched
    save(dest/f"{tag}-{shard}.json",dict(function=fun,bytes=size,source=path.name,line=start,body=matched))
if __name__=="__main__":
    jobs=[(t,"size") for t in ("ftq","guards","payload","ports","pruned")]+[("ftq","20"),("pruned","dispatch")]
    with ThreadPoolExecutor(5) as workers:list(workers.map(run,jobs))

