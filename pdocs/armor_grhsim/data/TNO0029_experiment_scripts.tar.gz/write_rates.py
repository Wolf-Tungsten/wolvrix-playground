"""Count enabled comparisons and their state writes in the original scalar commit code."""
from collections import Counter
from pathlib import Path
import json
import re
import sys

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
from diagnostics import OUT
from source_categories import read_lcov

symbol = re.compile(r"\$rob\$(?:dt_exuDebug_(\d+)_([01])_(paddr)|debug_(lqIdx|sqIdx|exuData)_(\d+)_([01])(?:_value)?)$")
result = {}
for workload in ("coremark", "microbench"):
    found = set()
    totals = {}
    for file, visits, _ in read_lcov(OUT / "coverage/gr_pgo" / workload / "model.lcov"):
        path = Path(file)
        if "_sched_" not in path.name:
            continue
        rows = path.read_text().splitlines()
        for index, row in enumerate(rows):
            if "[kRegisterWritePort]" not in row or not (match := symbol.search(row)):
                continue
            name = match[3] or match[4]
            key = (name, match[1] or match[5], match[2] or match[6])
            assert key not in found
            found.add(key)
            compares = [j for j in range(index + 1, index + 11) if "!= next_value" in rows[j]]
            compare, = compares
            assert re.fullmatch(r"state_logic_storage_\.\w+ = next_value;", rows[compare + 1].strip())
            count = totals.setdefault(name, Counter())
            count.update(elements=1, enabled=visits.get(compare + 1, 0), changed=visits.get(compare + 2, 0))
    assert len(found) == 1280
    result[workload] = totals
(base / "write-rates.json").write_text(json.dumps(result, indent=2) + "\n")
