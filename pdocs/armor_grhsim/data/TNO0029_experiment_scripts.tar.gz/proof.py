"""Verify the flattened ROB write ports with ordered Boolean decision diagrams."""
from array import array
from collections import Counter,defaultdict
from functools import lru_cache
from pathlib import Path
import json,re,time

base=Path(__file__).resolve().parent
root=base.parents[1]
stages=root/"build/armor-xs-gap-current-v1/audit/stages"
canonical=array("I",[0])
width=array("I",[0])
names=re.compile(rb'\$rob\$io_(exuWriteback|writeback)_(\d+)_(valid|bits_robIdx_value|bits_robIdx_isFormer|bits_lqIdx_value|bits_sqIdx_value|bits_data)"')
ports=defaultdict(dict)
alloc_names={}
for p in range(8):
    for j in range(3):alloc_names[f'$rob$_GEN_{20128+321*p+j}"'.encode()]=p,j
alloc_ids={}
root_expr=re.compile(rb'\$rob\$debug_(lqIdx|sqIdx|exuData)_(\d+)_(0|1)(?:_value)?"')
for line in (stages/"after-clone.values.tsv").open("rb"):
    if not line[:1].isdigit():continue
    i,c,w,_,_,s=line.rstrip(b"\n").split(b"\t",5)
    assert len(canonical)==int(i)
    canonical.append(int(c));width.append(int(w))
    if b"$rob$io_" in s and (m:=names.search(s)):
        ports[(int(m[2]),m[3].decode())][m[1].decode()]=int(c)
    if b"$rob$_GEN_" in s:
        suffix=s[s.index(b"$rob$_GEN_"):]
        if suffix in alloc_names:alloc_ids[alloc_names[suffix]]=int(c)
fields=("lqIdx","sqIdx","exuData")
types={};kind=array("B",[0])*len(canonical)
slice_start=array("I",[0])*len(canonical)
position=array("I",[0])*len(canonical);args=array("I")
const={};registers={};writes={};portids={}
for key,x in ports.items():
    port,role=key
    branch="exuWriteback" if role=="valid" else next((k for k in ("exuWriteback","writeback") if k in x),None)
    if branch in x:portids[x[branch]]=key
for line in (stages/"after-clone.ops.tsv").open("rb"):
    if not line[:1].isdigit():continue
    op,k,s,attr,file,ln,col,inp,out=line.rstrip(b"\n").split(b"\t")
    if k==b"kRegisterWritePort" and b"$rob$debug_" in attr and (m:=root_expr.search(attr)):
        assert ["eventEdge",7,["posedge"]] in json.loads(attr)
        writes[m[1].decode(),int(m[2]),int(m[3])]=(int(op),*map(lambda x:canonical[int(x)],inp.split(b",")))
    if not out or b"," in out:continue
    i=int(out)
    if canonical[i]!=i:continue
    code=types.setdefault(k,len(types)+1)
    kind[i]=code
    if k==b"kConstant":const[i]=attr.decode()
    if k==b"kRegisterReadPort" and i in portids:
        registers[i]=re.search(rb'\["regSymbol",3,"([^"]+)"\]',attr)[1].decode()
    if k==b"kSliceStatic":
        low=re.search(rb'\["sliceStart",1,(\d+)\]',attr)
        if low:slice_start[i]=int(low[1])
    if inp and (k==b"kConcat" or inp.count(b",")<3):
        operands=[canonical[int(x)] for x in inp.split(b",")]
        position[i]=len(args)
        args.extend([len(operands),*operands])
opname={n:k.decode() for k,n in types.items()}

def inputs(i):
    off=position[i]
    return args[off+1:off+1+args[off]]
def number(i):
    text=const[i]
    m=re.search(r'"(\d+)\'([sS]?)([hbdHBD])([0-9a-fA-F_]+)"',text)
    if not m:
        raise ValueError((i,text))
    return int(m[4].replace("_",""),{"h":16,"d":10,"b":2}[m[3].lower()])
for lane in range(8):
    valid,cmp0,hit=[alloc_ids[lane,i] for i in range(3)]
    assert opname[kind[cmp0]]=="kEq" and opname[kind[hit]]=="kAnd"
    addr,zero=inputs(cmp0)
    assert number(zero)==0
    common,former=inputs(hit)
    assert set(inputs(common))=={cmp0,valid}
    for i,role in [(addr,"bits_robIdx_value"),(former,"bits_robIdx_isFormer"),(valid,"valid")]:
        portids[i]=29+lane,role
# Terminal 0/1 nodes are false/true. Higher-priority ports precede lower ports
# to keep the multi-port priority function linear in the number of ports.
nodes=[(10000,0,0),(10000,1,1)]
@lru_cache(None)
def make(var,lo,hi):
    if lo==hi:return lo
    n=len(nodes);nodes.append((var,lo,hi));return n
@lru_cache(None)
def ite(c,t,e):
    if c==1 or t==e:return t
    if c==0:return e
    if t==1 and e==0:return c
    v=min(nodes[a][0] for a in (c,t,e))
    cofactors=[nodes[a][1:] if nodes[a][0]==v else (a,a) for a in (c,t,e)]
    return make(v,ite(*(a[0] for a in cofactors)),ite(*(a[1] for a in cofactors)))
def conj(a,b):return ite(a,b,0)
def disj(a,b):return ite(a,1,b)
def inv(a):return ite(a,0,1)
def variable(p,role,bit=0):
    return make((36-p)*96+{"valid":0,"eq":1,"bits_robIdx_isFormer":2,"bits_lqIdx_value":3,"bits_sqIdx_value":11,"bits_data":18}[role]+bit,0,1)
def get_bdd(row):
    @lru_cache(None)
    def expr(i,bit=0):
        assert 0<=bit<width[i],(i,bit,width[i])
        if i in portids:
            p,role=portids[i]
            return variable(p,role,bit)
        k=opname.get(kind[i]);ins=list(inputs(i))
        if k=="kConstant":
            v=number(i)
            return (v>>bit)&1
        if k=="kReduceOr" and ins[0] in portids and portids[ins[0]][1]=="bits_robIdx_value":
            assert row==0
            return inv(variable(portids[ins[0]][0],"eq"))
        if k=="kEq":
            a,b=ins
            if a in const:a,b=b,a
            p,r=portids[a]
            assert r=="bits_robIdx_value" and b in const and number(b)==row,(row,p,r,number(b))
            return variable(p,"eq")
        if k=="kSliceStatic":return expr(ins[0],slice_start[i]+bit)
        if k=="kReplicate":return expr(ins[0],bit%width[ins[0]])
        if k=="kConcat":
            for operand in reversed(ins):
                if bit<width[operand]:return expr(operand,bit)
                bit-=width[operand]
            raise ValueError(i)
        if k.startswith("kLogic"):assert all(width[v]==1 for v in ins)
        if k=="kAssign":return expr(ins[0],bit)
        if k in ("kNot","kLogicNot"):return inv(expr(ins[0],bit))
        if k in ("kAnd","kLogicAnd"):return conj(expr(ins[0],bit),expr(ins[1],bit))
        if k in ("kOr","kLogicOr"):return disj(expr(ins[0],bit),expr(ins[1],bit))
        if k=="kMux":
            assert width[ins[0]]==1 and width[ins[1]]==width[ins[2]]==width[i]
            return ite(expr(ins[0]),expr(ins[1],bit),expr(ins[2],bit))
        raise ValueError(("unsupported leaf",i,k,ins))
    return expr
payloads={"sqIdx":{p:"bits_sqIdx_value" for p in (15,16,17,18)},"lqIdx":{p:"bits_lqIdx_value" for p in (9,11,13)},
          "exuData":{p:"bits_data" for p in (0,2,4,6,7,8,9,11,13)}}
def main():
    print("ports",len(portids),"states",len(registers),"writes",len(writes),flush=True)
    print("const example",list(const.items())[:2],flush=True)
    inventory=[]
    for row in range(160):
        expr=get_bdd(row)
        for half in range(2):
            enabled=0;hits=[]
            for p in range(29):
                former=variable(p,"bits_robIdx_isFormer")
                hit=conj(conj(variable(p,"eq"),variable(p,"valid")),former if half==0 else inv(former))
                enabled=disj(enabled,hit)
                hits.append(hit)
            alloc=0
            for p in range(29,37):
                former=variable(p,"bits_robIdx_isFormer")
                alloc=disj(alloc,conj(conj(variable(p,"eq"),variable(p,"valid")), former if half==0 else inv(former)))
            for field in fields:
                op,guard,value,mask,clk=writes[field,row,half]
                g=expr(guard)
                if g==enabled:enq=False
                elif g==disj(enabled,alloc):enq=True
                else:raise ValueError((row,half,field,"guard",g,enabled))
                assert enq==(field=="lqIdx") and clk==2
                assert width[value]=={"lqIdx":7,"sqIdx":6,"exuData":64}[field]
                for bit in range(width[value]):
                    expected=0
                    for p,hit in enumerate(hits):
                        v=variable(p,payloads[field][p],bit) if p in payloads[field] else 0
                        expected=ite(hit,v,expected)
                    d=expr(value,bit)
                    assert conj(g,d)==conj(g,expected),(row,half,field,"priority/data",bit,d,expected)
                assert number(mask)==(1<<width[value])-1,(mask,field,width[value])
                inventory.append(dict(field=field,row=row,half=half,op=op,guard=guard,value=value,clk=clk,width=width[value],allocation_clear=enq))
        expr.cache_clear()
    assert len(inventory)==960
    result=dict(writes=inventory,ports=[dict(port=p,role=r,id=i,reg=registers.get(i)) for i,(p,r) in sorted(portids.items())],
                payloads=payloads,decision_nodes=len(nodes),clock_ids=sorted({w["clk"] for w in inventory}))
    (base/"proof.json").write_text(json.dumps(result,indent=1)+"\n")
if __name__=="__main__":main()

