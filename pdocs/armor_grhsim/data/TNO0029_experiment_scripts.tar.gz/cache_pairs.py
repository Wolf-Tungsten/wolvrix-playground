"""Collect the front-end or data-cache counter group with the same timing protocol."""
from pathlib import Path
import fcntl
import sys
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/"scripts/armor_xs_gap_diagnostics"))
import site_pairs
site_pairs.bins["ftq"]=root/"build/armor-xs-value-paths-v1/generator/build/emu"
site_pairs.base=base
group=sys.argv[1]
site_pairs.gap.GROUPS[0]=site_pairs.gap.GROUPS[{"frontend":1,"data":2}[group.rsplit("_",1)[-1]]]
if int(sys.argv[3]) == 96:
    lock_path = root.parent / "wolvrix-playground-cv32e40p/build/xs/xiangshan-cpu96-measure.lock"
    shared_cpu_lock = lock_path.open("a")
    fcntl.flock(shared_cpu_lock, fcntl.LOCK_EX)
site_pairs.main()

