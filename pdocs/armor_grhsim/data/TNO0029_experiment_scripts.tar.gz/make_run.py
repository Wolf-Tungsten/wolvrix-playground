"""Exercise fresh emission and the standard Make PGO driver with the packaged profile."""
from pathlib import Path
from argparse import ArgumentParser
import json,resource,sys
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/"scripts"))
from armor_xs_pgo_build import execute
from grhsim_single_baseline import clean_environment
old=root/"build/armor-xs-value-paths-v1"
def run(profile,dest):
    emit=json.loads((old/"reemit/emit.command.json").read_text())["argv"]
    pgo=json.loads((old/"generator/pgo.command.json").read_text())["argv"]
    flags={a.partition("=")[0]:a.partition("=")[2] for a in emit+pgo if "=" in a}
    flags.update(XS_GRHSIM_BUILD=str(dest/"build"),XS_WOLF_GRHSIM_EMIT_DIR=str(dest/"model"),XS_LOG_DIR=str(dest/"logs"),
                 XS_GRHSIM_SITE_PROFILE=str(old/"generator/build/grhsim-sites.tsv.gz"),XS_GRHSIM_ROB_WRITEBACK_PROFILE=str(profile.resolve()))
    cmd=emit[:emit.index("xs_wolf_grhsim_emit")]+["xs_wolf_grhsim_emu"]+[f"{key}={value}" for key,value in flags.items()]
    env=dict(clean_environment(),PYTHONPATH=str(root/"build/armor-dispatch-v1/tools/python"),LD_LIBRARY_PATH=str(root/"build/armor-dispatch-v1/tools"),
             WOLVRIX_GRHSIM_PRIORITY_MUX_COMMIT_DEMAND="1",WOLVRIX_GRHSIM_PRIORITY_MUX_MIN_CHAIN_LENGTH="13")
    execute(cmd,"make",dest,env,root)
if __name__=="__main__":
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("profile",nargs="?",type=Path,default=base/"triplet-profile.json.gz")
    parser.add_argument("--output",type=Path,default=base/"make")
    args=parser.parse_args()
    run(args.profile,args.output.resolve())

