"""Replay a verified ROB writeback specialization in a private GrhSIM build directory."""
import gzip
import hashlib
import json
from pathlib import Path


def load_writeback_profile(path, model_digest):
    with gzip.open(path, "rt") as stream:
        profile = json.load(stream)
    if profile.get("format") != "grhsim-rob-writeback-v1":
        raise ValueError(f"unknown ROB writeback profile format in {path}")
    if model_digest != profile["model"]:
        raise ValueError(f"ROB writeback profile expects model {profile['model']}, got {model_digest}")
    return profile


def specialize_writeback(model, profile):
    for name, change in profile["files"].items():
        path = model / name
        if name != Path(name).name or path.suffix not in (".cpp", ".hpp", ".h"):
            raise ValueError(f"invalid generated source name {name}")
        source = path.read_bytes()
        # Site training prepends a private include. Profile offsets refer to the emitted source.
        header = f'#include "{path.with_suffix(".sites.h").name}"\n'.encode()
        prefix = header if source.startswith(header) else b""
        body = source[len(prefix):]
        if hashlib.sha256(body).hexdigest() != change["source"]:
            raise ValueError(f"ROB writeback source mismatch in {name}")
        rows = body.splitlines(keepends=True)
        output = bytearray()
        cursor = 0
        for first, count, insert in change["edits"]:
            if not cursor <= first <= first + count <= len(rows):
                raise ValueError(f"invalid ROB writeback edit in {name} at line {first + 1}")
            output.extend(b"".join(rows[cursor:first]))
            output.extend(insert.encode())
            cursor = first + count
        output.extend(b"".join(rows[cursor:]))
        if hashlib.sha256(output).hexdigest() != change["result"]:
            raise ValueError(f"ROB writeback result mismatch in {name}")
        path.write_bytes(prefix + output)

