# TNO0029 复现

将本包解到 ARMOR 仓库的 `build/armor-xs-rob-writeback-v1/`。以下命令从该目录执行。本包为冻结模型的实验归档。三字段原型用第 1、2 步的 `pruned` 标签重建。实验重建使用同一套 XiangShan RTL、DiffTest、NEMU、CoreMark 固件和 LLVM 23.1.2，以及下列已经归档或可从既有报告重建的输入。

- TNO0026 的 `build/armor-xs-gap-current-v1/audit/stages/after-clone.{ops,values}.tsv`、两种负载的源覆盖和站点诊断构建命令。
- TNO0027 的 `build/armor-xs-site-pgo-v1/long/baseline`，以及 TNO0026 对齐统计 DPI 后的 GSIM PGO 可执行文件。
- TNO0028 的 `build/armor-xs-value-paths-v1/generator`（FTQ 生成源码、ELF、逐站点训练文件、构建参数）、`sequence`、各负载的 TSV、`elf/generator` 和 `reemit/emit.command.json`。阶段文件、覆盖源文件及运行命令中包含工作区路径。迁移到其他目录时按实际根目录重建这些输入。

## 证明、生成及重建

1. 运行 `python3 proof.py` 和 `python3 paddr.py` 对三个字段和物理地址分别做 BDD 检查，再运行 `python3 layout.py` 和 `python3 layout.py paddr` 检查两组 C++ 槽及其读者。`python3 neighbors.py` 检查相邻字段，`python3 cone.py` 和 `python3 cone.py address` 分别计算三、四个字段依赖的值以及外部读者。
2. 对 `guards`、`payload`、`ports`、`pruned`、`address`、`address-pruned`、`address-cones` 各运行一次 `python3 build.py 标签`。这些命令在新实验目录创建私有源码、选择原有站点并为每个版本重新训练 Clang PGO。前三个标签分别移动使能、数据和两者。`pruned` 另外清理三个字段没有活跃读者的标量。`address` 添加物理地址。`address-pruned` 用四个字段的依赖重新做同样的标量分析。`address-cones` 在该分析前先去掉只服务已删除写口的纯条件 mux 块。各标签可独立构建。
3. `python3 export_profile.py pruned triplet-profile.json.gz`、`python3 export_profile.py address address-profile.json.gz` 和 `python3 export_profile.py address-cones address-cones-profile.json.gz` 可独立重建包中的三份压缩配置。将参数名、产物哈希与记录的 JSON 核对。若要核对当时通过 Make 走完流程的独立构建，在实验 checkout 的根目录运行 `git apply build/armor-xs-rob-writeback-v1/historical-make.patch` 恢复当时的接线，再回到本目录。此时可用 `python3 make_run.py triplet-profile.json.gz` 从检查点重新生成模型。随后 `python3 replay_address.py address` 和 `python3 replay_address.py address-cones` 对该新模型应用对应配置并走相同的 Make PGO 编译入口。
4. 三份独立 Make 产物分别用 `python3 reconcile.py pruned make`、`python3 reconcile.py address make-address`、`python3 reconcile.py address-cones make-address-cones` 核对最终 ELF 的完整代码段和所有生成模型函数。`python3 elf.py` 对照基线和三字段 ELF。四字段版用 `python3 -c 'import elf; elf.run(("address","size")); elf.run(("address","dispatch"))'`，将标签替换为 `address-cones` 可查看额外清理后的版本。
5. `python3 coverage.py` 和 `python3 write_rates.py` 分别汇总原终端赋值、删去站点的访问频率，以及原来被允许写的元素和真实状态变化数。前两项原始终端赋值和写口比较使用 TNO0026 的覆盖文件。删去站点的访问和变化数来自已有的 TNO0028 全站点计数。

## 功能和计时

`python3 paddr_elf.py pruned address address-cones` 用各自的 PGO 编译带行号的计算分片 22 和 26，核对第 79 行后半条目在消费端和生产端映射到最终 ELF 的指令。`python3 site_overlap.py` 将被删除的变化检查及提交写口与原来训练选中的站点取交集。

- `python3 build.py shadow` 生成逐正沿检查三个字段的独立构建，再运行 `python3 shadow_run.py`。分别执行 `python3 directed.py` 和 `python3 directed.py address` 编译真实的端口分发函数并与按行枚举的独立参考比较。
- 运行 `python3 verify.py guards payload ports pruned address address-cones make make-address make-address-cones`。完整 MicroBench 使用 `long/baseline` 指向 TNO0027 的同名参考目录，运行 `python3 long_trace.py ports pruned address address-cones make make-address make-address-cones`。两种完整检查都打开 DiffTest。
- 在 node030 分别运行以下命令，`WL CPU` 对应 `coremark 104`、`microbench 120`。每次运行固定一个物理核和 NUMA 节点 1，检查 SMT 兄弟空闲、运行时驻留和 PMU 计数器使用比例。表中的正反顺序由脚本按负载及轮次决定。

```sh
python3 pairs.py components WL CPU ftq guards payload ports --rounds 3
python3 pairs.py final WL CPU ftq ports pruned gs_pgo --rounds 4
python3 pairs.py address WL CPU ftq pruned address gs_pgo --rounds 3
python3 pairs.py cones WL CPU ftq pruned address address-cones gs_pgo --rounds 3
```

- `python3 cache_pairs.py frontend coremark 96 ftq ports pruned --rounds 2` 和 `python3 cache_pairs.py data coremark 112 ftq ports pruned --rounds 2` 分别采前端、数据缓存事件。四字段边际比较使用组名 `address_frontend`、`address_data`，两个工作负载分别在相同的 96、112 核上测量 `pruned address` 各两轮。96 核使用工作区已有的 XiangShan 计时锁。
- 在本目录运行 `PYTHONPATH=../../scripts python3 test_grhsim_rob_writeback.py`。在仓库根目录运行 `python3 scripts/test_grhsim_change_sites.py`、安装了当前绑定的 Python 下的 `scripts/test_wolvrix_xs_grhsim_options.py`。在原工具构建目录用 CTest 运行 `emit-grhsim-execution-plan`、`emit-grhsim-cpp-commit-blocks`、`emit-grhsim-cpp-priority-mux-commit-demand`，保留输出为本目录的 `ctest.log`。
- 用 `python3 cache_pairs.py check_frontend coremark 96 pruned address-cones --rounds 4` 和 `python3 cache_pairs.py check_data microbench 112 pruned address-cones --rounds 4` 复现额外两个物理核上完成清理后的四字段和三字段直接对照。
- 运行 `python3 archive.py` 导出所有已接受样本、指标、ELF 摘录、功能核对和本包。CSV 每行是一次实测，JSON 的配对百分数按一轮内的两个时间求比后再取算术均值。

