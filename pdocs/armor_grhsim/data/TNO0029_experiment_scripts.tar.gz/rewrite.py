"""Materialize the proved terminal write-port inputs from active ports at the compute/commit boundary."""
from collections import defaultdict
from pathlib import Path
import json,re

base=Path(__file__).resolve().parent
names=("lqIdx","sqIdx","exuData")
table_names={"lqIdx":"lq","sqIdx":"sq","exuData":"data"}

def patch_model(model,tag):
    layout=json.loads((base/"layout.json").read_text())
    proof=json.loads((base/"proof.json").read_text())
    shadow=tag=="shadow"
    move_guards=tag in ("guards","ports")
    move_values=tag in ("payload","ports")
    guarded_outputs=move_guards or shadow
    payload_outputs=move_values or shadow
    assert proof["clock_ids"]==[2]
    assert not layout["source_missing"] and len(layout["writes"])==960
    src={(p["port"],p["role"]):p["source"] for p in layout["ports"]}
    payloads=proof["payloads"]
    columns={}
    source_files=defaultdict(list)
    for w in layout["writes"]:
        field=w["field"];key=2*w["row"]+w["half"]
        for role in ("guard","value"):
            part=w[role+"_storage"]
            assert part["eligible"] and part["commit_uses"]==1 and part["compute_uses"]==1
            assert part["bulk"]==(["commit"] if role=="guard" else [])
            if role=="guard" and not guarded_outputs or role=="value" and not payload_outputs:continue
            prefix=table_names[field]+("_guard" if role=="guard" else "_slot")
            columns[prefix,key]=int(re.fullmatch(r"value_(bool|u8|u64)_slots_\[(\d+)\]",part["slot"])[2])
            if not shadow:
                path,comment=part["blocks"][0]
                source_files[path].append((comment,w[role],part["slot"]))
    # The ChangeSites private training copy inserts one include in marked shards.
    for name,items in source_files.items():
        path=model/name
        lines=path.read_text().splitlines(keepends=True)
        extra=int(lines[0].startswith('#include "') and '.sites.h"' in lines[0])
        for comment,value,slot in items:
            pos=comment+extra
            assert f"[value_id={value}:0]" in lines[pos-1]
            assert lines[pos].strip()=="{" and lines[pos+2].strip()==slot+" = next_value;" and lines[pos+3].strip()=="}"
            lines[pos:pos+4]=[""]*4
        path.write_text("".join(lines))
    header=model/"grhsim_SimTop.hpp"
    hdr=header.read_text()
    declaration="    void eval_commit_batch_66();"
    assert hdr.count(declaration)==1
    extra="    void prepare_rob_writeback(bool initialize = false);\n"
    if move_guards:
        extra+="    std::array<std::uint16_t, 37> rob_touched_rows_{};\n    std::size_t rob_touched_count_{};\n"
    header.write_text(hdr.replace(declaration,declaration+"\n"+extra))
    state=model/"grhsim_SimTop_state.cpp"
    init="void GrhSIM_SimTop::init()\n{"
    if move_guards:
        content=state.read_text()
        assert content.count(init)==1
        state.write_text(content.replace(init,init+"\n    prepare_rob_writeback(true);"))
    book=["","void GrhSIM_SimTop::prepare_rob_writeback(bool initialize)","{"]
    fields=list(dict.fromkeys(k for k,_ in columns))
    book.append("    struct Row { "+" ".join("std::uint32_t "+f+";" for f in fields)+" };")
    book.append("    static constexpr Row rows[] = {")
    for idx in range(320):
        book.append("        {"+", ".join(str(columns[f,idx]) for f in fields)+"},")
    book+=["    };"]
    if move_guards:
        book+=["    const auto clear = [&](const Row &row) {","        value_bool_slots_[row.lq_guard] = false;",
               "        value_bool_slots_[row.sq_guard] = false;","        value_bool_slots_[row.data_guard] = false;","    };",
               "    if (initialize) {","        for (const Row &row : rows) clear(row);","        rob_touched_count_ = 0;","        return;","    }",
               "    for (std::size_t i = 0; i < rob_touched_count_; ++i) clear(rows[rob_touched_rows_[i]]);",
               "    rob_touched_count_ = 0;"]
    if shadow:
        book+=["    std::array<bool, 320> allocated{};","    std::array<unsigned char, 320> wb_hits{};",
               "    std::array<std::uint8_t, 320> lq{}, sq{};","    std::array<std::uint64_t, 320> data{};"]
    roles={"lqIdx":"lq","sqIdx":"sq","exuData":"data"}
    for p in [*range(29,37),*range(29)]:
        addr=src[p,"bits_robIdx_value"]
        book+=[f"    if ({src[p,'valid']} && {addr} < 160u) {{",
               f"        const unsigned index = static_cast<unsigned>({addr}) * 2u + !{src[p,'bits_robIdx_isFormer']};"]
        if not shadow:book.append("        const Row &row = rows[index];")
        if move_guards:
            book+=["        rob_touched_rows_[rob_touched_count_++] = static_cast<std::uint16_t>(index);",
                   "        value_bool_slots_[row.lq_guard] = true;"]
            if p<29:book+=["        value_bool_slots_[row.sq_guard] = true;","        value_bool_slots_[row.data_guard] = true;"]
        if shadow:book.append("        ++wb_hits[index];" if p<29 else "        allocated[index] = true;")
        if payload_outputs:
            for f,k in roles.items():
                if p>=29 and f!="lqIdx":continue
                role=payloads[f].get(str(p))
                value=src[p,role] if role else "0"
                target=(k+"[index]") if shadow else ("value_u64_slots_" if k=="data" else "value_u8_slots_")+"[row."+k+"_slot]"
                book.append(f"        {target} = {value};")
        book.append("    }")
    if shadow:
        book+=["    static std::uint64_t edges{}, wb{}, collision{}, overlap{}, allocation_only{}, load_writes{}, other_writes{};",
               "    ++edges;","    for (unsigned i = 0; i < 320; ++i) {",
               "        const Row &r = rows[i];","        const bool enabled = wb_hits[i] != 0;",
               "        const bool load = enabled || allocated[i];",
               "        if (value_bool_slots_[r.lq_guard] != load || value_bool_slots_[r.sq_guard] != enabled ||",
               "            value_bool_slots_[r.data_guard] != enabled || (load && value_u8_slots_[r.lq_slot] != lq[i]) ||",
               "            (enabled && (value_u8_slots_[r.sq_slot] != sq[i] || value_u64_slots_[r.data_slot] != data[i]))) {",
               '            std::fprintf(stderr,"ROB write mismatch at edge=%llu element=%u expected=%d/%d/%u/%u/%llu observed=%d/%d/%d/%u/%u/%llu\\n",',
               '                (unsigned long long)edges,i,(int)load,(int)enabled,(unsigned)lq[i],(unsigned)sq[i],(unsigned long long)data[i],',
               '                value_bool_slots_[r.lq_guard],value_bool_slots_[r.sq_guard],value_bool_slots_[r.data_guard],',
               '                value_u8_slots_[r.lq_slot],value_u8_slots_[r.sq_slot],(unsigned long long)value_u64_slots_[r.data_slot]);',
               "            std::abort();","        }","        wb += wb_hits[i]; collision += wb_hits[i] > 1;",
               "        overlap += enabled && allocated[i]; allocation_only += !enabled && allocated[i];",
               "        load_writes += load; other_writes += enabled;","    }",
               '    if (edges % 10000 == 0) std::fprintf(stderr,"ROB_SHADOW %llu %llu %llu %llu %llu %llu %llu\\n",',
               "        (unsigned long long)edges,(unsigned long long)wb,(unsigned long long)collision,",
               "        (unsigned long long)overlap,(unsigned long long)allocation_only,(unsigned long long)load_writes,(unsigned long long)other_writes);"]
    book+=["}",""]
    ev=model/"grhsim_SimTop_eval.cpp";s=ev.read_text()
    cut="        // Then commit sink supernodes in direct schedule order."
    assert s.count(cut)==1 and s.index("this->eval_compute_batch_65();")<s.index(cut)<s.index("this->eval_commit_batch_66();")
    if shadow:s='#include <cstdio>\n#include <cstdlib>\n'+s
    ev.write_text(s.replace(cut,"        if (hot_event_posedge_) prepare_rob_writeback();\n"+cut)+"\n".join(book))
    return dict(tag=tag,removed_stores=sum(len(x) for x in source_files.values()),modified_shards=sorted(source_files))

