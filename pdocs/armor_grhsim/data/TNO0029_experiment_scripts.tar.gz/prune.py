"""Remove pure scalar definitions with no surviving readers in the frozen scheduled C++."""
from collections import Counter,defaultdict
from pathlib import Path
import json,re
base=Path(__file__).resolve().parent
ref=re.compile(r"\b(?:value_(?:bool|u8|u16|u32|u64)_slots_\[\d+\]|grhsim_v\d+_\d+)\b(?<!\])|\bvalue_(?:bool|u8|u16|u32|u64)_slots_\[\d+\]")
slotref=re.compile(r"value_(bool|u8|u16|u32|u64)_slots_\[(\d+)\]")
pointer=re.compile(r"value_(bool|u8|u16|u32|u64)_slots_\.data\(\) \+ (\d+)u")
comment=re.compile(r"-> (value_(?:bool|u8|u16|u32|u64)_slots_\[\d+\]) \[value_id=(\d+):0\]")
local=re.compile(r"\s*const (?:bool|std::uint(?:8|16|32|64)_t) (grhsim_v(\d+)_\d+) = (.*);\s*$")
calls=re.compile(r"\b([a-zA-Z_]\w*)\(")
def pure(expr):
    # Ordinary scalar reads, logical/arithmetic operators, and pure logic helpers.
    # Address-taking, updates, event APIs and opaque C++ calls are not candidates.
    return not ("++" in expr or "--" in expr or ".data(" in expr) and all(x in ("UINT64_C","UINT32_C","UINT16_C","UINT8_C") or x.startswith(("grhsim_mux_","grhsim_sel_","grhsim_reduce_","grhsim_trunc_")) for x in calls.findall(expr))
def read_range(line,m):
    if "std::memcmp" in line:
        length=int(re.search(r"(\d+)u \* sizeof",line[m.end():])[1])
    elif "grhsim_store_scalar_slices<" in line:
        length=line.partition("grhsim_store_scalar_slices<")[2].partition(">")[0].count(",")
    else:raise ValueError(line[:240])
    return range(int(m[2]),int(m[2])+length)
def inventory(rows,exclusive):
    finds=[];phase=None;j=0
    while j<len(rows):
        row=rows[j]
        if row.startswith("void "):phase="::eval_compute_batch_" in row
        if not phase:j+=1;continue
        if (m:=local.match(row)) and int(m[2]) in exclusive and pure(m[3]):
            finds.append((j,j+1,m[1],int(m[2]),m[3]));j+=1;continue
        if "[value_id=" not in row or not (m:=comment.search(row)) or int(m[2]) not in exclusive:
            j+=1;continue
        key,v=m[1],int(m[2])
        if rows[j+1].strip()!="{" or not (assignment:=re.fullmatch(r"const (?:bool|std::uint(?:8|16|32|64)_t) next_value = (.*);",rows[j+2].strip())) or not pure(assignment[1]):
            j+=1;continue
        if rows[j+3].strip()==key+" = next_value;" and rows[j+4].strip()=="}":
            finds.append((j,j+5,key,v,assignment[1]));j+=5;continue
        end=next((i for i in range(j+3,min(j+40,len(rows))) if rows[i].rstrip()=="        }"),None)
        if end is None:j+=1;continue
        change=f"grhsim_changed_{v}"
        if rows[j+3].strip()!=f"const bool {change} = ({key} != next_value);":
            j+=1;continue
        # Only model-internal reader mask accumulators and a single store are removable.
        body=[s.strip() for s in rows[j+4:end]]
        allowed=[key+" = next_value;","{","}","#endif","#ifdef GRHSIM_COUNT_SITE",f"#ifdef GRHSIM_SPARSE_{v}",
                 f"if (unlikely({change}))",f"GRHSIM_COUNT_SITE(V, {v}, {change});"]
        if body.count(key+" = next_value;")!=1 or any(s not in allowed and not
           (change in s and (s.startswith(("supernode_active_curr_[","grhsim_any_changed_","grhsim_or_active_u")))) for s in body):
            j+=1;continue
        finds.append((j,end+1,key,v,assignment[1]));j=end+1
    return finds
def prune(model,extended=False):
    inventory_file="exclusive-address.txt" if extended else "exclusive.txt"
    exclusive={int(x) for x in (base/inventory_file).read_text().splitlines()}
    spans={};keys=set();byid={};deps=defaultdict(set);seen=Counter()
    for p in sorted(model.glob("*_sched_*.cpp")):
        records=inventory(p.read_text().splitlines(),exclusive)
        for j,end,key,v,expr in records:
            seen[key]+=1;keys.add(key);byid[key]=v
            deps[key].update(ref.findall(expr))
        if records:spans[p.name]={j:(end,key) for j,end,key,v,e in records}
    live={k for k,n in seen.items() if n>1}
    # The port selector uses dynamic subscripts whose tables list these exact sinks.
    layout=json.loads((base/"layout.json").read_text())
    if extended:
        layout["writes"].extend(json.loads((base/"paddr-layout.json").read_text())["writes"])
    live.update(w[k+"_storage"]["slot"] for w in layout["writes"] for k in ("guard","value"))
    for p in sorted([*model.glob("*.cpp"),*model.glob("*.hpp"),*model.glob("*.h")]):
        excluded=spans.get(p.name,{})
        end=0
        for j,row in enumerate(p.open()):
            if j<end:continue
            if j in excluded:end=excluded[j][0];continue
            if row.lstrip().startswith(("//","#")):continue
            if "value_" not in row and "grhsim_v" not in row:continue
            live.update(k for k in ref.findall(row) if k in keys)
            for m in pointer.finditer(row):
                live.update(f"value_{m[1]}_slots_[{i}]" for i in read_range(row,m))
    todo=list(live)
    while todo:
        for k in deps.get(todo.pop(),()):
            if k in keys and k not in live:
                live.add(k);todo.append(k)
    dead=keys-live
    for name,sp in spans.items():
        p=model/name;rows=p.read_text().splitlines(keepends=True);changed=False
        for lo,(hi,key) in sp.items():
            if key in dead:
                rows[lo:hi]=[""]*(hi-lo);changed=True
        if changed:p.write_text("".join(rows))
    return dict(candidates=len(keys),removed_locals=sum(k.startswith("grhsim_v") for k in dead),
                removed_slots=sum(k.startswith("value_") for k in dead),
                removed_slot_ids=sorted(byid[k] for k in dead if k.startswith("value_")),
                removed_value_ids=sorted(byid[k] for k in dead))

