"""Extend the proved three-field dispatch table with one physical-address payload."""
from collections import defaultdict
from pathlib import Path
import json,re
base=Path(__file__).resolve().parent
def extend(model):
    extra=json.loads((base/"paddr-layout.json").read_text())
    assert not extra["source_missing"]
    writes=sorted(extra["writes"],key=lambda w:(w["row"],w["half"]))
    blocks=defaultdict(dict)
    for w in writes:
        for role in ("guard","value"):
            a=w[role+"_storage"]
            assert a["eligible"] and a["commit_uses"]==1 and a["compute_uses"]==1 and not a["other"]
            assert a["bulk"]==(["commit"] if role=="guard" else [])
            name,_=a["blocks"][0]
            blocks[name][w[role]]=a["slot"]
    for name,items in blocks.items():
        p=model/name;rows=p.read_text().splitlines(keepends=True);found=set()
        for j,line in enumerate(rows):
            if "[value_id=" not in line:continue
            m=re.search(r"\[value_id=(\d+):0\]",line)
            if not m or (v:=int(m[1])) not in items:continue
            assert rows[j+1].strip()=="{" and " next_value = " in rows[j+2] and rows[j+3].strip()==items[v]+" = next_value;" and rows[j+4].strip()=="}"
            rows[j+1:j+5]=[""]*4;found.add(v)
        assert found==items.keys()
        p.write_text("".join(rows))
    p=model/"grhsim_SimTop_eval.cpp";s=p.read_text();first,body=s.split("void GrhSIM_SimTop::prepare_rob_writeback(bool initialize)\n")
    body=body.replace("struct Row { ","struct Row { std::uint32_t paddr_guard; std::uint32_t paddr_slot; ")
    rows=body.splitlines(keepends=True)
    table=rows.index("    static constexpr Row rows[] = {\n")+1
    for idx,w in enumerate(writes):
        col=[re.search(r"\[(\d+)\]",w[role+"_storage"]["slot"])[1] for role in ("guard","value")]
        rows[table+idx]=rows[table+idx].replace("{","{"+", ".join(col)+", ",1)
    body="".join(rows)
    body=body.replace("        value_bool_slots_[row.data_guard] = false;","        value_bool_slots_[row.data_guard] = false;\n        value_bool_slots_[row.paddr_guard] = false;")
    inputs={w["port"]:w["source"] for w in extra["ports"]}
    needle="        value_bool_slots_[row.data_guard] = true;"
    parts=body.split(needle);assert len(parts)==30
    buf=[parts[0]]
    for port,b in enumerate(parts[1:]):
        value=inputs[port]+" & UINT64_C(0xffffffffffff)" if port in inputs else "0"
        buf.append(needle+"\n        value_bool_slots_[row.paddr_guard] = true;\n        value_u64_slots_[row.paddr_slot] = "+value+";"+b)
    p.write_text(first+"void GrhSIM_SimTop::prepare_rob_writeback(bool initialize)\n"+"".join(buf))
    return dict(fields=len(writes),sources=len(inputs),extra_stores=sum(len(x) for x in blocks.values()))

