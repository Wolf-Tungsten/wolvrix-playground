"""Package the two group inventories, equivalence checks and accepted paired PMU runs."""
from collections import Counter
import csv
import gzip
import hashlib
import json
from pathlib import Path
from statistics import mean
import tarfile

here = Path(__file__).resolve().parent
root = here.parents[1]
out = root / "pdocs/armor_grhsim/data"
read = lambda path: json.loads(path.read_text())
rows = lambda name: [json.loads(line) for line in (here/name).read_text().splitlines()]
control = rows("control.jsonl")
before = {r["group"]:r for r in control if r["outcome"] != "decoded_write_overlap"}
after = {r["group"]:r for r in rows("checked.jsonl")}
assert before.keys() == after.keys()
assert all(r["writes"] == after[i]["writes"] for i,r in before.items())
assert all(after[i]["outcome"] == "converted" for i,r in before.items() if r["outcome"] == "converted")
added = {i for i,g in after.items() if g["outcome"] == "converted" and before[i]["outcome"] != "converted"}
target = {i for i,g in before.items() if g["outcome"] == "no_true_match" and g["consolidated_reject"] == "family_mismatch"
          and "common=0" in g["consolidated_detail"] and "data=1" in g["consolidated_detail"]}
assert added <= target
proof = read(here/"proof.json")
long = read(here/"long/verified.json")
stats = dict(threshold=64, targets=len(target), converted=len(added), groups=sorted(added),
             remaining=sorted(target-added), rows=sum(after[i]["members"] for i in added),
             strategies=Counter(after[i]["normalized_match"] for i in added),
             prior_merges=sum(r["outcome"]=="converted" for r in before.values()),
             total_merges=sum(r["outcome"]=="converted" for r in after.values()),
             overlap_at_29=[{k:r[k] for k in ("group","members","overlapping_groups")} for r in control
                            if r["outcome"]=="decoded_write_overlap"], write_proofs=proof,
             full_microbench={k:long[k] for k in ("guest_cycles","cycle","instr")},
             full_microbench_trace={k:long["trace"][k] for k in ("records","first_cycle","last_cycle","pass_")},
             workloads={})
samples = []
for wl in ("coremark","microbench"):
    upstream = read(root/f"build/armor-xs-upstream-v1/upstream-{wl}.json")["groups"]
    ranked = sorted((i for i,g in before.items() if g["outcome"] != "converted"),
                    key=lambda i: (-upstream.get(str(i),{}).get("visits",0),i))
    result = dict(top200_converted=sorted(added.intersection(ranked[:200])),
                  upstream_visits_per_cycle=sum(upstream.get(str(i),{}).get("visits",0) for i in added)/100001,
                  trace=read(here/f"verify/{wl}/result.json"))
    pairs = read(here/f"pairs/main/{wl}/rounds.json")
    assert len(pairs)==4
    metrics = []
    for i,pair in enumerate(pairs,1):
        assert set(pair["order"]) == {"ftq","normalized"}
        base, test = pair["ftq"],pair["normalized"]
        assert base["guest_cycles"] == test["guest_cycles"] == 100001
        metrics.append(dict(wall_pct=100*(test["external_wall_s"]/base["external_wall_s"]-1),
                            instructions_per_cycle=(test["counts"]["instructions"]-base["counts"]["instructions"])/100001))
        for order,tag in enumerate(pair["order"],1):
            r=pair[tag]
            samples.append(dict(workload=wl,round=i,position=order,variant=tag,cpu=pair["cpu"],
                wall_s=r["external_wall_s"],guest_cycles=r["guest_cycles"],**r["counts"],
                pmu_min_pct=min(r["counter_running_pct"].values()),cpu_fraction=r["cpu_fraction"],
                sibling_idle=min(n for c,n in r["sibling_idle"].items() if int(c)!=pair["cpu"]),
                binary_sha256=r["binary"]["sha256"],path=r["path"]))
    result.update(paired=metrics, instruction_delta=mean(m["instructions_per_cycle"] for m in metrics),
                  wall_delta_pct=mean(m["wall_pct"] for m in metrics),
                  faster_rounds=sum(m["wall_pct"]<0 for m in metrics))
    print(wl,result["instruction_delta"],result["wall_delta_pct"],result["faster_rounds"],
          [round(m["wall_pct"],2) for m in metrics])
    stats["workloads"][wl]=result
stats["reports"] = {}
for name in ("control","checked"):
    raw=(here/(name+".jsonl")).read_bytes()
    stats["reports"][name]=hashlib.sha256(raw).hexdigest()
    (here/(name+".jsonl.gz")).write_bytes(gzip.compress(raw,mtime=0))
stats["post_sha256"] = (here/"post.sha256").read_text().split()[0]
(out/"TNO0032_conflict_results.json").write_text(json.dumps(stats,indent=2)+"\n")
with (out/"TNO0032_conflict_samples.csv").open("w",newline="") as f:
    table=csv.DictWriter(f,fieldnames=samples[0],lineterminator="\n")
    table.writeheader()
    table.writerows(samples)
with tarfile.open(out/"TNO0032_conflict_repro.tar.gz","w:gz") as archive:
    for name in ("REPRODUCE.md","archive_results.py","check_writes.py","measure.py","verify_model.py","build_model.py",
                 "control.jsonl.gz","checked.jsonl.gz","post.sha256","proof-final.log","ctest-all.log",
                 "checked-pass.log","baseline-compiler.log","options.log","parser-tests.log"):
        archive.add(here/name,arcname=name)
