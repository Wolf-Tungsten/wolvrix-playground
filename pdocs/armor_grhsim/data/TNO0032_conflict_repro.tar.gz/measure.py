"""Counterbalance the normalized build with the frozen TNO0028 binary on node030."""
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
root = here.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
import site_pairs

site_pairs.base = here
site_pairs.bins.update(ftq=root / "build/armor-xs-value-paths-v1/generator/build/emu",
                       normalized=here / "build/emu")
site_pairs.main()
