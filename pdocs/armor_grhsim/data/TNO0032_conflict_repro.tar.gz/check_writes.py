"""Check scalar vs recovered ROB writes using the actual pre/post GRH operands and libz3."""
import ctypes as C
from ctypes.util import find_library
from functools import lru_cache
import json
import mmap
from pathlib import Path
import re
import sys

here = Path(__file__).resolve().parent
root = here.parents[1]
pre_path = root / "build/armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json"
z3 = C.CDLL(find_library("z3"))


def function(name, result, *args):
    fn = getattr(z3, "Z3_" + name)
    fn.argtypes = args
    fn.restype = result
    return fn


ptr = C.c_void_p
config = function("mk_config", ptr)()
context = function("mk_context", ptr, ptr)
destroy = function("del_context", None, ptr)
evaluate = function("eval_smtlib2_string", C.c_char_p, ptr, C.c_char_p)


class Checkpoint:
    def __init__(self, path, regs, memories):
        # Pretty-compact GRH has one value or operation per line. Index symbol and offset
        # only. Parse complete JSON records on demand, including attrs and edge identity.
        self.width = {}
        self.signed = set()
        self.defs = {}
        self.writes = {}
        self.ports = {m: [] for m in memories}
        self.memory = {}
        f = path.open("rb")
        self.data = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        self.data.seek(self.data.find(b'      "vals": ['))
        while line := self.data.readline():
            if line.startswith(b'      "ports"'):
                break
            m = re.match(rb'        \{"sym": "([^"\\]+)", "w": (\d+), "sgn": (true|false),', line)
            if m:
                name = m[1].decode()
                self.width[name] = int(m[2])
                if m[3] == b"true": self.signed.add(name)
        self.data.seek(self.data.find(b'      "ops": [', self.data.tell()))
        while True:
            pos = self.data.tell()
            line = self.data.readline()
            if not line or line.startswith(b'      ]'):
                break
            at = line.find(b', "out": [')
            if at < 0:
                continue
            end = line.index(b']', at)
            outputs = line[at+10:end]
            if outputs:
                if b'\\' in outputs or b'", "' in outputs:
                    for value in json.loads(b'[' + outputs + b']'):
                        self.defs[value] = pos
                else:
                    self.defs[outputs[1:-1].decode()] = pos
                continue
            if b'"kind": "kRegisterWritePort"' in line:
                sym = line.split(b'"', 4)[3].decode()
                if sym in regs:
                    self.writes[sym] = json.loads(line.rstrip(b',\n'))
            elif b'"kind": "kMemory' in line:
                op = json.loads(line.rstrip(b',\n'))
                if op["sym"] in memories:
                    self.memory[op["sym"]] = op
                elif op["kind"] in ("kMemoryWritePort", "kMemoryFillPort"):
                    mem = op["attrs"]["memSymbol"]["v"]
                    if mem in memories:
                        self.ports[mem].append(op)

    @lru_cache(maxsize=262144)
    def op(self, value):
        pos = self.defs.get(value)
        if pos is None:
            return {}
        self.data.seek(pos)
        return json.loads(self.data.readline().rstrip(b',\n'))


def literal(n, w):
    return f"(_ bv{n % (1 << w)} {w})"


def width_cast(e, old, new, signed=False):
    if old == new: return e
    if old < new: return f"((_ {'sign_extend' if signed else 'zero_extend'} {new-old}) {e})"
    return f"((_ extract {new-1} 0) {e})"


def solve_group(g, pre, post):
    mem = memory_name(g)
    ports = post.ports[mem]
    assert ports and all(p["kind"] == "kMemoryWritePort" for p in ports)
    ports = sorted(ports, key=lambda p: -p["attrs"]["memoryWrite.priority"]["v"])
    assert all(p["attrs"]["memoryWrite.priorityGroup"]["v"] == mem for p in ports)
    assert {p["attrs"]["memoryWrite.priority"]["v"] for p in ports} == set(range(len(ports)))
    memattr = post.memory[mem]["attrs"]
    assert memattr["row"]["v"] == g["members"] == len(g["writes"])  # Entire zero-based arrays here.
    word = memattr["width"]["v"]
    shared = set()
    # Preserve the actual shared RTL boundary. Compare independent address ports,
    # enables, half selectors and payloads for arbitrary values including collisions.
    for graph in (pre, post):
        for name in graph.width:
            if re.search(r"\$rob\$io_(?:exuWriteback|writeback)_\d+_(?:valid|bits_robIdx_(?:value|isFormer)|bits_data|bits_debug_paddr)$", name):
                shared.add(name)
    shared.update(p["in"][1] for p in ports)
    for p in ports:
        data = p["in"][2]
        if data in pre.width and pre.op(data).get("kind") != "kConstant":
            shared.add(data)

    def stable(v):
        assert v in pre.width and v in post.width and pre.width[v] == post.width[v], v
        assert (v in pre.signed) == (v in post.signed), v
        a, b = pre.op(v), post.op(v)
        assert all(a.get(k) == b.get(k) for k in ("sym", "kind", "attrs", "in")), v
    for v in shared: stable(v)
    for row, (_, op, reg) in enumerate(g["writes"]):
        original = pre.writes[op]
        assert original["attrs"]["regSymbol"]["v"] == reg
        decl = []; leaves = {}

        def atom(v, w):
            if v not in leaves:
                sym = "i" + str(len(leaves))
                leaves[v] = sym
                decl.append(f"(declare-const {sym} (_ BitVec {w}))")
            return leaves[v]

        @lru_cache(None)
        def expr(side, v, subst=None):
            gr = pre if side == 0 else post
            w = gr.width[v]
            if v == subst: return literal(row, w)
            if v in shared: return atom(v, w)
            o = gr.op(v)
            k = o.get("kind"); ins = o.get("in", []); attrs = o.get("attrs", {})
            def a(i): return expr(side, ins[i], subst)
            if k == "kConstant":
                value = attrs["constValue"]["v"].replace("_", "")
                base, digits = re.fullmatch(r"\d+'s?([bdho])([a-fA-F\d]+)", value).groups()
                return literal(int(digits, {"b":2,"d":10,"h":16,"o":8}[base]), w)
            if k == "kAssign": return width_cast(a(0), gr.width[ins[0]], w, ins[0] in gr.signed)
            if k in ("kEq","kLt","kGe"):
                aw = max(gr.width[s] for s in ins)
                l,r = [width_cast(a(i), gr.width[s], aw, s in gr.signed) for i,s in enumerate(ins)]
                signed = all(s in gr.signed for s in ins)
                pred = {"kEq":"=","kLt":"bvslt" if signed else "bvult","kGe":"bvsge" if signed else "bvuge"}[k]
                rhs = f"(ite ({pred} {l} {r}) #b1 #b0)"
            elif k in ("kOr","kAnd","kLogicOr","kLogicAnd","kNot","kLogicNot"):
                if k.startswith("kLogic"):
                    assert all(gr.width[s] == 1 for s in ins), (k, v)
                op = {"kAnd":"bvand","kLogicAnd":"bvand","kOr":"bvor","kLogicOr":"bvor",
                      "kNot":"bvnot","kLogicNot":"bvnot"}[k]
                rhs = f"({op} " + " ".join(width_cast(a(i), gr.width[s], w, s in gr.signed) for i,s in enumerate(ins)) + ")"
            elif k in ("kReduceOr","kReduceAnd"):
                req = literal(0 if k == "kReduceOr" else -1, gr.width[ins[0]])
                rhs = f"(ite (= {a(0)} {req}) " + ("#b0 #b1)" if k == "kReduceOr" else "#b1 #b0)")
            elif k == "kMux":
                assert gr.width[ins[0]] == 1 and gr.width[ins[1]] == gr.width[ins[2]] == w
                rhs = f"(ite (= {a(0)} #b1) {a(1)} {a(2)})"
            elif k == "kConcat":
                rhs = a(0)
                for i in range(1,len(ins)): rhs = f"(concat {rhs} {a(i)})"
            elif k == "kSliceStatic":
                hi,lo = (attrs[key]["v"] for key in ("sliceEnd","sliceStart"))
                rhs = f"((_ extract {hi} {lo}) {a(0)})"
            elif k == "kReplicate":
                assert w % gr.width[ins[0]] == 0
                rhs = f"((_ repeat {w // gr.width[ins[0]]}) {a(0)})"
            else:
                stable(v)
                return atom(v, w)
            ident = f"v{len(decl)}"
            decl.append(f"(define-fun {ident} () (_ BitVec {w}) {rhs})")
            return ident

        old_enable, old_data, old_mask, *event = original["in"]
        enabled = expr(0,old_enable); payload = expr(0,old_data); mask = expr(0,old_mask)
        hits = []; selected = literal(0,word)
        for p in ports:
            gate, addr, data, m, *ev = p["in"]
            assert event == ev and p["attrs"]["eventEdge"] == original["attrs"]["eventEdge"]
            assert m == old_mask and pre.width[old_mask] == post.width[m]
            stable(m)
            # When addr == row the occurrences of that address in this gate can be replaced by row.
            hit = f"(and (= {expr(1,addr)} {literal(row,post.width[addr])}) (= {expr(1,gate,addr)} #b1))"
            hits.append(hit)
            selected = f"(ite {hit} {expr(1,data)} {selected})"
        differs = f"(or (distinct (= {enabled} #b1) (or {' '.join(hits)})) (and (= {enabled} #b1) (distinct (bvand {payload} {mask}) (bvand {selected} {mask}))))"
        assert pre.width[old_mask] == pre.width[old_data] == word
        query = "\n".join(["(set-logic QF_BV)", "(set-option :timeout 20000)", *decl,
                           f"(assert {differs})", "(check-sat)"])
        ctx = context(config)
        answer = evaluate(ctx, query.encode()).decode().strip()
        destroy(ctx)
        if answer != "unsat":
            (here/"failed.smt2").write_text(query)
            raise ValueError((g["group"], row, answer))
    return {"group":g["group"], "rows":len(g["writes"]), "width":word, "ports":len(ports),
            "unsat":len(g["writes"])}


def memory_name(g):
    return "rtm_mem$" + re.sub("[^a-zA-Z0-9_]", "_", g["writes"][0][2])


def main():
    groups = [json.loads(l) for l in (here/"checked.jsonl").open()]
    groups = [g for g in groups if g["outcome"]=="converted" and g["normalized_match"]!="not_attempted"
              and "$rob$" in g["writes"][0][2]]
    assert len(groups) == 4 and sum(g["members"] for g in groups) == 640
    regs = {op for g in groups for _,op,_ in g["writes"]}
    memories = {memory_name(g) for g in groups}
    print("indexing original and transformed checkpoints", flush=True)
    pre = Checkpoint(pre_path, regs, set())
    post = Checkpoint(here/"checked-post.json", set(), memories)
    assert set(pre.writes) == regs and set(post.memory) == memories
    result = []
    for g in groups:
        result.append(solve_group(g, pre, post))
        print(result[-1], flush=True)
    (here/"proof.json").write_text(json.dumps(result, indent=2)+"\n")


if __name__ == "__main__":
    main()
