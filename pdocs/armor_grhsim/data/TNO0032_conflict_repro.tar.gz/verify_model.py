"""Run both TNO0029 trace checks or the full MicroBench trace to the reference good trap."""
from pathlib import Path
import json
import re
import resource
import sys

here = Path(__file__).resolve().parent
root = here.parents[1]
sys.path.insert(0, str(root / "scripts/armor_xs_gap_diagnostics"))
from diagnostics import IMAGES, NEMU, clean_environment, execute, pick_cpu, save
from grhsim_difftrace import compare_traces
from verify_sparse import verify_sparse

resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
binary = here / "build/emu"
if sys.argv[1:] == ["long"]:
    out = here / "long"
    cpu, _ = pick_cpu()
    execute(["taskset", "-c", str(cpu), "numactl", "--membind=1", "setarch", "x86_64", "-R", binary,
             "-i", IMAGES["microbench"], "--diff", NEMU, "-b", "0", "-e", "0", "-s", "0", "-C", "250000",
             "--dump-difftrace", "./trace"], "run", out, clean_environment(), out)
    text = re.sub(r"\x1b\[[0-9;]*m", "", (out/"run.log").read_text())
    assert "MicroBench PASS" in text and "HIT GOOD TRAP" in text and "Difftest enabled" in text
    ref = root / "build/armor-xs-site-pgo-v1/long/baseline"
    expected = json.loads((ref/"endpoint.json").read_text())
    numbers = {}
    for key, label in (("guest_cycles","Guest cycle spent: "), ("cycle","cycleCnt = "), ("instr","instrCnt = ")):
        numbers[key] = int(re.search(label + r"([\d,]+)", text)[1].replace(",", ""))
        assert numbers[key] == expected[key]
    assert re.search(r"HIT GOOD TRAP at pc = (0x\w+)",text)[1] == expected["pc"]
    trace = compare_traces(root/"build/armor-xs-pgo-v1/gsim/verify/comparator/compare",
                           ref/"trace", out/"trace", out/"trace.json")
    assert trace["pass_"] and trace["records"] == 225599 and trace["last_cycle"] == expected["cycle"], trace
    save(out/"verified.json", dict(**numbers, trace=trace))
else:
    verify_sparse(binary, here / "verify")
