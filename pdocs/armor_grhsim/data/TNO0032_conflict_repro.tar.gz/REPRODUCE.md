# TNO0032 复现

将包解至 `build/armor-xs-family-mismatch-v1`。所需输入为 TNO0030 的 pre-reg-to-mem 检查点、TNO0028 的生成命令、基线二进制及两种固件。证明程序通过系统 libz3 的 SMT-LIB 接口检查二态 GRH。先按主文给出的构建命令更新 Python 绑定。

```bash
cd build/armor-xs-family-mismatch-v1
tools="$PWD/../armor-dispatch-v1/tools"
export PYTHONPATH="$tools/python" LD_LIBRARY_PATH="$tools"
ulimit -s unlimited
pre=../armor-acc-default-v1/xs/model/wolvrix_xs_pre_reg_to_mem.json
replay=../../scripts/armor_xs_gap_diagnostics/replay_reg_to_mem.py
python3 "$replay" "$pre" control.jsonl --min-alternatives 29
python3 "$replay" "$pre" checked.jsonl --normalize-write-conflicts --output-checkpoint checked-post.json
sha256sum checked-post.json
python3 check_writes.py
python3 build_model.py
python3 verify_model.py
python3 verify_model.py long
```

在 node030 使用原 TNO0029 的两个物理核分别运行下列命令。脚本检查 NUMA 驻留、SMT 兄弟空闲率、PMU 运行比例和仿真终点。每种负载固定在同一核，成对换序四轮。

```bash
python3 measure.py main coremark 104 ftq normalized --rounds 4
python3 measure.py main microbench 120 ftq normalized --rounds 4
```

将 TNO0031 的 `upstream-coremark.json` 和 `upstream-microbench.json` 放入其复现目录，运行 `archive_results.py` 重算前 200 组命中数、配对变化和全部样本。两个压缩 JSONL 分别对应关闭新规则的门槛 29 和开启新规则的门槛 64。报告中的寄存器名仅用于取证。生产 pass 只匹配图结构。
