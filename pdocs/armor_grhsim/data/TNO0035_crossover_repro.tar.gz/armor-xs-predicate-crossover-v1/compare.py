"""Audit original and swapped fixed-binary PMU pairs against the archived endpoints."""
import csv
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
base = here.parent / 'armor-xs-predicate-encoding-v1'
data = here.parents[1] / 'pdocs/armor_grhsim/data'
old = json.loads((data / 'TNO0034_predicate_encoding_results.json').read_text())
tags = ('reference', 'eager')
events = ('instructions', 'cycles', 'branches', 'branch-misses', 'ex_ret_ops')


def summary(values):
    mean = statistics.mean(values)
    margin = 2.3646242516 * statistics.stdev(values)/math.sqrt(8)
    return {'mean':mean, 'ci95':[mean-margin, mean+margin], 'min':min(values), 'max':max(values),
            'negative':sum(v<0 for v in values)}


def raw_sample(row, cpu, wl, tag):
    sig = old['verification'][tag][wl]['signature']
    assert all(row[k] == v for k,v in sig.items())
    assert row['binary']['sha256'] == old['build']['binaries'][tag]
    path = base / row['path']
    raw = json.loads((path/'sample.json').read_text())
    assert all(row[k]==v for k,v in raw.items())
    with (path/'perf.csv').open() as stream:
        counts = {f[2].removesuffix(':u'):(int(f[0]),float(f[4])) for f in csv.reader(stream)
                  if len(f)>4 and f[2].removesuffix(':u') in events}
    assert set(counts) == set(events)
    assert all(row['counts'][k]==v and row['counter_running_pct'][k]==pct for k,(v,pct) in counts.items())
    sibling_idle = min(v for k,v in row['sibling_idle'].items() if int(k)!=cpu)
    running = min(row['counter_running_pct'].values())
    assert sibling_idle>=98 and running>=98 and row['cpu_fraction']>=.97 and row['placements']>0
    return dict(cpu=cpu,variant=tag,binary_sha256=row['binary']['sha256'],guest_cycles=sig['guest_cycles'],
                pc=sig['pc'],guest_instructions=sig['instr_count'],wall_s=row['external_wall_s'],
                **row['counts'],running_pct=running,sibling_idle_pct=sibling_idle,
                cpu_fraction=row['cpu_fraction'],path=row['path'])


def main():
    for t,sha in old['build']['binaries'].items():
        assert hashlib.sha256((base/t/'build/emu').read_bytes()).hexdigest()==sha
    records, groups = [], {}
    for block in ('paired','swapped'):
        for wl in ('coremark','microbench'):
            target = 104 if ((block=='paired') == (wl=='coremark')) else 120
            pairs = json.loads((base/'pairs'/block/wl/'rounds.json').read_text())
            assert len(pairs)==8
            values = {k:[] for k in ('wall_pct','cycles_pct',*events)}
            order = {}
            for n,r in enumerate(pairs,1):
                assert r['cpu']==target and set(r['order'])==set(tags) and len(r['order'])==2
                for position,tag in enumerate(r['order'],1):
                    records.append(dict(block=block,workload=wl,round=n,position=position,
                                        **raw_sample(r[tag],target,wl,tag)))
                a,b=(r[t] for t in tags)
                ratio=100*(b['external_wall_s']/a['external_wall_s']-1)
                values['wall_pct'].append(ratio)
                order.setdefault(r['order'][0],[]).append(ratio)
                values['cycles_pct'].append(100*(b['counts']['cycles']/a['counts']['cycles']-1))
                for event in events:
                    values[event].append((b['counts'][event]-a['counts'][event])/a['guest_cycles'])
            assert all(len(order[t])==4 for t in tags)
            result = {k:summary(v) for k,v in values.items()}
            if block=='paired': assert math.isclose(result['wall_pct']['mean'],old['workloads'][wl]['wall_pct']['mean'])
            result['wall_first'] = {t:statistics.mean(v) for t,v in order.items()}
            groups.setdefault(wl,{})[str(target)] = result
    assert len(records)==64 and len(set(r['path'] for r in records))==64
    report=dict(binaries=old['build']['binaries'],groups=groups,minimum_sample_quality={k:min(r[k] for r in records)
                for k in ('running_pct','sibling_idle_pct','cpu_fraction')})
    (data/'TNO0035_crossover_results.json').write_text(json.dumps(report,indent=2)+'\n')
    with (data/'TNO0035_crossover_samples.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=records[0],lineterminator='\n');writer.writeheader();writer.writerows(records)
    for wl,cores in groups.items():
        for cpu,r in cores.items():
            print(wl,cpu,r['wall_pct'], {k:round(r[k]['mean'],2) for k in ('cycles_pct','instructions','branch-misses')})

if __name__=='__main__':
    main()
