"""Collect separate IP samples for the changed object on both timed cores."""
import collections
import fcntl
import json
import os
import platform
import re
import resource
import subprocess
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]
base = here.parent / 'armor-xs-predicate-encoding-v1'
sys.path.insert(0, str(root/'scripts'))
import armor_xs_current_gap as gap
from grhsim_single_baseline import clean_environment, identity

PERIODS = {'branch-misses':12011,'de_no_dispatch_per_slot.no_ops_from_frontend':3000017}

def read(path):
    return json.loads(path.read_text())

def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2)+'\n')
    temp.replace(path)

def text_symbols(file):
    out = subprocess.check_output(['nm','-S','--defined-only',file],text=True)
    symbols = {}
    for line in out.splitlines():
        fields = line.split(None,3)
        if len(fields)==4 and fields[2] in ('T','t','W','w') and int(fields[1],16):
            symbols[fields[3]] = int(fields[0],16), int(fields[1],16)
    return symbols

def attribute(folder, binary, names):
    # Convert ELF symbol addresses into runtime addresses using executable PT_LOAD and its mapped file offset.
    ph = subprocess.check_output(['readelf','-lW',binary],text=True).splitlines()
    segment, = [l.split() for l in ph if l.lstrip().startswith('LOAD ') and ' E ' in l]
    seg_off, seg_va = int(segment[1],16), int(segment[2],16)
    maps = [l.split(maxsplit=5) for l in (folder/'maps').read_text().splitlines()]
    mapping, = [l for l in maps if len(l)==6 and l[5]==str(binary) and 'x' in l[1]]
    lo,hi=map(lambda x:int(x,16),mapping[0].split('-'))
    bias=lo - (seg_va + int(mapping[2],16) - seg_off)
    symbols = text_symbols(binary)
    ranges = [(bias+symbols[n][0],bias+sum(symbols[n])) for n in names]
    assert all(lo<=a<b<=hi for a,b in ranges)
    result = {e:collections.Counter() for e in PERIODS}
    cmd=['perf','script','--no-demangle','--show-lost-events','-F','event,period,ip,dso','-i',folder/'perf.data']
    with (folder/'decode.err').open('w') as err:
        proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=err,text=True)
        for raw in proc.stdout:
            if not raw.strip() or raw.startswith('#'):continue
            match=re.fullmatch(r'\s*(\d+)\s+(\S+):\s+([0-9a-fA-F]+)\s+\((.*)\)\s*',raw)
            if not match: raise RuntimeError(f'unparsed sample or lost event: {raw[:180]}')
            period,event,ip,dso=match.groups(); event=event.split('/')[0]; ip=int(ip,16)
            assert int(period)==PERIODS[event]
            if lo<=ip<hi and (dso==str(binary) or dso==binary.name):
                group='shard' if any(a<=ip<b for a,b in ranges) else 'other_emu'
            else:group='outside_emu'
            result[event][group]+=1
        if proc.wait(): raise RuntimeError((folder/'decode.err').read_text()[-1500:])
    assert all(c['shard']>0 and c['other_emu']>0 for c in result.values()),result
    return dict(symbols={n:symbols[n] for n in names},periods=PERIODS,counts=result)

def run(cpu):
    assert platform.node().split('.')[0]=='node030' and cpu in (104,120)
    resource.setrlimit(resource.RLIMIT_STACK,(resource.RLIM_INFINITY,resource.RLIM_INFINITY))
    gap.OUT=here
    gap.PERIOD=PERIODS
    syscpu=Path(f'/sys/devices/system/cpu/cpu{cpu}'); cache=(syscpu/'cache/index3/id').read_text().strip()
    siblings=set(map(int,(syscpu/'topology/thread_siblings_list').read_text().strip().split(',')))
    participants=('reference','eager'); ids=read(base/'identity.json'); obj,=ids['changed']
    names=text_symbols(base/'model'/obj); assert names
    block='swapped' if cpu==104 else 'paired'
    with (base/f'node030-l3-{cache}.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        pairs=read(base/'pairs'/block/'microbench/rounds.json'); assert len(pairs)==8
        for number,order in enumerate((participants,participants[::-1]),1):
            for tag in order:
                out=here/'profile'/f'cpu{cpu}'/f'pair{number}'/tag; out.mkdir(exist_ok=True,parents=True)
                folder=base/pairs[0][tag]['path']; runtime=folder.parent/'runtime'; binpath=runtime/'bin/emu'
                elf=identity(binpath); assert elf['sha256']==ids['binaries'][tag]
                orig=read(folder/'command.json'); pos=orig.index(str(binpath)); command=orig[:orig.index('perf')]+orig[pos:]
                assert command[-2:]==['-C',str(gap.WINDOW)]
                config=dict(cpu=cpu,siblings=siblings,binary=binpath,original_binary=elf,
                            plan=read(runtime/'manifest.json'),runtime=dict(clean_environment(),LC_ALL='C',EMU_PROGRESS_EVERY_CYCLES='0',LD_LIBRARY_PATH=str(runtime/'lib')),
                            base=command[:-2])
                if (out/'result.json').is_file():
                    old=read(out/'result.json');assert old['sha256']==elf['sha256'] and old['periods']==PERIODS
                    continue
                measured=None
                for attempt in range(8):
                    d=out/f'try{attempt}'; sample_file=d/'sample.json'
                    if sample_file.exists():
                        measured=read(sample_file);break
                    if d.exists():continue
                    try: measured=gap.run_one(config,'microbench',tag,0,d)
                    except RuntimeError as e:
                        if 'SMT busy' in str(e):continue
                        raise
                    break
                if not measured: raise RuntimeError('no accepted profiling window')
                assert measured['binary']['sha256']==elf['sha256'] and measured['guest_cycles']==100001
                info=attribute(here/measured['path'],binpath,names)
                save(out/'result.json',dict(cpu=cpu,pair=number,variant=tag,sha256=elf['sha256'],
                    guest_cycles=measured['guest_cycles'],source=measured['path'],**info))
                print(cpu,number,tag,info['counts'],flush=True)

if __name__=='__main__':run(int(sys.argv[1]))
