"""Export two counterbalanced diagnostic pairs per core separately from timed runs."""
import csv
import json
import statistics
from pathlib import Path

here = Path(__file__).resolve().parent
base = here.parent/'armor-xs-predicate-encoding-v1'
data = here.parents[1]/'pdocs/armor_grhsim/data'
identity = json.loads((base/'identity.json').read_text())
events = ['branch-misses', 'de_no_dispatch_per_slot.no_ops_from_frontend']
rows = []
summary = {}
for cpu in (104,120):
    summary[cpu] = {}
    for pair in (1,2):
        for tag in ('reference','eager'):
            folder=here/'profile'/f'cpu{cpu}'/f'pair{pair}'/tag
            sample=json.loads((folder/'result.json').read_text())
            run=json.loads((here/sample['source']/'sample.json').read_text())
            assert sample['sha256']==run['binary']['sha256']==identity['binaries'][tag]
            assert sample['guest_cycles']==run['guest_cycles']==100001
            assert run['pc']=='0x80000446' and run['runtime_difftest']=='on'
            assert set(sample['counts'])==set(events)
            for event in events:
                counts=sample['counts'][event]; total=sum(counts.values()); period=sample['periods'][event]
                assert set(counts)<={'shard','other_emu','outside_emu'} and 0<counts['shard']<total
                rows.append(dict(cpu=cpu,pair=pair,variant=tag,event=event,period=period,
                                 guest_cycles=run['guest_cycles'],shard_samples=counts['shard'],
                                 other_emu=counts['other_emu'],outside_emu=counts.get('outside_emu',0),
                                 total_samples=total,shard_share_pct=100*counts['shard']/total,
                                 shard_events_per_cycle=counts['shard']*period/run['guest_cycles'],
                                 total_events_per_cycle=total*period/run['guest_cycles'],
                                 source=sample['source']))
    for event in events:
        results=[]
        for pair in (1,2):
            a,b=[next(r for r in rows if (r['cpu'],r['pair'],r['variant'],r['event'])==(cpu,pair,tag,event))
                 for tag in ('reference','eager')]
            results.append({name:b[name]-a[name] for name in ('shard_events_per_cycle','total_events_per_cycle')})
        summary[cpu][event]={key:[r[key] for r in results] for key in results[0]}
with (data/'TNO0035_shard_samples.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=rows[0],lineterminator='\n');writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,indent=2))
