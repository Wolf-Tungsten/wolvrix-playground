# TNO0035 跨核复测

从主仓库根目录将归档解到 build/。输入沿用 TNO0034 冻结的两个模拟器、两套 PGO 数据以及 pairs/paired 中的原轮次。运行需要原实验的 node030、工作负载、NEMU、perf 权限和仓库内的 NUMA 检查工具。两个阶段都打开 DiffTest，窗口为 100,001 个实际 guest cycles。

~~~sh
base=build/armor-xs-predicate-encoding-v1
cross=build/armor-xs-predicate-crossover-v1
python3 "$base/measure.py" swapped coremark 120 reference eager --rounds 8
python3 "$base/measure.py" swapped microbench 104 reference eager --rounds 8
python3 "$cross/compare.py"
python3 "$cross/sample_shard.py" 104
python3 "$cross/sample_shard.py" 120
python3 "$cross/summarize_profile.py"
~~~

两个计时命令在 node030 的不同物理核上运行，可并行。请将新实验放在独立输出目录；已有完整配对可供后两个分析脚本直接核查。原始计时产物中的命令、perf.csv、sample.json、rounds.json 均保留。compare.py 核对冻结二进制哈希、guest 终点、每个计数器及运行比例、SMT 兄弟空闲率和配对顺序，另检查原轮的均值与 TNO0034 相符。

采样在两种实现各自已固定哈希的分阶段二进制上进行，核心锁与计时共用。每核各跑两对，首轮先短路、次轮先逐位。采样驱动从变更目标文件发现函数，从 ELF 段和进程实际映射还原地址，对该函数、模拟器其余部分、模拟器外代码分别计数。所有事件周期和分桶样本数保留在 CSV。每拍事件量为落在该桶的样本数乘采样周期，再除以 guest cycles。非精确事件采样存在指令位置偏移，只宜在函数粒度观察。两对采样仅用于归因，不进入八轮耗时区间。
